/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { useAuth } from './core/AuthContext';
import { Login } from './features/auth/Login';
import { Signup } from './features/auth/Signup';
import { Layout } from './widgets/Layout';
import { Dashboard } from './features/dashboard/Dashboard';
import { ExpenseList } from './features/expenses/ExpenseList';
import { AddExpense } from './features/expenses/AddExpense';
import { Analytics } from './features/analytics/Analytics';
import { Profile } from './features/auth/Profile';
import { Onboarding } from './features/auth/Onboarding';
import { RecurringExpenseList } from './features/expenses/RecurringExpenseList';
import { Goals } from './features/goals/Goals';
import { MoneyEducation } from './features/dashboard/MoneyEducation';
import { CommandPalette } from './widgets/CommandPalette';
import { FAB } from './widgets/FAB';
import { subscribeToExpenses } from './services/expenseService';
import { processRecurringExpenses } from './services/recurringExpenseService';
import { Expense, RecurringExpense } from './models/types';
import { motion, AnimatePresence } from 'motion/react';

type Tab = 'dashboard' | 'expenses' | 'analytics' | 'add' | 'profile' | 'recurring' | 'goals' | 'education';

export default function App() {
  const { user, profile, loading } = useAuth();
  const [isLogin, setIsLogin] = useState(true);
  const [activeTab, setActiveTab] = useState<Tab>('dashboard');
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [editingExpense, setEditingExpense] = useState<Expense | null>(null);
  const [editingRecurringExpense, setEditingRecurringExpense] = useState<RecurringExpense | null>(null);
  const [isCommandPaletteOpen, setIsCommandPaletteOpen] = useState(false);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'k' && (e.metaKey || e.ctrlKey)) {
        e.preventDefault();
        setIsCommandPaletteOpen(prev => !prev);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  useEffect(() => {
    if (user) {
      processRecurringExpenses();
      const unsubscribe = subscribeToExpenses((data) => {
        setExpenses(data);
      });
      return () => unsubscribe();
    }
  }, [user]);

  if (loading) {
    return (
      <div className="min-h-screen bg-zinc-50 flex items-center justify-center">
        <div className="w-12 h-12 border-4 border-emerald-600 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  const handleEdit = (expense: Expense) => {
    setEditingExpense(expense);
    setActiveTab('add');
  };

  const handleEditRecurring = (expense: RecurringExpense) => {
    setEditingRecurringExpense(expense);
    setActiveTab('add');
  };

  const handleCloseAdd = () => {
    setEditingExpense(null);
    setEditingRecurringExpense(null);
    setActiveTab('expenses');
  };

  return (
    <AnimatePresence mode="wait">
      {!user ? (
        <div key="auth" className="min-h-screen bg-zinc-50 dark:bg-zinc-950 flex items-center justify-center p-6">
          <AnimatePresence mode="wait">
            {isLogin ? (
              <motion.div
                key="login"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                transition={{ duration: 0.2 }}
                className="w-full"
              >
                <Login onToggle={() => setIsLogin(false)} />
              </motion.div>
            ) : (
              <motion.div
                key="signup"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                transition={{ duration: 0.2 }}
                className="w-full"
              >
                <Signup onToggle={() => setIsLogin(true)} />
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      ) : !profile?.onboardingCompleted ? (
        <motion.div
          key="onboarding"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
        >
          <Onboarding />
        </motion.div>
      ) : (
        <motion.div
          key="app"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
        >
          <Layout activeTab={activeTab} onTabChange={setActiveTab}>
            <CommandPalette 
              isOpen={isCommandPaletteOpen} 
              onClose={() => setIsCommandPaletteOpen(false)} 
              onTabChange={setActiveTab} 
            />
            <FAB 
              visible={activeTab !== 'add'} 
              onClick={() => setActiveTab('add')} 
            />
            <AnimatePresence mode="wait">
              {activeTab === 'dashboard' && (
                <motion.div
                  key="dashboard"
                  initial={{ opacity: 0, x: 10 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -10 }}
                >
                  <Dashboard 
                    expenses={expenses} 
                    onViewAll={() => setActiveTab('expenses')} 
                    onViewEducation={() => setActiveTab('education')}
                  />
                </motion.div>
              )}
              {activeTab === 'expenses' && (
                <motion.div
                  key="expenses"
                  initial={{ opacity: 0, x: 10 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -10 }}
                >
                  <ExpenseList 
                    expenses={expenses} 
                    onEdit={handleEdit} 
                  />
                </motion.div>
              )}
              {activeTab === 'analytics' && (
                <motion.div
                  key="analytics"
                  initial={{ opacity: 0, x: 10 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -10 }}
                >
                  <Analytics 
                    expenses={expenses} 
                  />
                </motion.div>
              )}
              {activeTab === 'add' && (
                <motion.div
                  key="add"
                  initial={{ opacity: 0, x: 10 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -10 }}
                >
                  <AddExpense 
                    onClose={handleCloseAdd} 
                    editExpense={editingExpense} 
                    editRecurringExpense={editingRecurringExpense}
                  />
                </motion.div>
              )}
              {activeTab === 'profile' && (
                <motion.div
                  key="profile"
                  initial={{ opacity: 0, x: 10 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -10 }}
                >
                  <Profile expenses={expenses} />
                </motion.div>
              )}
              {activeTab === 'recurring' && (
                <motion.div
                  key="recurring"
                  initial={{ opacity: 0, x: 10 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -10 }}
                >
                  <RecurringExpenseList onEdit={handleEditRecurring} />
                </motion.div>
              )}
              {activeTab === 'goals' && (
                <motion.div
                  key="goals"
                  initial={{ opacity: 0, x: 10 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -10 }}
                >
                  <Goals expenses={expenses} />
                </motion.div>
              )}
              {activeTab === 'education' && (
                <motion.div
                  key="education"
                  initial={{ opacity: 0, x: 10 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -10 }}
                >
                  <MoneyEducation />
                </motion.div>
              )}
            </AnimatePresence>
          </Layout>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

