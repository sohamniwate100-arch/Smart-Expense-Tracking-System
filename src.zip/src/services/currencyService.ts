/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

const BASE_URL = 'https://api.frankfurter.app';

export interface ExchangeRates {
  [key: string]: number;
}

let cachedRates: ExchangeRates | null = null;
let lastFetch: number = 0;
const CACHE_DURATION = 1000 * 60 * 60; // 1 hour

export const SUPPORTED_CURRENCIES = [
  { code: 'INR', symbol: '₹', name: 'Indian Rupee' },
  { code: 'USD', symbol: '$', name: 'US Dollar' },
  { code: 'EUR', symbol: '€', name: 'Euro' },
  { code: 'GBP', symbol: '£', name: 'British Pound' },
  { code: 'JPY', symbol: '¥', name: 'Japanese Yen' },
  { code: 'AUD', symbol: 'A$', name: 'Australian Dollar' },
  { code: 'CAD', symbol: 'C$', name: 'Canadian Dollar' },
  { code: 'CHF', symbol: 'CHF', name: 'Swiss Franc' },
  { code: 'CNY', symbol: '¥', name: 'Chinese Yuan' },
  { code: 'SGD', symbol: 'S$', name: 'Singapore Dollar' },
];

export async function fetchExchangeRates(base: string = 'INR'): Promise<ExchangeRates> {
  const now = Date.now();
  if (cachedRates && (now - lastFetch < CACHE_DURATION)) {
    return cachedRates;
  }

  try {
    const response = await fetch(`${BASE_URL}/latest?from=${base}`);
    if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
    const data = await response.json();
    if (!data || !data.rates) throw new Error('Invalid data received from API');
    
    cachedRates = data.rates;
    cachedRates![base] = 1; // Base rate is always 1
    lastFetch = now;
    return cachedRates!;
  } catch (error) {
    // Only log warning once to avoid console spam
    console.warn('Currency API unreachable, using fallback rates. This is expected in some network environments.');
    
    // Comprehensive fallback rates (approximate as of early 2024)
    const fallback: ExchangeRates = {
      'INR': 1,
      'USD': 0.012,
      'EUR': 0.011,
      'GBP': 0.0095,
      'JPY': 1.82,
      'AUD': 0.018,
      'CAD': 0.016,
      'CHF': 0.011,
      'CNY': 0.086,
      'SGD': 0.016,
    };
    return fallback;
  }
}

export function formatCurrency(amount: number, currencyCode: string = 'INR'): string {
  const currency = SUPPORTED_CURRENCIES.find(c => c.code === currencyCode) || SUPPORTED_CURRENCIES[0];
  
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: currency.code,
    minimumFractionDigits: 0,
    maximumFractionDigits: 2,
  }).format(amount);
}
