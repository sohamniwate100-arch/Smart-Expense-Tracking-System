import { GoogleGenAI, Type } from "@google/genai";
import { Category } from "../models/types";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export interface ScannedReceipt {
  amount: number;
  category: Category;
  date: string;
  notes: string;
  merchant: string;
}

export const scanReceipt = async (base64Image: string): Promise<ScannedReceipt> => {
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: [
      {
        parts: [
          {
            inlineData: {
              mimeType: "image/jpeg",
              data: base64Image.split(',')[1] || base64Image,
            },
          },
          {
            text: "Extract expense details from this receipt. Return the amount, category (one of: Food, Transport, Shopping, Bills, Entertainment, Health, Travel, Education, Other), date (ISO format), and a brief note about the merchant.",
          },
        ],
      },
    ],
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          amount: { type: Type.NUMBER },
          category: { type: Type.STRING },
          date: { type: Type.STRING },
          merchant: { type: Type.STRING },
          notes: { type: Type.STRING },
        },
        required: ["amount", "category", "date", "merchant"],
      },
    },
  });

  try {
    return JSON.parse(response.text);
  } catch (error) {
    console.error("Failed to parse AI response:", error);
    throw new Error("Could not read receipt clearly. Please enter manually.");
  }
};
