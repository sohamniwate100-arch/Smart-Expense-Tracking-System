import { useState, useEffect } from 'react';

export interface AppNotification {
  id: string;
  title: string;
  message: string;
  type: 'info' | 'warning' | 'success' | 'error';
  timestamp: string;
  read: boolean;
}

const STORAGE_KEY = 'app_notifications';

export const getNotifications = (): AppNotification[] => {
  const saved = localStorage.getItem(STORAGE_KEY);
  return saved ? JSON.parse(saved) : [];
};

export const addNotification = (notification: Omit<AppNotification, 'id' | 'timestamp' | 'read'>) => {
  const notifications = getNotifications();
  const newNotification: AppNotification = {
    ...notification,
    id: Math.random().toString(36).substr(2, 9),
    timestamp: new Date().toISOString(),
    read: false,
  };
  localStorage.setItem(STORAGE_KEY, JSON.stringify([newNotification, ...notifications].slice(0, 50)));
  window.dispatchEvent(new Event('notifications_updated'));
};

export const markAsRead = (id: string) => {
  const notifications = getNotifications().map(n => 
    n.id === id ? { ...n, read: true } : n
  );
  localStorage.setItem(STORAGE_KEY, JSON.stringify(notifications));
  window.dispatchEvent(new Event('notifications_updated'));
};

export const useNotifications = () => {
  const [notifications, setNotifications] = useState<AppNotification[]>(getNotifications());

  useEffect(() => {
    const update = () => setNotifications(getNotifications());
    window.addEventListener('notifications_updated', update);
    return () => window.removeEventListener('notifications_updated', update);
  }, []);

  return {
    notifications,
    unreadCount: notifications.filter(n => !n.read).length,
    markAsRead,
  };
};
