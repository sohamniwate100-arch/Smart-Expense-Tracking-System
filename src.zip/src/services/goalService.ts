import { 
  collection, 
  addDoc, 
  updateDoc, 
  deleteDoc, 
  doc,
  query, 
  where, 
  orderBy, 
  onSnapshot,
  Timestamp,
  serverTimestamp
} from 'firebase/firestore';
import { db, auth, handleFirestoreError, OperationType } from '../core/firebase';
import { FinancialGoal } from '../models/types';

const GOALS_COLLECTION = 'financial_goals';

export const addGoal = async (goal: Omit<FinancialGoal, 'id' | 'userId' | 'createdAt'>) => {
  const userId = auth.currentUser?.uid;
  if (!userId) throw new Error('User not authenticated');

  try {
    return await addDoc(collection(db, GOALS_COLLECTION), {
      ...goal,
      userId,
      deadline: Timestamp.fromDate(new Date(goal.deadline)),
      createdAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, GOALS_COLLECTION);
  }
};

export const updateGoal = async (id: string, goal: Partial<FinancialGoal>) => {
  const docRef = doc(db, GOALS_COLLECTION, id);
  try {
    const updateData: any = { ...goal };
    if (goal.deadline) {
      updateData.deadline = Timestamp.fromDate(new Date(goal.deadline));
    }
    await updateDoc(docRef, updateData);
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, `${GOALS_COLLECTION}/${id}`);
  }
};

export const deleteGoal = async (id: string) => {
  const docRef = doc(db, GOALS_COLLECTION, id);
  try {
    await deleteDoc(docRef);
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, `${GOALS_COLLECTION}/${id}`);
  }
};

export const subscribeToGoals = (callback: (goals: FinancialGoal[]) => void) => {
  const userId = auth.currentUser?.uid;
  if (!userId) return () => {};

  const q = query(
    collection(db, GOALS_COLLECTION),
    where('userId', '==', userId)
  );

  return onSnapshot(q, (snapshot) => {
    const goals = snapshot.docs.map(doc => {
      const data = doc.data();
      return {
        id: doc.id,
        ...data,
        deadline: (data.deadline as Timestamp).toDate().toISOString(),
        createdAt: data.createdAt ? (data.createdAt as Timestamp).toDate().toISOString() : undefined,
      } as FinancialGoal;
    });

    // Sort client-side to avoid missing index errors
    goals.sort((a, b) => {
      const dateA = a.createdAt ? new Date(a.createdAt).getTime() : 0;
      const dateB = b.createdAt ? new Date(b.createdAt).getTime() : 0;
      return dateB - dateA;
    });

    callback(goals);
  }, (error) => {
    handleFirestoreError(error, OperationType.LIST, GOALS_COLLECTION);
  });
};
