import { 
  collection, 
  addDoc, 
  updateDoc, 
  deleteDoc, 
  getDocs,
  doc, 
  query, 
  where, 
  orderBy, 
  onSnapshot,
  Timestamp,
  serverTimestamp
} from 'firebase/firestore';
import { db, auth, handleFirestoreError, OperationType } from '../core/firebase';
import { Expense } from '../models/types';

const EXPENSES_COLLECTION = 'expenses';

export const addExpense = async (expense: Omit<Expense, 'id' | 'userId' | 'createdAt'>) => {
  const userId = auth.currentUser?.uid;
  if (!userId) throw new Error('User not authenticated');

  try {
    const docRef = await addDoc(collection(db, EXPENSES_COLLECTION), {
      ...expense,
      userId,
      currency: expense.currency || 'INR',
      isTaxDeductible: expense.isTaxDeductible || false,
      date: Timestamp.fromDate(new Date(expense.date)),
      createdAt: serverTimestamp(),
    });
    return docRef.id;
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, EXPENSES_COLLECTION);
  }
};

export const updateExpense = async (id: string, expense: Partial<Expense>) => {
  const docRef = doc(db, EXPENSES_COLLECTION, id);
  try {
    const updateData: any = { ...expense };
    if (expense.date) {
      updateData.date = Timestamp.fromDate(new Date(expense.date));
    }
    await updateDoc(docRef, updateData);
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, `${EXPENSES_COLLECTION}/${id}`);
  }
};

export const deleteExpense = async (id: string) => {
  const docRef = doc(db, EXPENSES_COLLECTION, id);
  try {
    await deleteDoc(docRef);
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, `${EXPENSES_COLLECTION}/${id}`);
  }
};

export const deleteAllUserExpenses = async () => {
  const userId = auth.currentUser?.uid;
  if (!userId) throw new Error('User not authenticated');

  const q = query(
    collection(db, EXPENSES_COLLECTION),
    where('userId', '==', userId)
  );

  try {
    const querySnapshot = await getDocs(q);
    const deletePromises = querySnapshot.docs.map(doc => deleteDoc(doc.ref));
    await Promise.all(deletePromises);
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, EXPENSES_COLLECTION);
  }
};

export const subscribeToExpenses = (callback: (expenses: Expense[]) => void) => {
  const userId = auth.currentUser?.uid;
  if (!userId) return () => {};

  const q = query(
    collection(db, EXPENSES_COLLECTION),
    where('userId', '==', userId)
  );

  return onSnapshot(q, (snapshot) => {
    const expenses = snapshot.docs.map(doc => {
      const data = doc.data();
      return {
        id: doc.id,
        ...data,
        date: (data.date as Timestamp).toDate().toISOString(),
        createdAt: data.createdAt ? (data.createdAt as Timestamp).toDate().toISOString() : undefined,
      } as Expense;
    });
    
    // Sort client-side to avoid missing index errors
    expenses.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
    
    callback(expenses);
  }, (error) => {
    handleFirestoreError(error, OperationType.LIST, EXPENSES_COLLECTION);
  });
};
