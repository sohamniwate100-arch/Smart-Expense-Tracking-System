import { 
  collection, 
  addDoc, 
  updateDoc, 
  deleteDoc, 
  getDocs,
  doc, 
  query, 
  where, 
  orderBy, 
  onSnapshot,
  Timestamp,
  serverTimestamp,
  writeBatch
} from 'firebase/firestore';
import { db, auth, handleFirestoreError, OperationType } from '../core/firebase';
import { RecurringExpense, Expense, Frequency } from '../models/types';
import { addExpense } from './expenseService';

const RECURRING_COLLECTION = 'recurring_expenses';
const EXPENSES_COLLECTION = 'expenses';

export const addRecurringExpense = async (expense: Omit<RecurringExpense, 'id' | 'userId' | 'createdAt' | 'lastProcessedDate' | 'nextDueDate' | 'active'> & { date?: string }) => {
  const userId = auth.currentUser?.uid;
  if (!userId) throw new Error('User not authenticated');

  const nextDueDate = new Date(expense.startDate);
  
  try {
    // Omit 'date' if it exists in the expense object
    const { date, ...cleanExpense } = expense;
    
    const docRef = await addDoc(collection(db, RECURRING_COLLECTION), {
      ...cleanExpense,
      userId,
      currency: expense.currency || 'INR',
      isTaxDeductible: expense.isTaxDeductible || false,
      startDate: Timestamp.fromDate(new Date(expense.startDate)),
      nextDueDate: Timestamp.fromDate(nextDueDate),
      active: true,
      createdAt: serverTimestamp(),
    });
    return docRef.id;
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, RECURRING_COLLECTION);
  }
};

export const updateRecurringExpense = async (id: string, expense: Partial<RecurringExpense>) => {
  const docRef = doc(db, RECURRING_COLLECTION, id);
  try {
    const updateData: any = { ...expense };
    if (expense.startDate) {
      updateData.startDate = Timestamp.fromDate(new Date(expense.startDate));
    }
    if (expense.nextDueDate) {
      updateData.nextDueDate = Timestamp.fromDate(new Date(expense.nextDueDate));
    }
    if (expense.lastProcessedDate) {
      updateData.lastProcessedDate = Timestamp.fromDate(new Date(expense.lastProcessedDate));
    }
    await updateDoc(docRef, updateData);
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, `${RECURRING_COLLECTION}/${id}`);
  }
};

export const deleteRecurringExpense = async (id: string) => {
  const docRef = doc(db, RECURRING_COLLECTION, id);
  try {
    await deleteDoc(docRef);
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, `${RECURRING_COLLECTION}/${id}`);
  }
};

export const subscribeToRecurringExpenses = (callback: (expenses: RecurringExpense[]) => void) => {
  const userId = auth.currentUser?.uid;
  if (!userId) return () => {};

  const q = query(
    collection(db, RECURRING_COLLECTION),
    where('userId', '==', userId)
  );

  return onSnapshot(q, (snapshot) => {
    const expenses = snapshot.docs.map(doc => {
      const data = doc.data();
      return {
        id: doc.id,
        ...data,
        startDate: (data.startDate as Timestamp).toDate().toISOString(),
        nextDueDate: (data.nextDueDate as Timestamp).toDate().toISOString(),
        lastProcessedDate: data.lastProcessedDate ? (data.lastProcessedDate as Timestamp).toDate().toISOString() : undefined,
        createdAt: data.createdAt ? (data.createdAt as Timestamp).toDate().toISOString() : undefined,
      } as RecurringExpense;
    });

    // Sort client-side to avoid missing index errors
    expenses.sort((a, b) => {
      const dateA = a.createdAt ? new Date(a.createdAt).getTime() : 0;
      const dateB = b.createdAt ? new Date(b.createdAt).getTime() : 0;
      return dateB - dateA;
    });

    callback(expenses);
  }, (error) => {
    handleFirestoreError(error, OperationType.LIST, RECURRING_COLLECTION);
  });
};

export const processRecurringExpenses = async () => {
  const userId = auth.currentUser?.uid;
  if (!userId) return;

  const now = new Date();
  const q = query(
    collection(db, RECURRING_COLLECTION),
    where('userId', '==', userId),
    where('active', '==', true)
  );

  try {
    const snapshot = await getDocs(q);
    if (snapshot.empty) return;

    // Filter by due date client-side to avoid missing index errors
    const dueExpenses = snapshot.docs.filter(doc => {
      const data = doc.data();
      const nextDue = (data.nextDueDate as Timestamp).toDate();
      return nextDue <= now;
    });

    if (dueExpenses.length === 0) return;

    for (const docSnapshot of dueExpenses) {
      const recurring = docSnapshot.data() as RecurringExpense;
      const recurringId = docSnapshot.id;
      let nextDue = (recurring.nextDueDate as any as Timestamp).toDate();

      const batch = writeBatch(db);

      while (nextDue <= now) {
        // Add expense with deterministic ID to prevent duplicates
        const expenseId = `${recurringId}_${nextDue.getTime()}`;
        const expenseRef = doc(db, EXPENSES_COLLECTION, expenseId);
        
        batch.set(expenseRef, {
          userId,
          amount: recurring.amount,
          currency: recurring.currency || 'INR',
          category: recurring.category,
          notes: recurring.notes || `Recurring: ${recurring.frequency}`,
          date: Timestamp.fromDate(new Date(nextDue)),
          paymentMethod: recurring.paymentMethod,
          isRecurring: true,
          recurringId: recurringId,
          isTaxDeductible: recurring.isTaxDeductible || false,
          createdAt: serverTimestamp(),
        });

        // Calculate next due date
        const currentDue = new Date(nextDue);
        if (recurring.frequency === 'Daily') {
          nextDue.setDate(nextDue.getDate() + 1);
        } else if (recurring.frequency === 'Weekly') {
          nextDue.setDate(nextDue.getDate() + 7);
        } else if (recurring.frequency === 'Monthly') {
          nextDue.setMonth(nextDue.getMonth() + 1);
        }

        // Update recurring doc
        batch.update(docSnapshot.ref, {
          lastProcessedDate: Timestamp.fromDate(currentDue),
          nextDueDate: Timestamp.fromDate(new Date(nextDue)),
        });
      }

      await batch.commit();
    }
  } catch (error) {
    console.error('Error processing recurring expenses:', error);
  }
};
