import { addExpense } from './expenseService';
import { Category } from '../models/types';

export const importFromCSV = async (file: File): Promise<number> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = async (e) => {
      const text = e.target?.result as string;
      const lines = text.split('\n');
      const headers = lines[0].split(',');
      
      let count = 0;
      for (let i = 1; i < lines.length; i++) {
        const line = lines[i].trim();
        if (!line) continue;
        
        const values = line.split(',');
        const expense = {
          date: new Date(values[0]).toISOString(),
          category: (values[1] as Category) || 'Other',
          amount: parseFloat(values[2]),
          paymentMethod: (values[3] as 'Online' | 'Cash') || 'Online',
          notes: values[4] || 'Imported from CSV',
          currency: 'INR',
        };

        if (!isNaN(expense.amount)) {
          await addExpense(expense);
          count++;
        }
      }
      resolve(count);
    };
    reader.onerror = reject;
    reader.readAsText(file);
  });
};
