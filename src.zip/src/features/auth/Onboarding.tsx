import React, { useState } from 'react';
import { useAuth } from '../../core/AuthContext';
import { db, handleFirestoreError, OperationType } from '../../core/firebase';
import { doc, setDoc, updateDoc, serverTimestamp } from 'firebase/firestore';
import { Button } from '../../widgets/Button';
import { motion, AnimatePresence } from 'motion/react';
import { Target, Briefcase, DollarSign, Calendar, TrendingUp, CreditCard, ChevronRight, ChevronLeft, Globe } from 'lucide-react';

import { fetchExchangeRates, SUPPORTED_CURRENCIES } from '../../services/currencyService';

const FINANCIAL_GOALS = [
  { id: 'emergency', label: 'Build Emergency Fund', emoji: '🏦' },
  { id: 'home', label: 'Buy a Home', emoji: '🏠' },
  { id: 'car', label: 'Buy a Car', emoji: '🚗' },
  { id: 'travel', label: 'Travel / Vacation', emoji: '✈️' },
  { id: 'retirement', label: 'Retirement Savings', emoji: '🌅' },
  { id: 'investments', label: 'Grow Investments', emoji: '📈' },
  { id: 'debt', label: 'Become Debt Free', emoji: '💳' },
  { id: 'education', label: 'Education Fund', emoji: '📚' },
  { id: 'business', label: 'Expand Business', emoji: '🏢' },
  { id: 'other', label: 'Other', emoji: '🎯' },
];

const PROFESSIONS = ['Job', 'Student', 'Business Owner', 'Freelancer'];

const JOB_TYPES = ['Part-time', 'Full-time', 'Weekend'];
const STUDENT_LEVELS = ['School going', 'HSC', 'Polytechnic', 'Graduation', 'Post Graduation'];
const BUSINESS_TYPES = ['Online Business', 'Offline Business'];

export const Onboarding: React.FC = () => {
  const { user, profile } = useAuth();
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  
  const [formData, setFormData] = useState({
    profession: 'Job' as any,
    jobType: '' as any,
    studentLevel: '' as any,
    businessType: '' as any,
    businessDescription: '',
    businessCategory: '' as any,
    income: '',
    currency: 'INR',
    age: '',
    dailySpendingGoal: '',
    monthlySpendingGoal: '',
    hasDebt: false,
    debtAmount: '',
    financialGoal: '',
  });

  const categorizeBusiness = (description: string): 'B2B' | 'B2C' | 'C2C' | 'C2B' => {
    const desc = description.toLowerCase();
    if (desc.includes('business to business') || desc.includes('b2b') || desc.includes('corporate') || desc.includes('enterprise') || desc.includes('wholesale') || desc.includes('agency')) return 'B2B';
    if (desc.includes('customer to customer') || desc.includes('c2c') || desc.includes('marketplace') || desc.includes('peer to peer') || desc.includes('p2p') || desc.includes('resell')) return 'C2C';
    if (desc.includes('customer to business') || desc.includes('c2b') || desc.includes('influencer') || desc.includes('affiliate') || desc.includes('review')) return 'C2B';
    return 'B2C';
  };

  const handleNext = () => {
    // Validation for each step
    if (step === 1) {
      if (!formData.age || parseInt(formData.age) <= 0) {
        setError('Please enter a valid age to continue.');
        return;
      }
    } else if (step === 1.1) {
      if (formData.profession === 'Job' && !formData.jobType) {
        setError('Please select your job type.');
        return;
      }
      if (formData.profession === 'Student' && !formData.studentLevel) {
        setError('Please select your education level.');
        return;
      }
      if (formData.profession === 'Business Owner' && !formData.businessType) {
        setError('Please select your business type.');
        return;
      }
    } else if (step === 1.2) {
      if (formData.profession === 'Business Owner' && !formData.businessDescription) {
        setError('Please describe your business.');
        return;
      }
      // Auto-categorize business
      if (formData.profession === 'Business Owner') {
        const category = categorizeBusiness(formData.businessDescription);
        setFormData(prev => ({ ...prev, businessCategory: category }));
      }
    } else if (step === 2) {
      if (!formData.income || parseFloat(formData.income) < 0) {
        setError('Please enter your monthly income/revenue.');
        return;
      }
      if (!formData.dailySpendingGoal || !formData.monthlySpendingGoal) {
        setError('Please set your spending goals.');
        return;
      }
    } else if (step === 3) {
      if (formData.hasDebt && (!formData.debtAmount || parseFloat(formData.debtAmount) <= 0)) {
        setError('Please enter your debt amount.');
        return;
      }
    }
    setError('');

    // Determine next step
    if (step === 1) {
      if (formData.profession === 'Freelancer') setStep(2);
      else setStep(1.1);
    } else if (step === 1.1) {
      if (formData.profession === 'Business Owner') setStep(1.2);
      else setStep(2);
    } else if (step === 1.2) {
      setStep(2);
    } else {
      setStep(s => s + 1);
    }
  };

  const handleBack = () => {
    if (step === 2) {
      if (formData.profession === 'Freelancer') setStep(1);
      else if (formData.profession === 'Business Owner') setStep(1.2);
      else setStep(1.1);
    } else if (step === 1.2) {
      setStep(1.1);
    } else if (step === 1.1) {
      setStep(1);
    } else {
      setStep(s => s - 1);
    }
  };

  const handleSubmit = async () => {
    if (!user) return;
    if (!formData.financialGoal) {
      setError('Please select a financial goal to finish.');
      return;
    }
    setLoading(true);
    setError('');
    try {
      const data: any = {
        ...formData,
        income: parseFloat(formData.income) || 0,
        age: parseInt(formData.age) || 0,
        dailySpendingGoal: parseFloat(formData.dailySpendingGoal) || 0,
        monthlySpendingGoal: parseFloat(formData.monthlySpendingGoal) || 0,
        debtAmount: parseFloat(formData.debtAmount) || 0,
        onboardingCompleted: true,
      };

      const userPath = `users/${user.uid}`;
      if (!profile) {
        // If profile doesn't exist, create it with all required fields
        try {
          await setDoc(doc(db, 'users', user.uid), {
            ...data,
            uid: user.uid,
            email: user.email || '',
            displayName: user.displayName || user.email?.split('@')[0] || 'User',
            createdAt: serverTimestamp(),
            role: 'user', // Default role
          });
        } catch (err) {
          handleFirestoreError(err, OperationType.CREATE, userPath);
        }
      } else {
        // If profile exists, just update the onboarding data
        try {
          await updateDoc(doc(db, 'users', user.uid), data);
        } catch (err) {
          handleFirestoreError(err, OperationType.UPDATE, userPath);
        }
      }
    } catch (err: any) {
      console.error('Onboarding error:', err);
      let message = err.message;
      try {
        // Try to parse JSON error from handleFirestoreError
        const parsed = JSON.parse(err.message);
        message = parsed.error || 'Permission denied';
      } catch (e) {
        // Not a JSON error
      }
      setError(message || 'Failed to complete setup. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-transparent flex flex-col items-center p-4 font-sans overflow-y-auto">
      <div className="w-full max-w-md my-auto py-8">
        <div className="mb-8 flex justify-between items-center">
          <div className="flex gap-1">
            {[1, 1.1, 1.2, 2, 3, 4].map(s => {
              // Hide business-only steps if not a business owner
              if (s === 1.2 && formData.profession !== 'Business Owner') return null;
              // Hide conditional steps if freelancer
              if (s === 1.1 && formData.profession === 'Freelancer') return null;
              
              const isActive = s <= step;
              return (
                <div 
                  key={s} 
                  className={`h-1 w-4 rounded-full transition-all duration-500 ${isActive ? 'bg-linear-to-r from-emerald-500 to-cyan-500 dark:from-neon dark:to-emerald-400 w-8' : 'bg-zinc-200 dark:bg-zinc-800'}`} 
                />
              );
            })}
          </div>
          <span className="text-[9px] font-bold text-zinc-400 uppercase tracking-[0.2em] shimmer-text">Step {Math.floor(step)} of 4</span>
        </div>

        <AnimatePresence mode="wait">
          {step === 1 && (
            <motion.div
              key="step1"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="glass-card p-8 rounded-[3rem] space-y-6"
            >
              <div className="space-y-2">
                <h1 className="text-2xl font-bold tracking-tight leading-tight gradient-text shimmer-text">Tell us about yourself</h1>
                <p className="text-zinc-500 dark:text-zinc-400 text-sm leading-relaxed shimmer-text">This helps us personalize your financial experience.</p>
              </div>

              <div className="space-y-5">
                <div>
                  <label className="block text-[9px] font-bold text-zinc-400 uppercase tracking-[0.2em] mb-3 shimmer-text">Profession</label>
                  <div className="grid grid-cols-2 gap-2">
                    {PROFESSIONS.map(p => (
                      <button
                        key={p}
                        onClick={() => setFormData({ ...formData, profession: p as any })}
                        className={`p-4 rounded-2xl border-2 transition-all duration-300 text-xs font-bold flex flex-col items-center gap-2 ${
                          formData.profession === p 
                            ? 'border-zinc-900 bg-zinc-900 text-white dark:border-neon dark:bg-neon dark:text-zinc-950 shadow-lg' 
                            : 'border-zinc-100 bg-white text-zinc-500 hover:border-zinc-200 dark:bg-zinc-900 dark:border-zinc-800 dark:text-zinc-400'
                        }`}
                      >
                        <span className="text-xl">{p === 'Business Owner' ? '🏢' : p === 'Freelancer' ? '💻' : p === 'Student' ? '🎓' : '💼'}</span>
                        <span className="tracking-tight shimmer-text">{p}</span>
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-[9px] font-bold text-zinc-400 uppercase tracking-[0.2em] mb-3 shimmer-text">Age</label>
                  <div className="relative group">
                    <Calendar className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-400 group-focus-within:text-zinc-900 dark:group-focus-within:text-neon transition-colors" />
                    <input
                      type="text"
                      inputMode="numeric"
                      pattern="[0-9]*"
                      value={formData.age}
                      onChange={e => {
                        const val = e.target.value.replace(/[^0-9]/g, '');
                        setFormData({ ...formData, age: val });
                      }}
                      className="w-full pl-12 pr-4 py-3.5 bg-white dark:bg-zinc-900 border border-zinc-100 dark:border-zinc-800 rounded-xl focus:outline-none focus:ring-4 focus:ring-zinc-900/5 dark:focus:ring-neon/5 focus:border-zinc-900 dark:focus:border-neon transition-all text-base font-medium text-zinc-900 dark:text-white"
                      placeholder="Your age"
                    />
                  </div>
                </div>
              </div>

              {error && (
                <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} className="p-3 bg-red-50 dark:bg-red-500/10 text-red-600 dark:text-red-400 text-xs rounded-xl border border-red-100 dark:border-red-500/20 font-medium">
                  {error}
                </motion.div>
              )}

              <Button onClick={handleNext} className="w-full py-4 text-base rounded-xl">
                Continue <ChevronRight className="w-4 h-4 ml-1" />
              </Button>
            </motion.div>
          )}

          {step === 1.1 && (
            <motion.div
              key="step1.1"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="glass-card p-8 rounded-[3rem] space-y-6"
            >
              <div className="space-y-2">
                <h1 className="text-2xl font-bold tracking-tight leading-tight gradient-text shimmer-text">
                  {formData.profession === 'Job' ? 'Job Details' : 
                   formData.profession === 'Student' ? 'Education Level' : 
                   'Business Type'}
                </h1>
                <p className="text-zinc-500 dark:text-zinc-400 text-sm leading-relaxed shimmer-text">Tell us more about your current status.</p>
              </div>

              <div className="space-y-3">
                <div className="grid grid-cols-1 gap-2">
                  {formData.profession === 'Job' && JOB_TYPES.map(type => (
                    <button
                      key={type}
                      onClick={() => setFormData({ ...formData, jobType: type as any })}
                      className={`p-4 rounded-xl border-2 transition-all duration-300 text-left font-bold flex items-center justify-between ${
                        formData.jobType === type 
                          ? 'border-zinc-900 bg-zinc-900 text-white dark:border-neon dark:bg-neon dark:text-zinc-950 shadow-lg' 
                          : 'border-zinc-100 bg-white text-zinc-500 hover:border-zinc-200 dark:bg-zinc-900 dark:border-zinc-800 dark:text-zinc-400'
                      }`}
                    >
                      <span className="tracking-tight text-sm shimmer-text">{type}</span>
                      {formData.jobType === type && <ChevronRight className="w-4 h-4" />}
                    </button>
                  ))}

                  {formData.profession === 'Student' && STUDENT_LEVELS.map(level => (
                    <button
                      key={level}
                      onClick={() => setFormData({ ...formData, studentLevel: level as any })}
                      className={`p-4 rounded-xl border-2 transition-all duration-300 text-left font-bold flex items-center justify-between ${
                        formData.studentLevel === level 
                          ? 'border-zinc-900 bg-zinc-900 text-white dark:border-neon dark:bg-neon dark:text-zinc-950 shadow-lg' 
                          : 'border-zinc-100 bg-white text-zinc-500 hover:border-zinc-200 dark:bg-zinc-900 dark:border-zinc-800 dark:text-zinc-400'
                      }`}
                    >
                      <span className="tracking-tight text-sm shimmer-text">{level}</span>
                      {formData.studentLevel === level && <ChevronRight className="w-4 h-4" />}
                    </button>
                  ))}

                  {formData.profession === 'Business Owner' && BUSINESS_TYPES.map(type => (
                    <button
                      key={type}
                      onClick={() => setFormData({ ...formData, businessType: type as any })}
                      className={`p-4 rounded-xl border-2 transition-all duration-300 text-left font-bold flex items-center justify-between ${
                        formData.businessType === type 
                          ? 'border-zinc-900 bg-zinc-900 text-white dark:border-neon dark:bg-neon dark:text-zinc-950 shadow-lg' 
                          : 'border-zinc-100 bg-white text-zinc-500 hover:border-zinc-200 dark:bg-zinc-900 dark:border-zinc-800 dark:text-zinc-400'
                      }`}
                    >
                      <span className="tracking-tight text-sm shimmer-text">{type}</span>
                      {formData.businessType === type && <ChevronRight className="w-4 h-4" />}
                    </button>
                  ))}
                </div>
              </div>

              {error && (
                <div className="p-3 bg-red-50 dark:bg-red-500/10 text-red-600 dark:text-red-400 text-xs rounded-xl border border-red-100 dark:border-red-500/20 font-medium">
                  {error}
                </div>
              )}

              <div className="flex gap-2">
                <Button variant="ghost" onClick={handleBack} className="flex-1 py-4 rounded-xl">
                  <ChevronLeft className="w-4 h-4 mr-1" /> Back
                </Button>
                <Button onClick={handleNext} className="flex-[2] py-4 text-base rounded-xl">
                  Continue <ChevronRight className="w-4 h-4 ml-1" />
                </Button>
              </div>
            </motion.div>
          )}

          {step === 1.2 && (
            <motion.div
              key="step1.2"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="glass-card p-8 rounded-[3rem] space-y-6"
            >
              <div className="space-y-2">
                <h1 className="text-2xl font-bold tracking-tight leading-tight gradient-text shimmer-text">Business Details</h1>
                <p className="text-zinc-500 dark:text-zinc-400 text-sm leading-relaxed shimmer-text">Briefly describe what your business does.</p>
              </div>

              <div className="space-y-3">
                <textarea
                  value={formData.businessDescription}
                  onChange={e => setFormData({ ...formData, businessDescription: e.target.value })}
                  className="w-full p-4 bg-white dark:bg-zinc-900 border border-zinc-100 dark:border-zinc-800 rounded-3xl focus:outline-none focus:ring-4 focus:ring-zinc-900/5 dark:focus:ring-neon/5 focus:border-zinc-900 dark:focus:border-neon transition-all text-base font-medium min-h-[150px] resize-none text-zinc-900 dark:text-white"
                  placeholder="e.g. I run an online store selling handmade jewelry directly to customers..."
                />
                <p className="text-[10px] text-zinc-400 font-medium px-2">Our AI will automatically categorize your business model (B2B, B2C, etc.) based on your description.</p>
              </div>

              {error && (
                <div className="p-3 bg-red-50 dark:bg-red-500/10 text-red-600 dark:text-red-400 text-xs rounded-xl border border-red-100 dark:border-red-500/20 font-medium">
                  {error}
                </div>
              )}

              <div className="flex gap-2">
                <Button variant="ghost" onClick={handleBack} className="flex-1 py-4 rounded-xl">
                  <ChevronLeft className="w-4 h-4 mr-1" /> Back
                </Button>
                <Button onClick={handleNext} className="flex-[2] py-4 text-base rounded-xl">
                  Continue <ChevronRight className="w-4 h-4 ml-1" />
                </Button>
              </div>
            </motion.div>
          )}

          {step === 2 && (
            <motion.div
              key="step2"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="glass-card p-8 rounded-[3rem] space-y-6"
            >
              <div className="space-y-2">
                <h1 className="text-2xl font-bold tracking-tight leading-tight gradient-text shimmer-text">Financial Overview</h1>
                <p className="text-zinc-500 dark:text-zinc-400 text-sm leading-relaxed shimmer-text">Your income and spending habits.</p>
              </div>

              <div className="space-y-5">
                <div>
                  <label className="block text-[9px] font-bold text-zinc-400 uppercase tracking-[0.2em] mb-3 shimmer-text">Preferred Currency</label>
                  <div className="relative group">
                    <Globe className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-400 group-focus-within:text-zinc-900 dark:group-focus-within:text-neon transition-colors" />
                    <select
                      value={formData.currency}
                      onChange={e => setFormData({ ...formData, currency: e.target.value })}
                      className="w-full pl-12 pr-10 py-4 bg-white dark:bg-zinc-900 border border-zinc-100 dark:border-zinc-800 rounded-2xl focus:outline-none focus:ring-4 focus:ring-zinc-900/5 dark:focus:ring-neon/5 focus:border-zinc-900 dark:focus:border-neon transition-all appearance-none font-bold text-base text-zinc-900 dark:text-white"
                    >
                      {SUPPORTED_CURRENCIES.map(c => (
                        <option key={c.code} value={c.code}>{c.code} – {c.name}</option>
                      ))}
                    </select>
                    <div className="absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none">
                      <ChevronRight className="w-4 h-4 text-zinc-400 rotate-90" />
                    </div>
                  </div>
                </div>

                <div>
                  <label className="block text-[9px] font-bold text-zinc-400 uppercase tracking-[0.2em] mb-3 shimmer-text">
                    {formData.profession === 'Student' ? 'Monthly Pocket Money' : 
                     formData.profession === 'Job' ? 'Monthly Salary' :
                     formData.profession === 'Freelancer' ? 'Monthly Deal/Contract Payment' :
                     'Monthly Revenue'}
                  </label>
                  <div className="relative group">
                    <DollarSign className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-400 group-focus-within:text-zinc-900 dark:group-focus-within:text-neon transition-colors" />
                    <input
                      type="number"
                      value={formData.income}
                      onChange={e => setFormData({ ...formData, income: e.target.value })}
                      className="w-full pl-12 pr-4 py-4 bg-white dark:bg-zinc-900 border border-zinc-100 dark:border-zinc-800 rounded-2xl focus:outline-none focus:ring-4 focus:ring-zinc-900/5 dark:focus:ring-neon/5 focus:border-zinc-900 dark:focus:border-neon transition-all text-xl font-bold tracking-tight text-zinc-900 dark:text-white"
                      placeholder="0.00"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[9px] font-bold text-zinc-400 uppercase tracking-[0.2em] mb-3 shimmer-text">Daily Budget</label>
                    <input
                      type="number"
                      value={formData.dailySpendingGoal}
                      onChange={e => setFormData({ ...formData, dailySpendingGoal: e.target.value })}
                      className="w-full px-4 py-4 bg-white dark:bg-zinc-900 border border-zinc-100 dark:border-zinc-800 rounded-2xl focus:outline-none focus:ring-4 focus:ring-zinc-900/5 dark:focus:ring-neon/5 focus:border-zinc-900 dark:focus:border-neon transition-all text-base font-medium text-zinc-900 dark:text-white"
                      placeholder="Daily"
                    />
                  </div>
                  <div>
                    <label className="block text-[9px] font-bold text-zinc-400 uppercase tracking-[0.2em] mb-3 shimmer-text">Monthly Avg</label>
                    <input
                      type="number"
                      value={formData.monthlySpendingGoal}
                      onChange={e => setFormData({ ...formData, monthlySpendingGoal: e.target.value })}
                      className="w-full px-4 py-4 bg-white dark:bg-zinc-900 border border-zinc-100 dark:border-zinc-800 rounded-2xl focus:outline-none focus:ring-4 focus:ring-zinc-900/5 dark:focus:ring-neon/5 focus:border-zinc-900 dark:focus:border-neon transition-all text-base font-medium text-zinc-900 dark:text-white"
                      placeholder="Monthly"
                    />
                  </div>
                </div>
              </div>

              {error && (
                <div className="p-3 bg-red-50 dark:bg-red-500/10 text-red-600 dark:text-red-400 text-xs rounded-xl border border-red-100 dark:border-red-500/20 font-medium">
                  {error}
                </div>
              )}

              <div className="flex gap-2">
                <Button variant="ghost" onClick={handleBack} className="flex-1 py-4 rounded-xl">
                  <ChevronLeft className="w-4 h-4 mr-1" /> Back
                </Button>
                <Button onClick={handleNext} className="flex-[2] py-4 text-base rounded-xl">
                  Continue <ChevronRight className="w-4 h-4 ml-1" />
                </Button>
              </div>
            </motion.div>
          )}

          {step === 3 && (
            <motion.div
              key="step3"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="glass-card p-8 rounded-[3rem] space-y-6"
            >
              <div className="space-y-2">
                <h1 className="text-2xl font-bold tracking-tight leading-tight gradient-text shimmer-text">Any ongoing debt?</h1>
                <p className="text-zinc-500 dark:text-zinc-400 text-sm leading-relaxed shimmer-text">We'll help you manage and clear it.</p>
              </div>

              <div className="space-y-5">
                <div className="flex gap-2">
                  <button
                    onClick={() => setFormData({ ...formData, hasDebt: false, debtAmount: '' })}
                    className={`flex-1 p-6 rounded-3xl border-2 transition-all duration-300 text-center ${
                      !formData.hasDebt 
                        ? 'border-zinc-900 bg-zinc-900 text-white dark:border-neon dark:bg-neon dark:text-zinc-950 shadow-xl' 
                        : 'border-zinc-100 bg-white text-zinc-500 dark:bg-zinc-900 dark:border-zinc-800 dark:text-zinc-400'
                    }`}
                  >
                    <span className="block text-2xl mb-1.5">✅</span>
                    <span className="font-bold tracking-tight text-xs shimmer-text">No Debt</span>
                  </button>
                  <button
                    onClick={() => setFormData({ ...formData, hasDebt: true })}
                    className={`flex-1 p-6 rounded-3xl border-2 transition-all duration-300 text-center ${
                      formData.hasDebt 
                        ? 'border-zinc-900 bg-zinc-900 text-white dark:border-neon dark:bg-neon dark:text-zinc-950 shadow-xl' 
                        : 'border-zinc-100 bg-white text-zinc-500 dark:bg-zinc-900 dark:border-zinc-800 dark:text-zinc-400'
                    }`}
                  >
                    <span className="block text-2xl mb-1.5">💸</span>
                    <span className="font-bold tracking-tight text-xs shimmer-text">Yes, I have</span>
                  </button>
                </div>

                {formData.hasDebt && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                  >
                    <label className="block text-[9px] font-bold text-zinc-400 uppercase tracking-[0.2em] mb-3 shimmer-text">Total Debt Amount</label>
                    <div className="relative group">
                      <CreditCard className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-400 group-focus-within:text-zinc-900 dark:group-focus-within:text-neon transition-colors" />
                      <input
                        type="number"
                        value={formData.debtAmount}
                        onChange={e => setFormData({ ...formData, debtAmount: e.target.value })}
                        className="w-full pl-12 pr-4 py-4 bg-white dark:bg-zinc-900 border border-zinc-100 dark:border-zinc-800 rounded-2xl focus:outline-none focus:ring-4 focus:ring-zinc-900/5 dark:focus:ring-neon/5 focus:border-zinc-900 dark:focus:border-neon transition-all text-xl font-bold tracking-tight text-zinc-900 dark:text-white"
                        placeholder="0.00"
                      />
                    </div>
                  </motion.div>
                )}
              </div>

              {error && (
                <div className="p-3 bg-red-50 dark:bg-red-500/10 text-red-600 dark:text-red-400 text-xs rounded-xl border border-red-100 dark:border-red-500/20 font-medium">
                  {error}
                </div>
              )}

              <div className="flex gap-2">
                <Button variant="ghost" onClick={handleBack} className="flex-1 py-4 rounded-xl">
                  <ChevronLeft className="w-4 h-4 mr-1" /> Back
                </Button>
                <Button onClick={handleNext} className="flex-[2] py-4 text-base rounded-xl">
                  Continue <ChevronRight className="w-4 h-4 ml-1" />
                </Button>
              </div>
            </motion.div>
          )}

          {step === 4 && (
            <motion.div
              key="step4"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="glass-card p-8 rounded-[3rem] space-y-6"
            >
              <div className="bg-linear-to-br from-zinc-900 to-zinc-700 dark:from-neon dark:to-emerald-400 p-6 rounded-3xl text-white dark:text-zinc-950 shadow-2xl mb-6">
                <div className="flex items-center gap-3 mb-3">
                  <div className="w-10 h-10 bg-white/20 dark:bg-zinc-900/10 rounded-full flex items-center justify-center">
                    <Target className="w-6 h-6" />
                  </div>
                  <h2 className="text-xl font-bold tracking-tight shimmer-text">Financial Goals</h2>
                </div>
                <p className="text-zinc-300 dark:text-zinc-800 text-sm leading-relaxed shimmer-text">Setting goals helps you stay motivated and focused on what matters.</p>
              </div>

              <div className="space-y-5">
                <label className="block text-[9px] font-bold text-zinc-400 uppercase tracking-[0.2em] mb-3 shimmer-text">Primary Financial Goal</label>
                <div className="relative group">
                  <select
                    value={formData.financialGoal}
                    onChange={e => setFormData({ ...formData, financialGoal: e.target.value })}
                    className="w-full pl-12 pr-10 py-4 bg-white dark:bg-zinc-900 border border-zinc-100 dark:border-zinc-800 rounded-2xl focus:outline-none focus:ring-4 focus:ring-zinc-900/5 dark:focus:ring-neon/5 focus:border-zinc-900 dark:focus:border-neon transition-all appearance-none font-bold text-base text-zinc-900 dark:text-white"
                  >
                    <option value="">Select your main goal</option>
                    {FINANCIAL_GOALS
                      .filter(goal => formData.hasDebt || goal.id !== 'debt')
                      .map(goal => (
                        <option key={goal.id} value={goal.label}>
                          {goal.emoji} {goal.label}
                        </option>
                      ))}
                  </select>
                  <Target className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-400 group-focus-within:text-zinc-900 dark:group-focus-within:text-neon transition-colors" />
                  <div className="absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none">
                    <ChevronRight className="w-4 h-4 text-zinc-400 rotate-90" />
                  </div>
                </div>
              </div>

              {error && (
                <div className="p-3 bg-red-50 dark:bg-red-500/10 text-red-600 dark:text-red-400 text-xs rounded-xl border border-red-100 dark:border-red-500/20 font-medium">
                  {error}
                </div>
              )}

              <div className="flex gap-2 pt-2">
                <Button variant="ghost" onClick={handleBack} className="flex-1 py-4 rounded-xl">
                  <ChevronLeft className="w-4 h-4 mr-1" /> Back
                </Button>
                <Button onClick={handleSubmit} className="flex-[2] py-4 text-base rounded-xl" isLoading={loading}>
                  Finish Setup <TrendingUp className="w-4 h-4 ml-1" />
                </Button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
};
