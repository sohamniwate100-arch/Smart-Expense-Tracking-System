import React, { useState } from 'react';
import { signInWithEmailAndPassword } from 'firebase/auth';
import { auth } from '../../core/firebase';
import { Button } from '../../widgets/Button';
import { motion } from 'motion/react';

interface LoginProps {
  onToggle: () => void;
}

export const Login: React.FC<LoginProps> = ({ onToggle }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    try {
      await signInWithEmailAndPassword(auth, email, password);
    } catch (err: any) {
      setError(err.message || 'Failed to login');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="w-full max-w-md mx-auto">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="glass-card p-8 rounded-[3rem] text-zinc-900 dark:text-white relative overflow-hidden"
      >
        <div className="mb-8 text-center">
          <div className="w-12 h-12 bg-linear-to-br from-zinc-900 to-zinc-700 dark:from-neon dark:to-emerald-400 rounded-2xl flex items-center justify-center shadow-xl mx-auto mb-4">
            <span className="text-white dark:text-zinc-950 font-bold text-2xl leading-none">$</span>
          </div>
          <h2 className="text-2xl font-bold tracking-tight shimmer-text">Welcome Back</h2>
          <p className="text-zinc-500 dark:text-zinc-400 text-xs mt-1 shimmer-text">Sign in to track your expenses</p>
        </div>

        <form onSubmit={handleLogin} className="space-y-3.5">
          <div>
            <label className="block text-[8px] font-bold text-zinc-400 uppercase tracking-[0.2em] mb-1 px-1 shimmer-text">Email Address</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full px-3.5 py-2.5 bg-zinc-50 dark:bg-zinc-950 border border-zinc-100 dark:border-zinc-800 rounded-xl focus:outline-none focus:ring-2 focus:ring-zinc-900/5 dark:focus:ring-neon/5 focus:border-zinc-900 dark:focus:border-neon transition-all text-xs font-medium text-zinc-900 dark:text-white"
              placeholder="name@example.com"
              required
            />
          </div>
          <div>
            <label className="block text-[8px] font-bold text-zinc-400 uppercase tracking-[0.2em] mb-1 px-1 shimmer-text">Password</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full px-3.5 py-2.5 bg-zinc-50 dark:bg-zinc-950 border border-zinc-100 dark:border-zinc-800 rounded-xl focus:outline-none focus:ring-2 focus:ring-zinc-900/5 dark:focus:ring-neon/5 focus:border-zinc-900 dark:focus:border-neon transition-all text-xs font-medium text-zinc-900 dark:text-white"
              placeholder="••••••••"
              required
            />
          </div>

          {error && (
            <div className="p-2.5 bg-red-50 dark:bg-red-500/10 text-red-600 dark:text-red-400 text-[9px] rounded-xl border border-red-100 dark:border-red-500/20 font-medium">
              {error}
            </div>
          )}

          <Button type="submit" className="w-full py-3 text-sm rounded-xl mt-0.5" isLoading={loading}>
            <span className="shimmer-text">Sign In</span>
          </Button>
        </form>

        <div className="mt-5 text-center">
          <p className="text-zinc-500 dark:text-zinc-400 text-[10px] shimmer-text">
            Don't have an account?{' '}
            <button onClick={onToggle} className="text-zinc-900 dark:text-neon font-bold hover:underline shimmer-text">
              Sign Up
            </button>
          </p>
        </div>
      </motion.div>
    </div>
  );
};
