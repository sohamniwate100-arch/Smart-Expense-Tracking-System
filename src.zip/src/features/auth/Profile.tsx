import React, { useEffect, useState } from 'react';
import { useAuth } from '../../core/AuthContext';
import { db, auth } from '../../core/firebase';
import { doc, getDoc, updateDoc, deleteDoc } from 'firebase/firestore';
import { updateProfile, signOut, deleteUser, EmailAuthProvider, reauthenticateWithCredential } from 'firebase/auth';
import { motion, AnimatePresence } from 'motion/react';
import { 
  User, 
  Mail, 
  Calendar, 
  LogOut, 
  Edit2, 
  Check, 
  Briefcase, 
  DollarSign, 
  CreditCard, 
  ChevronRight, 
  Globe, 
  Bell, 
  Lock, 
  Settings, 
  HelpCircle, 
  Info, 
  Activity, 
  TrendingUp,
  Target,
  X,
  Trash2,
  AlertTriangle,
  FileText,
  Download
} from 'lucide-react';
import { Expense } from '../../models/types';
import { deleteAllUserExpenses } from '../../services/expenseService';
import { addNotification } from '../../services/notificationService';
import { useCurrency } from '../../hooks/useCurrency';
import { AnimatedNumber } from '../../widgets/AnimatedNumber';

interface ProfileProps {
  expenses: Expense[];
}

export const Profile: React.FC<ProfileProps> = ({ expenses }) => {
  const { user, profile } = useAuth();
  const [profileData, setProfileData] = useState<any>(profile);
  const [loading, setLoading] = useState(!profile);
  const [isEditing, setIsEditing] = useState(false);
  const [isBudgeting, setIsBudgeting] = useState(false);
  const [editData, setEditData] = useState({
    displayName: profile?.displayName || '',
    profession: (profile?.profession || 'Job') as 'Job' | 'Student' | 'Business Owner' | 'Freelancer',
    income: profile?.income || 0,
    age: profile?.age || 0,
    currency: profile?.currency || 'INR',
    monthlySpendingGoal: profile?.monthlySpendingGoal || 0,
  });
  const [budgetData, setBudgetData] = useState<Record<string, number>>(profile?.budgets || {});
  const [updating, setUpdating] = useState(false);
  
  // Account Deletion state
  const [deleteStep, setDeleteStep] = useState(0); // 0: none, 1: first confirm, 2: second confirm
  const [deleting, setDeleting] = useState(false);
  const [deleteError, setDeleteError] = useState<string | null>(null);

  const [reauthPassword, setReauthPassword] = useState('');
  const [showReauth, setShowReauth] = useState(false);

  // Preferences state
  const [reminders, setReminders] = useState(true);
  const [alerts, setAlerts] = useState(true);

  const { format, SUPPORTED_CURRENCIES } = useCurrency();

  useEffect(() => {
    const fetchProfile = async () => {
      if (!user) return;
      try {
        const docRef = doc(db, 'users', user.uid);
        const docSnap = await getDoc(docRef);
        if (docSnap.exists()) {
          const data = docSnap.data();
          setProfileData(data);
          setEditData({
            displayName: data.displayName,
            profession: (data.profession || 'Job') as 'Job' | 'Student' | 'Business Owner' | 'Freelancer',
            income: data.income || 0,
            age: data.age || 0,
            currency: data.currency || 'INR',
            monthlySpendingGoal: data.monthlySpendingGoal || 0,
          });
        }
      } catch (error) {
        console.error('Error fetching profile:', error);
      } finally {
        setLoading(false);
      }
    };

    if (!profile) {
      fetchProfile();
    } else {
      setProfileData(profile);
      setEditData({
        displayName: profile.displayName,
        profession: (profile.profession || 'Job') as 'Job' | 'Student' | 'Business Owner' | 'Freelancer',
        income: profile.income || 0,
        age: profile.age || 0,
        currency: profile.currency || 'INR',
        monthlySpendingGoal: profile.monthlySpendingGoal || 0,
      });
      setBudgetData(profile.budgets || {});
      setLoading(false);
    }
  }, [user, profile]);

  const handleUpdateBudgets = async () => {
    if (!user) return;
    setUpdating(true);
    try {
      const docRef = doc(db, 'users', user.uid);
      await updateDoc(docRef, { budgets: budgetData });
      setProfileData((prev: any) => ({ ...prev, budgets: budgetData }));
      setIsBudgeting(false);
    } catch (error) {
      console.error('Error updating budgets:', error);
    } finally {
      setUpdating(false);
    }
  };

  const handleUpdateProfile = async () => {
    if (!user || !editData.displayName.trim()) return;
    setUpdating(true);
    try {
      await updateProfile(user, { displayName: editData.displayName });
      const docRef = doc(db, 'users', user.uid);
      const updatePayload = {
        displayName: editData.displayName,
        profession: editData.profession,
        income: Number(editData.income),
        age: Number(editData.age),
        currency: editData.currency,
        monthlySpendingGoal: Number(editData.monthlySpendingGoal),
      };
      await updateDoc(docRef, updatePayload);
      setProfileData((prev: any) => ({ ...prev, ...updatePayload }));
      setIsEditing(false);
    } catch (error) {
      console.error('Error updating profile:', error);
    } finally {
      setUpdating(false);
    }
  };

  const handleLogout = async () => {
    try {
      await signOut(auth);
    } catch (error) {
      console.error('Logout error:', error);
    }
  };

  const handleReauthenticate = async () => {
    if (!user || !reauthPassword) return;
    setDeleting(true);
    setDeleteError(null);
    try {
      // Check if user has a password provider
      const isEmailProvider = user.providerData.some(p => p.providerId === 'password');
      
      if (isEmailProvider) {
        const credential = EmailAuthProvider.credential(user.email!, reauthPassword);
        await reauthenticateWithCredential(user, credential);
      }
      
      // Now that we are re-authenticated (or if no password provider), proceed with deletion
      await proceedWithDeletion();
      
      setShowReauth(false);
      setReauthPassword('');
    } catch (error: any) {
      console.error('Re-authentication error:', error);
      if (error.code === 'auth/wrong-password') {
        setDeleteError('Invalid password. Please try again.');
      } else {
        // Try to parse JSON error from handleFirestoreError
        try {
          const parsed = JSON.parse(error.message);
          setDeleteError(parsed.error || 'Re-authentication failed.');
        } catch {
          setDeleteError(error.message || 'Re-authentication failed. Please try again.');
        }
      }
      setDeleting(false);
    }
  };

  const proceedWithDeletion = async () => {
    if (!user) return;
    try {
      // 1. Delete all expenses
      await deleteAllUserExpenses();

      // 2. Delete user profile from Firestore
      const userDocRef = doc(db, 'users', user.uid);
      await deleteDoc(userDocRef);

      // 3. Delete user from Firebase Auth
      // This should now succeed because we just re-authenticated
      await deleteUser(user);
      
      // The app will automatically redirect to login because of AuthContext
    } catch (error: any) {
      console.error('Error during deletion:', error);
      // Try to parse JSON error from handleFirestoreError
      try {
        const parsed = JSON.parse(error.message);
        setDeleteError('Deletion failed: ' + (parsed.error || 'Unknown error'));
      } catch {
        setDeleteError('An error occurred during deletion: ' + (error.message || 'Unknown error'));
      }
      setDeleting(false);
    }
  };

  const handleDeleteAccount = async () => {
    if (!user) return;
    // Always show re-authentication modal first for security and to avoid requires-recent-login
    setShowReauth(true);
    setDeleteStep(0); // Close the confirmation modal
  };

  const generateTaxReport = () => {
    const taxDeductible = expenses.filter(e => e.isTaxDeductible);
    if (taxDeductible.length === 0) {
      addNotification({
        title: 'No Data',
        message: 'No tax-deductible expenses found.',
        type: 'info'
      });
      return;
    }

    const headers = ['Date', 'Category', 'Amount', 'Currency', 'Notes'];
    const rows = taxDeductible.map(exp => [
      new Date(exp.date).toLocaleDateString(),
      exp.category,
      exp.amount,
      exp.currency || 'INR',
      exp.notes || ''
    ]);

    const csvContent = [headers, ...rows].map(e => e.join(',')).join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', `tax_report_${new Date().getFullYear()}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Calculations
  const income = profileData?.income || 0;
  const currentMonth = new Date().getMonth();
  const currentYear = new Date().getFullYear();
  
  const monthlyExpenses = expenses
    .filter(exp => {
      const d = new Date(exp.date);
      return d.getMonth() === currentMonth && d.getFullYear() === currentYear && exp.category !== 'Invested';
    })
    .reduce((sum, exp) => sum + exp.amount, 0);

  const savings = Math.max(0, income - monthlyExpenses);
  const savingsRate = income > 0 ? (savings / income) * 100 : 0;
  
  // Health Score calculation (simplified)
  // Based on savings rate (0-100% maps to 0-10)
  const healthScore = Math.min(10, (savingsRate / 10)).toFixed(1);
  const healthStatus = parseFloat(healthScore) >= 8 ? 'Excellent' : parseFloat(healthScore) >= 6 ? 'Good' : 'Needs Work';

  const professionMap: Record<string, string> = {
    'Job': 'Full-time Employee',
    'Student': 'Student',
    'Business Owner': 'Business Owner',
    'Freelancer': 'Freelancer'
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-12">
        <div className="w-8 h-8 border-4 border-emerald-600 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6 pb-12 -mx-4 -mt-6">
      {/* Header with zinc theme */}
      <div className="glass-dark pt-12 pb-20 px-6 rounded-b-[2.5rem] relative shadow-2xl border-b border-zinc-100 dark:border-white/5">
        <div className="flex items-center justify-between mb-8">
          <h1 className="text-2xl font-bold text-zinc-900 dark:text-white tracking-tight">Profile</h1>
          {!isEditing && (
            <button 
              onClick={() => setIsEditing(true)} 
              className="w-10 h-10 glass rounded-xl flex items-center justify-center backdrop-blur-md border border-zinc-100 dark:border-white/10 active:scale-95 transition-transform"
            >
              <Edit2 className="w-4 h-4 text-zinc-900 dark:text-white" />
            </button>
          )}
        </div>
        
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 bg-linear-to-br from-neon to-emerald-400 rounded-2xl flex items-center justify-center shadow-2xl border border-white/10 dark:border-neon/20 relative overflow-hidden">
            <User className="w-8 h-8 text-zinc-950" />
            <div className="absolute inset-0 bg-gradient-to-tr from-zinc-900/20 to-transparent pointer-events-none" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-zinc-900 dark:text-white tracking-tight">{profileData?.displayName || 'User'}</h2>
            <div className="inline-flex items-center gap-1.5 glass dark:bg-neon/10 backdrop-blur-md px-3 py-1 rounded-full mt-2 border border-zinc-100 dark:border-neon/20">
              <div className="w-1 h-1 rounded-full bg-zinc-400 dark:bg-neon" />
              <p className="text-[8px] font-bold text-zinc-500 dark:text-neon uppercase tracking-[0.2em]">
                {professionMap[profileData?.profession || 'Job']}
              </p>
            </div>
          </div>
        </div>

        <div className="absolute -right-10 -top-10 w-48 h-48 bg-emerald-500/10 dark:bg-emerald-500/5 rounded-full blur-3xl" />
        <div className="absolute -left-10 -bottom-10 w-48 h-48 bg-cyan-500/10 dark:bg-cyan-500/5 rounded-full blur-2xl" />
      </div>

      {/* Quick Stats Card */}
      <div className="px-6 -mt-10">
        <motion.div 
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          className="glass dark:glass-dark rounded-[2rem] p-6 shadow-2xl border border-zinc-100 dark:border-white/5 grid grid-cols-3 gap-3 text-center"
        >
          <div>
            <h3 className="text-lg font-bold text-zinc-900 dark:text-white tracking-tight">
              <AnimatedNumber value={income} className="text-zinc-900 dark:text-white" />
            </h3>
            <p className="text-[8px] font-bold text-zinc-500 uppercase tracking-widest mt-1.5">
              {profileData?.profession === 'Student' ? 'Pocket' : 
               profileData?.profession === 'Job' ? 'Salary' :
               profileData?.profession === 'Freelancer' ? 'Deal' :
               'Revenue'}
            </p>
          </div>
          <div className="border-x border-zinc-100 dark:border-white/5">
            <h3 className="text-lg font-bold text-zinc-900 dark:text-white tracking-tight">
              <AnimatedNumber value={monthlyExpenses} className="text-zinc-900 dark:text-white" />
            </h3>
            <p className="text-[8px] font-bold text-zinc-500 uppercase tracking-widest mt-1.5">Spent</p>
          </div>
          <div>
            <h3 className="text-lg font-bold text-zinc-900 dark:text-white tracking-tight">
              <AnimatedNumber value={savings} className="text-zinc-900 dark:text-white" />
            </h3>
            <p className="text-[8px] font-bold text-zinc-500 uppercase tracking-widest mt-1.5">Saved</p>
          </div>
        </motion.div>
      </div>

      {/* Health & Savings Cards */}
      <div className="px-6 grid grid-cols-2 gap-3">
        <div className="glass-card p-5 rounded-[2rem] border border-zinc-100 dark:border-white/5 shadow-sm">
          <div className="flex items-center gap-2 mb-4">
            <Activity className="w-4 h-4 text-emerald-500" />
            <span className="text-[9px] font-bold text-zinc-400 uppercase tracking-widest">Health</span>
          </div>
          <h4 className="text-3xl font-bold text-zinc-900 dark:text-white tracking-tight mb-1">{healthScore}</h4>
          <p className="text-[9px] font-bold text-zinc-400 uppercase tracking-widest">{healthStatus}</p>
        </div>

        <div className="glass-card p-5 rounded-[2rem] border border-zinc-100 dark:border-white/5 shadow-sm">
          <div className="flex items-center gap-2 mb-4">
            <TrendingUp className="w-4 h-4 text-cyan-500" />
            <span className="text-[9px] font-bold text-zinc-400 uppercase tracking-widest">Rate</span>
          </div>
          <h4 className="text-3xl font-bold text-zinc-900 dark:text-white tracking-tight mb-1">{savingsRate.toFixed(0)}%</h4>
          <p className="text-[9px] font-bold text-zinc-400 uppercase tracking-widest">of income</p>
        </div>
      </div>

      {/* Financial Profile */}
      <div className="px-6 space-y-3">
        <h3 className="text-[9px] font-bold text-zinc-400 dark:text-zinc-500 uppercase tracking-[0.2em] px-2">Financial Profile</h3>
        <div className="glass-card rounded-[2rem] border border-zinc-100 dark:border-white/5 shadow-sm divide-y divide-zinc-50 dark:divide-white/5 overflow-hidden">
          <div className="p-5 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-zinc-50 dark:bg-zinc-950 rounded-xl flex items-center justify-center">
                <Briefcase className="w-5 h-5 text-emerald-500" />
              </div>
              <div>
                <p className="text-xs font-bold text-zinc-900 dark:text-white tracking-tight">Employment</p>
                <p className="text-[9px] font-bold text-zinc-400 uppercase tracking-wider mt-0.5">{professionMap[profileData?.profession || 'Job']}</p>
              </div>
            </div>
            <p className="text-base font-bold text-zinc-900 dark:text-white tracking-tight">
              <AnimatedNumber value={income} />
            </p>
          </div>

          <div className="p-5 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-zinc-50 dark:bg-zinc-950 rounded-xl flex items-center justify-center">
                <Globe className="w-5 h-5 text-cyan-500" />
              </div>
              <div>
                <p className="text-xs font-bold text-zinc-900 dark:text-white tracking-tight shimmer-text">Currency</p>
                <p className="text-[9px] font-bold text-zinc-400 uppercase tracking-wider mt-0.5">{profileData?.currency || 'INR'}</p>
              </div>
            </div>
            <p className="text-base font-bold text-zinc-900 dark:text-white tracking-tight">{profileData?.currency || 'INR'}</p>
          </div>

          <div className="p-5 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-zinc-50 dark:bg-zinc-950 rounded-xl flex items-center justify-center">
                <CreditCard className="w-5 h-5 text-rose-500" />
              </div>
              <div>
                <p className="text-xs font-bold text-zinc-900 dark:text-white tracking-tight shimmer-text">Total Volume</p>
                <p className="text-[9px] font-bold text-zinc-400 uppercase tracking-wider mt-0.5">{expenses.length} transactions</p>
              </div>
            </div>
            <p className="text-base font-bold text-zinc-900 dark:text-white tracking-tight">
              <AnimatedNumber value={expenses.reduce((s, e) => s + e.amount, 0)} />
            </p>
          </div>
        </div>
      </div>

      {/* Account Settings */}
      <div className="px-6 space-y-3">
        <h3 className="text-[9px] font-bold text-zinc-400 dark:text-zinc-500 uppercase tracking-[0.2em] px-2">Settings</h3>
        <div className="glass-card rounded-[2rem] border border-zinc-100 dark:border-white/5 shadow-sm divide-y divide-zinc-50 dark:divide-white/5 overflow-hidden">
          <button 
            onClick={() => setIsEditing(true)}
            className="w-full p-5 flex items-center justify-between hover:bg-zinc-50 dark:hover:bg-white/5 transition-colors"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-zinc-50 dark:bg-zinc-950 rounded-xl flex items-center justify-center">
                <Edit2 className="w-5 h-5 text-zinc-400" />
              </div>
              <div className="text-left">
                <p className="text-xs font-bold text-zinc-900 dark:text-white tracking-tight">Edit Profile</p>
                <p className="text-[9px] font-bold text-zinc-400 uppercase tracking-wider mt-0.5">Update your details</p>
              </div>
            </div>
            <ChevronRight className="w-4 h-4 text-zinc-300" />
          </button>

          <button className="w-full p-5 flex items-center justify-between hover:bg-zinc-50 dark:hover:bg-white/5 transition-colors">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-zinc-50 dark:bg-zinc-950 rounded-xl flex items-center justify-center">
                <Bell className="w-5 h-5 text-zinc-400" />
              </div>
              <div className="text-left">
                <p className="text-xs font-bold text-zinc-900 dark:text-white tracking-tight">Notifications</p>
                <p className="text-[9px] font-bold text-zinc-400 uppercase tracking-wider mt-0.5">Manage alerts</p>
              </div>
            </div>
            <ChevronRight className="w-4 h-4 text-zinc-300" />
          </button>

          <button 
            onClick={() => setIsBudgeting(true)}
            className="w-full p-5 flex items-center justify-between hover:bg-zinc-50 dark:hover:bg-white/5 transition-colors"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-zinc-50 dark:bg-zinc-950 rounded-xl flex items-center justify-center">
                <Target className="w-5 h-5 text-zinc-400" />
              </div>
              <div className="text-left">
                <p className="text-xs font-bold text-zinc-900 dark:text-white tracking-tight">Monthly Budgets</p>
                <p className="text-[9px] font-bold text-zinc-400 uppercase tracking-wider mt-0.5">Set category limits</p>
              </div>
            </div>
            <ChevronRight className="w-4 h-4 text-zinc-300" />
          </button>

          <button 
            onClick={generateTaxReport}
            className="w-full p-5 flex items-center justify-between hover:bg-zinc-50 dark:hover:bg-white/5 transition-colors"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-zinc-50 dark:bg-zinc-950 rounded-xl flex items-center justify-center">
                <FileText className="w-5 h-5 text-zinc-400" />
              </div>
              <div className="text-left">
                <p className="text-xs font-bold text-zinc-900 dark:text-white tracking-tight">Tax Report</p>
                <p className="text-[9px] font-bold text-zinc-400 uppercase tracking-wider mt-0.5">Export deductible expenses</p>
              </div>
            </div>
            <Download className="w-4 h-4 text-zinc-300" />
          </button>
        </div>
      </div>

      {/* Danger Zone */}
      <div className="px-6 space-y-3">
        <h3 className="text-[9px] font-bold text-red-400 uppercase tracking-[0.2em] px-2">Danger Zone</h3>
        <div className="bg-white dark:bg-zinc-900 rounded-[2rem] border border-red-100 dark:border-red-900/30 shadow-sm overflow-hidden">
          <button 
            onClick={() => setDeleteStep(1)}
            className="w-full p-5 flex items-center justify-between hover:bg-red-50 dark:hover:bg-red-950 transition-colors group"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-red-50 dark:bg-red-950 rounded-xl flex items-center justify-center group-hover:bg-red-100 transition-colors">
                <Trash2 className="w-5 h-5 text-red-500" />
              </div>
              <div className="text-left">
                <p className="text-xs font-bold text-red-600">Delete Account</p>
                <p className="text-[9px] font-bold text-red-400 uppercase tracking-wider mt-0.5">Permanent removal</p>
              </div>
            </div>
            <ChevronRight className="w-4 h-4 text-red-200" />
          </button>
        </div>
      </div>

      {/* Logout Button */}
      <div className="px-6 mt-10">
        <button 
          onClick={handleLogout}
          className="w-full py-4 bg-linear-to-br from-zinc-900 to-zinc-700 dark:from-white dark:to-zinc-200 text-white dark:text-zinc-900 rounded-[1.5rem] font-bold flex items-center justify-center gap-2.5 hover:opacity-90 active:scale-95 transition-all shadow-xl"
        >
          <LogOut className="w-5 h-5" />
          <span className="text-sm">Logout</span>
        </button>
      </div>

      {/* Edit Budgets Modal */}
      <AnimatePresence>
        {isBudgeting && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-6">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => !updating && setIsBudgeting(false)}
              className="absolute inset-0 bg-zinc-900/60 backdrop-blur-sm"
            />
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-zinc-900 dark:bg-zinc-900 rounded-[40px] p-8 w-full max-w-md relative z-10 shadow-2xl border border-white/10 max-h-[80vh] overflow-y-auto"
            >
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-bold text-white tracking-tight">Monthly Budgets</h3>
                <button onClick={() => setIsBudgeting(false)} className="text-zinc-500 hover:text-white transition-colors">
                  <X className="w-5 h-5" />
                </button>
              </div>
              
              <p className="text-zinc-500 text-xs mb-6 leading-relaxed">
                Set monthly spending limits for each category. We'll alert you when you're nearing your limit.
              </p>

              <div className="space-y-4">
                {['Food', 'Transport', 'Shopping', 'Bills', 'Entertainment', 'Health', 'Other'].map(category => (
                  <div key={category} className="flex items-center gap-4">
                    <div className="w-10 h-10 bg-zinc-950 border border-zinc-800 rounded-xl flex items-center justify-center text-xl">
                      {category === 'Food' ? '🍔' : 
                       category === 'Transport' ? '🚗' : 
                       category === 'Shopping' ? '🛍️' : 
                       category === 'Bills' ? '📄' : 
                       category === 'Entertainment' ? '🎬' : 
                       category === 'Health' ? '💊' : '💰'}
                    </div>
                    <div className="flex-1">
                      <label className="block text-[10px] font-bold text-zinc-500 uppercase tracking-wider mb-1 px-1">{category}</label>
                      <div className="relative">
                        <span className="absolute left-4 top-1/2 -translate-y-1/2 text-zinc-500 text-xs font-bold">₹</span>
                        <input
                          type="number"
                          value={budgetData[category] || ''}
                          onChange={(e) => setBudgetData({ ...budgetData, [category]: Number(e.target.value) })}
                          placeholder="0"
                          className="w-full pl-8 pr-4 py-3 bg-zinc-950 border border-zinc-800 rounded-xl focus:outline-none focus:ring-2 focus:ring-neon/10 focus:border-neon transition-all text-sm font-medium text-white"
                        />
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              <div className="mt-8 space-y-3">
                <button
                  onClick={handleUpdateBudgets}
                  disabled={updating}
                  className="w-full py-4 bg-white dark:bg-neon text-zinc-900 dark:text-zinc-950 rounded-2xl font-bold flex items-center justify-center gap-2 hover:opacity-90 transition-all disabled:opacity-50 shadow-xl"
                >
                  {updating ? (
                    <div className="w-5 h-5 border-2 border-zinc-900 border-t-transparent rounded-full animate-spin" />
                  ) : (
                    'Save Budgets'
                  )}
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Edit Profile Modal */}
      <AnimatePresence>
        {isEditing && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-6">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => !updating && setIsEditing(false)}
              className="absolute inset-0 bg-zinc-900/60 backdrop-blur-sm"
            />
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-zinc-900 dark:bg-zinc-900 rounded-[40px] p-8 w-full max-w-sm relative z-10 shadow-2xl border border-white/10"
            >
              <h3 className="text-xl font-bold text-white mb-6 tracking-tight">Edit Profile</h3>
              
              <div className="space-y-4">
                <div>
                  <label className="block text-[10px] font-bold text-zinc-500 uppercase tracking-wider mb-1 px-1">Display Name</label>
                  <input
                    type="text"
                    value={editData.displayName}
                    onChange={(e) => setEditData({ ...editData, displayName: e.target.value })}
                    className="w-full px-4 py-3 bg-zinc-950 border border-zinc-800 rounded-xl focus:outline-none focus:ring-2 focus:ring-neon/10 focus:border-neon transition-all text-sm font-medium text-white"
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-zinc-500 uppercase tracking-wider mb-1 px-1">Profession</label>
                  <select
                    value={editData.profession}
                    onChange={(e) => setEditData({ ...editData, profession: e.target.value as any })}
                    className="w-full px-4 py-3 bg-zinc-950 border border-zinc-800 rounded-xl focus:outline-none focus:ring-2 focus:ring-neon/10 focus:border-neon transition-all text-sm font-bold text-white appearance-none"
                  >
                    {Object.keys(professionMap).map(p => (
                      <option key={p} value={p}>{p}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-zinc-500 uppercase tracking-wider mb-1 px-1">Currency</label>
                  <select
                    value={editData.currency}
                    onChange={(e) => setEditData({ ...editData, currency: e.target.value })}
                    className="w-full px-4 py-3 bg-zinc-950 border border-zinc-800 rounded-xl focus:outline-none focus:ring-2 focus:ring-neon/10 focus:border-neon transition-all text-sm font-bold text-white appearance-none"
                  >
                    {SUPPORTED_CURRENCIES.map(c => (
                      <option key={c.code} value={c.code}>{c.code} – {c.name}</option>
                    ))}
                  </select>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[10px] font-bold text-zinc-500 uppercase tracking-wider mb-1 px-1">Income</label>
                    <input
                      type="number"
                      value={editData.income}
                      onChange={(e) => setEditData({ ...editData, income: Number(e.target.value) })}
                      className="w-full px-4 py-3 bg-zinc-950 border border-zinc-800 rounded-xl focus:outline-none focus:ring-2 focus:ring-neon/10 focus:border-neon transition-all text-sm font-medium text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-zinc-500 uppercase tracking-wider mb-1 px-1">Monthly Budget</label>
                    <input
                      type="number"
                      value={editData.monthlySpendingGoal}
                      onChange={(e) => setEditData({ ...editData, monthlySpendingGoal: Number(e.target.value) })}
                      className="w-full px-4 py-3 bg-zinc-950 border border-zinc-800 rounded-xl focus:outline-none focus:ring-2 focus:ring-neon/10 focus:border-neon transition-all text-sm font-medium text-white"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-zinc-500 uppercase tracking-wider mb-1 px-1">Age</label>
                  <input
                    type="number"
                    value={editData.age}
                    onChange={(e) => setEditData({ ...editData, age: Number(e.target.value) })}
                    className="w-full px-4 py-3 bg-zinc-950 border border-zinc-800 rounded-xl focus:outline-none focus:ring-2 focus:ring-neon/10 focus:border-neon transition-all text-sm font-medium text-white"
                  />
                </div>
              </div>

              <div className="mt-8 space-y-3">
                <button
                  onClick={handleUpdateProfile}
                  disabled={updating}
                  className="w-full py-4 bg-white dark:bg-neon text-zinc-900 dark:text-zinc-950 rounded-2xl font-bold flex items-center justify-center gap-2 hover:opacity-90 transition-all disabled:opacity-50 shadow-xl"
                >
                  {updating ? (
                    <div className="w-5 h-5 border-2 border-zinc-900 border-t-transparent rounded-full animate-spin" />
                  ) : (
                    'Save Changes'
                  )}
                </button>
                <button
                  onClick={() => setIsEditing(false)}
                  disabled={updating}
                  className="w-full py-4 bg-zinc-800 text-zinc-400 rounded-2xl font-bold hover:bg-zinc-700 transition-colors disabled:opacity-50"
                >
                  Cancel
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Re-authentication Modal */}
      <AnimatePresence>
        {showReauth && (
          <div className="fixed inset-0 z-[60] flex items-center justify-center p-6">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => !deleting && setShowReauth(false)}
              className="absolute inset-0 bg-zinc-900/80 backdrop-blur-md"
            />
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-zinc-900 rounded-[40px] p-8 w-full max-w-sm relative z-10 shadow-2xl border border-white/10"
            >
              <div className="w-16 h-16 bg-zinc-950 rounded-[24px] flex items-center justify-center mx-auto mb-6 border border-white/5">
                <Lock className="w-8 h-8 text-white dark:text-neon" />
              </div>
              
              <h3 className="text-xl font-bold text-white text-center mb-2 tracking-tight">Confirm Password</h3>
              <p className="text-zinc-500 text-center text-sm mb-8 leading-relaxed">
                For security, please enter your password to confirm account deletion.
              </p>

              <div className="space-y-4">
                <div>
                  <label className="block text-[10px] font-bold text-zinc-500 uppercase tracking-wider mb-1 px-1">Password</label>
                  <input
                    type="password"
                    value={reauthPassword}
                    onChange={(e) => setReauthPassword(e.target.value)}
                    className="w-full px-4 py-3 bg-zinc-950 border border-zinc-800 rounded-xl focus:outline-none focus:ring-2 focus:ring-neon/10 focus:border-neon transition-all text-sm font-medium text-white"
                    placeholder="••••••••"
                  />
                </div>

                {deleteError && (
                  <div className="bg-red-500/10 p-3 rounded-xl border border-red-500/20">
                    <p className="text-[10px] text-red-400 font-medium text-center">{deleteError}</p>
                  </div>
                )}

                <div className="space-y-3 pt-4">
                  <button
                    onClick={handleReauthenticate}
                    disabled={deleting || !reauthPassword}
                    className="w-full py-4 bg-white dark:bg-neon text-zinc-900 dark:text-zinc-950 rounded-2xl font-bold flex items-center justify-center gap-2 hover:opacity-90 transition-all disabled:opacity-50 shadow-xl"
                  >
                    {deleting ? (
                      <div className="w-5 h-5 border-2 border-zinc-900 border-t-transparent rounded-full animate-spin" />
                    ) : (
                      'Verify & Delete'
                    )}
                  </button>
                  <button
                    onClick={() => {
                      setShowReauth(false);
                      setDeleteError(null);
                      setReauthPassword('');
                    }}
                    disabled={deleting}
                    className="w-full py-4 bg-zinc-800 text-zinc-400 rounded-2xl font-bold hover:bg-zinc-700 transition-colors disabled:opacity-50"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Delete Confirmation Modal */}
      <AnimatePresence>
        {deleteStep > 0 && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-6">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => !deleting && setDeleteStep(0)}
              className="absolute inset-0 bg-zinc-900/60 backdrop-blur-sm"
            />
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-zinc-900 rounded-[40px] p-8 w-full max-w-sm relative z-10 shadow-2xl border border-white/10"
            >
              <div className="w-16 h-16 bg-red-500/10 rounded-[24px] flex items-center justify-center mx-auto mb-6 border border-red-500/20">
                <AlertTriangle className="w-8 h-8 text-red-500" />
              </div>
              
              <h3 className="text-xl font-bold text-white text-center mb-2 tracking-tight">
                {deleteStep === 1 ? 'Delete Account?' : 'Are you absolutely sure?'}
              </h3>
              <p className="text-zinc-500 text-center text-sm mb-8 leading-relaxed">
                {deleteStep === 1 
                  ? 'This action is permanent and will delete all your expenses, profile data, and account settings.'
                  : 'This is the final confirmation. All your data will be immediately removed from our database.'}
              </p>

              {deleteError && (
                <div className="bg-red-500/10 p-4 rounded-2xl mb-6 border border-red-500/20">
                  <p className="text-xs text-red-400 leading-relaxed text-center font-medium">
                    {deleteError}
                  </p>
                </div>
              )}

              <div className="space-y-3">
                <button
                  onClick={() => {
                    if (deleteStep === 1) setDeleteStep(2);
                    else handleDeleteAccount();
                  }}
                  disabled={deleting}
                  className="w-full py-4 bg-red-600 text-white rounded-2xl font-bold flex items-center justify-center gap-2 hover:bg-red-700 transition-colors disabled:opacity-50 shadow-xl"
                >
                  {deleting ? (
                    <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  ) : (
                    <>
                      <Trash2 className="w-5 h-5" />
                      {deleteStep === 1 ? 'Yes, Delete My Account' : 'Confirm Permanent Deletion'}
                    </>
                  )}
                </button>
                <button
                  onClick={() => setDeleteStep(0)}
                  disabled={deleting}
                  className="w-full py-4 bg-zinc-800 text-zinc-400 rounded-2xl font-bold hover:bg-zinc-700 transition-colors disabled:opacity-50"
                >
                  Cancel
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};
