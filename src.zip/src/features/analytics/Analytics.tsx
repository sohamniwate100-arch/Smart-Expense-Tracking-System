import React, { useState } from 'react';
import { Expense, CATEGORIES, getCategoryEmoji } from '../../models/types';
import { 
  PieChart, 
  Pie, 
  Cell, 
  ResponsiveContainer, 
  Tooltip,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  LineChart,
  Line,
  AreaChart,
  Area,
  Legend
} from 'recharts';
import { motion } from 'motion/react';
import { 
  TrendingUp, 
  PieChart as PieChartIcon, 
  BarChart3, 
  TrendingDown, 
  DollarSign, 
  Lightbulb,
  ArrowUpRight,
  ArrowDownRight,
  Target
} from 'lucide-react';
import { useAuth } from '../../core/AuthContext';

import { useCurrency } from '../../hooks/useCurrency';
import { AnimatedNumber } from '../../widgets/AnimatedNumber';

interface AnalyticsProps {
  expenses: Expense[];
}

const COLORS = [
  '#f59e0b', // amber-500 (Food)
  '#10b981', // emerald-500 (Bills)
  '#8b5cf6', // violet-500 (Shopping)
  '#3b82f6', // blue-500 (Transport)
  '#ef4444', // red-500 (Entertainment)
  '#ec4899', // pink-500 (Health)
  '#14b8a6', // teal-500 (Invested)
  '#64748b', // slate-500 (Other)
];

export const Analytics: React.FC<AnalyticsProps> = ({ expenses }) => {
  const { profile } = useAuth();
  const { format } = useCurrency();
  const [timeRange, setTimeRange] = useState<'1m' | '3m' | '6m' | '9m' | '1y' | '3y' | '5y'>('1m');
  const income = profile?.income || 0;

  // Filter expenses based on time range
  const getTimeRangeDate = (range: string) => {
    const d = new Date();
    switch (range) {
      case '1m': d.setMonth(d.getMonth() - 1); break;
      case '3m': d.setMonth(d.getMonth() - 3); break;
      case '6m': d.setMonth(d.getMonth() - 6); break;
      case '9m': d.setMonth(d.getMonth() - 9); break;
      case '1y': d.setFullYear(d.getFullYear() - 1); break;
      case '3y': d.setFullYear(d.getFullYear() - 3); break;
      case '5y': d.setFullYear(d.getFullYear() - 5); break;
    }
    return d;
  };

  const rangeStartDate = getTimeRangeDate(timeRange);
  const filteredExpenses = expenses.filter(e => new Date(e.date) >= rangeStartDate);

  // Filter out investments for spending stats
  const spendingExpenses = filteredExpenses.filter(e => e.category !== 'Invested');
  const investmentExpenses = filteredExpenses.filter(e => e.category === 'Invested');

  // 1. Avg. Daily Spend (Selected Range)
  const totalSpentInRange = spendingExpenses.reduce((sum, exp) => sum + exp.amount, 0);
  const now = new Date();
  const diffTime = Math.abs(now.getTime() - rangeStartDate.getTime());
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  const avgDailySpend = diffDays > 0 ? totalSpentInRange / diffDays : 0;

  // 2. Biggest Category (Selected Range)
  const categoryTotals = CATEGORIES.map(cat => {
    const total = spendingExpenses
      .filter(exp => exp.category === cat)
      .reduce((sum, exp) => sum + exp.amount, 0);
    return { name: cat, value: total };
  });
  
  const biggestCategory = [...categoryTotals].sort((a, b) => b.value - a.value)[0];

  // 6. Smart Insights
  const totalIncomeInRange = income * (diffDays / 30);
  const isOverBudget = totalSpentInRange > totalIncomeInRange;
  const savingsRate = income > 0 ? Math.max(0, ((totalIncomeInRange - totalSpentInRange) / totalIncomeInRange) * 100) : 0;

  // 3. Category Breakdown Data (Updated with over-budget highlighting)
  const categoryBreakdown = categoryTotals
    .filter(d => d.value > 0)
    .map((d, index) => {
      const isBiggest = d.name === biggestCategory.name;
      return {
        ...d,
        percentage: totalSpentInRange > 0 ? (d.value / totalSpentInRange) * 100 : 0,
        color: (isOverBudget && isBiggest) ? '#991b1b' : COLORS[index % COLORS.length]
      };
    });

  // 4. Trend Data Calculation
  const getTrendData = () => {
    const data = [];
    const now = new Date();
    
    if (timeRange === '1m') {
      // Daily for 1 month
      for (let i = 0; i < diffDays; i++) {
        const date = new Date(rangeStartDate);
        date.setDate(date.getDate() + i);
        if (date > now) break;
        
        const dateStr = date.toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
        const total = spendingExpenses
          .filter(exp => new Date(exp.date).toDateString() === date.toDateString())
          .reduce((sum, exp) => sum + exp.amount, 0);
          
        data.push({ name: dateStr, amount: total, fullDate: date.toLocaleDateString() });
      }
    } else if (timeRange === '3m' || timeRange === '6m') {
      // Weekly for 3m and 6m
      const weeks = timeRange === '3m' ? 12 : 26;
      for (let i = 0; i < weeks; i++) {
        const date = new Date(rangeStartDate);
        date.setDate(date.getDate() + (i * 7));
        if (date > now) break;

        const dateStr = date.toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
        const total = spendingExpenses
          .filter(exp => {
            const d = new Date(exp.date);
            const weekEnd = new Date(date);
            weekEnd.setDate(weekEnd.getDate() + 7);
            return d >= date && d < weekEnd;
          })
          .reduce((sum, exp) => sum + exp.amount, 0);
          
        data.push({ name: dateStr, amount: total, fullDate: `Week of ${date.toLocaleDateString()}` });
      }
    } else {
      // Monthly for 9m, 1y, 3y, 5y
      const months = timeRange === '9m' ? 9 : timeRange === '1y' ? 12 : timeRange === '3y' ? 36 : 60;
      for (let i = 0; i < months; i++) {
        const date = new Date(rangeStartDate);
        date.setMonth(date.getMonth() + i);
        if (date > now) break;

        const dateStr = date.toLocaleDateString(undefined, { month: 'short', year: timeRange.includes('y') ? '2-digit' : undefined });
        const total = spendingExpenses
          .filter(exp => {
            const d = new Date(exp.date);
            return d.getMonth() === date.getMonth() && d.getFullYear() === date.getFullYear();
          })
          .reduce((sum, exp) => sum + exp.amount, 0);
          
        data.push({ name: dateStr, amount: total, fullDate: date.toLocaleDateString(undefined, { month: 'long', year: 'numeric' }) });
      }
    }
    return data;
  };

  const dailyTrend = getTrendData();

  // 5. Savings vs Expenses (Range based)
  const getSavingsVsExpenses = () => {
    let points = 6;
    if (timeRange === '1m') points = 4; // Weeks
    if (timeRange === '3y' || timeRange === '5y') points = 12; // More points for longer ranges

    return Array.from({ length: points }).map((_, i) => {
      const date = new Date(rangeStartDate);
      if (timeRange === '1m') {
        date.setDate(date.getDate() + (i * 7));
      } else {
        const monthStep = Math.max(1, Math.floor((diffDays / 30) / (points - 1)));
        date.setMonth(date.getMonth() + (i * monthStep));
      }
      
      const label = timeRange === '1m' 
        ? `W${i + 1}` 
        : date.toLocaleDateString(undefined, { month: 'short', year: timeRange.includes('y') ? '2-digit' : undefined });
      
      const month = date.getMonth();
      const year = date.getFullYear();

      const monthlySpent = spendingExpenses
        .filter(exp => {
          const d = new Date(exp.date);
          if (timeRange === '1m') {
             // Filter by week
             const weekStart = new Date(date);
             const weekEnd = new Date(date);
             weekEnd.setDate(weekEnd.getDate() + 7);
             return d >= weekStart && d < weekEnd;
          }
          return d.getMonth() === month && d.getFullYear() === year;
        })
        .reduce((sum, exp) => sum + exp.amount, 0);

      const monthlyIncome = income; // Assuming static income for now
      const savings = Math.max(0, monthlyIncome - monthlySpent);

      return { name: label, Expenses: monthlySpent, Savings: savings };
    });
  };

  const savingsVsExpenses = getSavingsVsExpenses();
  
  const getInsights = () => {
    const insights = [];
    
    // Profession-based recommendations
    if (profile?.profession === 'Student') {
      insights.push(`As a ${profile.studentLevel || 'student'}, focus on building a habit of saving even small amounts from your pocket money.`);
      insights.push("Try to set aside 10-15% of your allowance for a 'future self' fund.");
      if (profile.studentLevel === 'Post Graduation') {
        insights.push("Since you're at a higher education level, start exploring student-specific investment plans or low-risk mutual funds.");
      }
    } else if (profile?.profession === 'Job') {
      insights.push(`With your ${profile.jobType || 'full-time'} role, follow the 50/30/20 rule: 50% for needs, 30% for wants, and 20% for savings/investments.`);
      insights.push("Consider tax-saving investment instruments to maximize your take-home salary.");
      if (profile.jobType === 'Part-time') {
        insights.push("Since you're working part-time, focus on building a solid emergency fund to cover lean periods.");
      }
    } else if (profile?.profession === 'Freelancer') {
      insights.push("Since your income is project-based, aim for a larger emergency fund (6-12 months of expenses).");
      insights.push("Always set aside 20-30% of every deal/contract payment for future taxes.");
    } else if (profile?.profession === 'Business Owner') {
      insights.push(`As a ${profile.businessCategory || ''} ${profile.businessType || 'business'} owner, maintain a clear boundary between business revenue and personal income.`);
      insights.push("Diversify your wealth into FDs, RDs, or mutual funds to reduce dependency on business cash flow.");
      if (profile.businessCategory === 'B2B') {
        insights.push("For your B2B model, focus on optimizing your accounts receivable to ensure steady cash flow.");
      } else if (profile.businessCategory === 'B2C') {
        insights.push("In your B2C business, track your customer acquisition cost (CAC) closely against your lifetime value (LTV).");
      }
    }

    // Age-based recommendations
    const age = profile?.age || 0;
    if (age > 0 && age < 25) {
      insights.push("You're in the early stages! This is the best time to take calculated risks and invest in high-growth assets.");
    } else if (age >= 25 && age < 40) {
      insights.push("Focus on wealth accumulation and ensuring you have adequate life and health insurance coverage.");
    } else if (age >= 40 && age < 60) {
      insights.push("Prioritize debt reduction and shift towards more stable, low-risk investment options as you approach retirement.");
    } else if (age >= 60) {
      insights.push("Focus on capital preservation and generating a steady stream of regular income.");
    }

    // General spending insights
    if (savingsRate >= 20) {
      insights.push(`Great work! You're saving ${savingsRate.toFixed(0)}% of your income. Keep it up to hit your financial goal faster.`);
    } else if (savingsRate > 0) {
      insights.push(`You're saving ${savingsRate.toFixed(0)}% of your income. Try to reach the 20% mark for better financial security.`);
    } else {
      insights.push(`Your spending is exceeding your income. Consider reviewing your ${biggestCategory.name} expenses.`);
    }

    if (biggestCategory.value > income * 0.3) {
      insights.push(`Your ${biggestCategory.name} spending is quite high (${((biggestCategory.value / income) * 100).toFixed(0)}% of income). Look for ways to optimize this.`);
    }

    if (profile?.hasDebt) {
      insights.push("Prioritize paying off your active debt to reduce interest burden and increase your monthly savings.");
    }

    return insights;
  };

  return (
    <div className="space-y-8 pb-12">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 px-2">
        <div>
          <h2 className="text-3xl font-bold text-zinc-900 dark:text-white tracking-tight shimmer-text">Analytics</h2>
          <p className="text-zinc-400 dark:text-zinc-500 text-[10px] font-bold uppercase tracking-widest mt-1 shimmer-text">Financial Performance & Insights</p>
        </div>
        
        <div className="flex flex-wrap gap-1.5 glass p-1 rounded-2xl border border-zinc-200 dark:border-white/5">
          {(['1m', '3m', '6m', '9m', '1y', '3y', '5y'] as const).map((range) => (
            <button
              key={range}
              onClick={() => setTimeRange(range)}
              className={`px-3 py-1.5 rounded-xl text-[10px] font-bold uppercase tracking-wider transition-all ${
                timeRange === range
                  ? 'bg-zinc-900 dark:bg-zinc-800 text-white dark:text-white shadow-sm'
                  : 'text-zinc-400 hover:text-zinc-600 dark:hover:text-zinc-300 shimmer-text'
              }`}
            >
              {range}
            </button>
          ))}
        </div>
      </div>
      
      {/* Budget Health Overview */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {Object.entries(profile?.budgets || {}).slice(0, 3).map(([cat, budget], idx) => {
          const spent = spendingExpenses.filter(e => e.category === cat).reduce((s, e) => s + e.amount, 0);
          const percentage = Math.min((spent / (budget as number)) * 100, 100);
          return (
            <motion.div
              key={cat}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.1 }}
              className="glass-card p-6 rounded-[2rem] border border-zinc-100 dark:border-white/5 shadow-sm"
            >
              <div className="flex justify-between items-center mb-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-zinc-50 dark:bg-zinc-950 rounded-xl flex items-center justify-center text-xl">
                    {getCategoryEmoji(cat)}
                  </div>
                  <div>
                    <p className="text-xs font-bold text-zinc-900 dark:text-white tracking-tight shimmer-text">{cat}</p>
                    <p className="text-[9px] font-bold text-zinc-400 uppercase tracking-wider">
                      <AnimatedNumber value={spent} /> / <AnimatedNumber value={budget as number} />
                    </p>
                  </div>
                </div>
                <span className={`text-[10px] font-bold ${percentage > 90 ? 'text-red-500' : 'text-zinc-400'}`}>{percentage.toFixed(0)}%</span>
              </div>
              <div className="h-1.5 w-full bg-zinc-50 dark:bg-zinc-950 rounded-full overflow-hidden">
                <motion.div 
                  initial={{ width: 0 }}
                  animate={{ width: `${percentage}%` }}
                  className={`h-full rounded-full ${percentage > 90 ? 'bg-red-500' : percentage > 70 ? 'bg-amber-500' : 'bg-neon'}`}
                />
              </div>
            </motion.div>
          );
        })}
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          className="glass-card p-6 rounded-[2rem] border border-zinc-100 dark:border-white/5 shadow-sm"
        >
          <div className="w-10 h-10 bg-zinc-50 dark:bg-zinc-950 rounded-xl flex items-center justify-center mb-4">
            <TrendingDown className="w-5 h-5 text-rose-500" />
          </div>
          <p className="text-[9px] font-bold text-zinc-400 dark:text-zinc-500 uppercase tracking-[0.2em] mb-1 shimmer-text">Daily Average</p>
          <h3 className="text-2xl font-bold text-zinc-900 dark:text-white tracking-tight">
            <AnimatedNumber value={avgDailySpend} />
          </h3>
          <p className="text-[9px] text-zinc-400 dark:text-zinc-500 mt-3 font-bold uppercase tracking-wider">{spendingExpenses.length} Transactions</p>
        </motion.div>

        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.1 }}
          className={`p-6 rounded-[2rem] border shadow-sm transition-colors duration-500 ${
            isOverBudget 
              ? 'bg-red-50 dark:bg-red-950/20 border-red-100 dark:border-red-900/30' 
              : 'glass-card border-zinc-100 dark:border-white/5'
          }`}
        >
          <div className={`w-10 h-10 rounded-xl flex items-center justify-center mb-4 ${
            isOverBudget ? 'bg-red-100 dark:bg-red-900/40' : 'bg-zinc-50 dark:bg-zinc-950'
          }`}>
            <PieChartIcon className={`w-5 h-5 ${isOverBudget ? 'text-red-500' : 'text-amber-500'}`} />
          </div>
          <p className={`text-[9px] font-bold uppercase tracking-[0.2em] mb-1 ${
            isOverBudget ? 'text-red-400 dark:text-red-500' : 'text-zinc-400 dark:text-zinc-500 shimmer-text'
          }`}>Top Category</p>
          <h3 className={`text-2xl font-bold tracking-tight truncate ${
            isOverBudget ? 'text-red-600 dark:text-red-400' : 'text-zinc-900 dark:text-white shimmer-text'
          }`}>{biggestCategory.name || 'None'}</h3>
          <p className={`text-[9px] mt-3 font-bold uppercase tracking-wider ${
            isOverBudget ? 'text-red-400 dark:text-red-500' : 'text-zinc-400 dark:text-zinc-500'
          }`}>
            <AnimatedNumber value={biggestCategory.value} className={isOverBudget ? 'text-red-400 dark:text-red-500' : ''} /> in range
          </p>
        </motion.div>

        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.2 }}
          className={`p-6 rounded-[2rem] border shadow-sm transition-colors duration-500 ${
            savingsRate === 0 
              ? 'bg-orange-50 dark:bg-orange-950/20 border-orange-100 dark:border-orange-900/30' 
              : 'glass-card border-zinc-100 dark:border-white/5'
          }`}
        >
          <div className={`w-10 h-10 rounded-xl flex items-center justify-center mb-4 ${
            savingsRate === 0 ? 'bg-orange-100 dark:bg-orange-900/40' : 'bg-zinc-50 dark:bg-zinc-950'
          }`}>
            <Target className={`w-5 h-5 ${savingsRate === 0 ? 'text-orange-500' : 'text-cyan-500'}`} />
          </div>
          <p className={`text-[9px] font-bold uppercase tracking-[0.2em] mb-1 ${
            savingsRate === 0 ? 'text-orange-400 dark:text-orange-500' : 'text-zinc-400 dark:text-zinc-500 shimmer-text'
          }`}>Savings Rate</p>
          <h3 className={`text-2xl font-bold tracking-tight ${
            savingsRate === 0 ? 'text-orange-600 dark:text-orange-400' : 'text-zinc-900 dark:text-white'
          }`}>{savingsRate.toFixed(0)}%</h3>
          <p className={`text-[9px] mt-3 font-bold uppercase tracking-wider ${
            savingsRate === 0 ? 'text-orange-400 dark:text-orange-500' : 'text-zinc-400 dark:text-zinc-500'
          }`}>{savingsRate === 0 ? 'Budget Exceeded' : 'of total income'}</p>
        </motion.div>

        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.3 }}
          className="glass-card p-6 rounded-[2rem] border border-zinc-100 dark:border-white/5 shadow-sm"
        >
          <div className="w-10 h-10 bg-zinc-50 dark:bg-zinc-950 rounded-xl flex items-center justify-center mb-4">
            <TrendingUp className="w-5 h-5 text-emerald-500" />
          </div>
          <p className="text-[9px] font-bold text-zinc-400 dark:text-zinc-500 uppercase tracking-[0.2em] mb-1 shimmer-text">Total Invested</p>
          <h3 className="text-2xl font-bold text-zinc-900 dark:text-white tracking-tight">
            <AnimatedNumber value={investmentExpenses.reduce((s, e) => s + e.amount, 0)} />
          </h3>
          <p className="text-[9px] text-zinc-400 dark:text-zinc-500 mt-3 font-bold uppercase tracking-wider">Lifetime</p>
        </motion.div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Category Breakdown */}
        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.4 }}
          className="glass-card p-8 rounded-[2.5rem] border border-zinc-100 dark:border-white/5 shadow-sm"
        >
          <h3 className="font-bold text-zinc-900 dark:text-white mb-8 uppercase tracking-[0.2em] text-[10px] shimmer-text">Category Breakdown</h3>
          
          <div className="flex flex-col md:flex-row items-center gap-8">
            <div className="h-[240px] w-full md:w-1/2 relative">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={categoryBreakdown}
                    cx="50%"
                    cy="50%"
                    innerRadius={75}
                    outerRadius={95}
                    paddingAngle={8}
                    dataKey="value"
                    animationDuration={1500}
                  >
                    {categoryBreakdown.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} stroke="none" />
                    ))}
                  </Pie>
                  <Tooltip 
                    contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 20px 25px -5px rgb(0 0 0 / 0.1)', backgroundColor: '#18181b', color: '#fff', fontSize: '11px' }}
                    itemStyle={{ color: '#fff' }}
                    formatter={(value: number, _name: string, props: any) => [
                      <span className="flex items-center gap-1">
                        <AnimatedNumber value={value} />
                        <span>({props.payload.percentage.toFixed(1)}%)</span>
                      </span>, 
                      'Amount'
                    ]}
                  />
                </PieChart>
              </ResponsiveContainer>
              
              {/* Center Text for Pie */}
              <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
                <p className="text-[8px] font-bold text-zinc-400 dark:text-zinc-500 uppercase tracking-widest">Total</p>
                <p className="text-2xl font-bold text-zinc-900 dark:text-white tracking-tight">
                  <AnimatedNumber value={totalSpentInRange} />
                </p>
              </div>
            </div>

            <div className="w-full md:w-1/2 space-y-4">
              {categoryBreakdown.map((item) => (
                <div key={item.name} className="flex items-center justify-between group cursor-default">
                  <div className="flex items-center gap-3">
                    <div className="w-3 h-3 rounded-full group-hover:scale-125 transition-transform" style={{ backgroundColor: item.color }} />
                    <span className={`text-xs font-bold uppercase tracking-wider ${
                      (isOverBudget && item.name === biggestCategory.name) ? 'text-red-600 dark:text-red-400' : 'text-zinc-600 dark:text-zinc-400 shimmer-text'
                    }`}>{item.name}</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className={`text-sm font-bold tracking-tight ${
                      (isOverBudget && item.name === biggestCategory.name) ? 'text-red-600 dark:text-red-400' : 'text-zinc-900 dark:text-white'
                    }`}>
                      <AnimatedNumber value={item.value} className={(isOverBudget && item.name === biggestCategory.name) ? 'text-red-600 dark:text-red-400' : ''} />
                    </span>
                    <span className={`text-[9px] font-bold uppercase tracking-widest ${
                      (isOverBudget && item.name === biggestCategory.name) ? 'text-red-400 dark:text-red-500' : 'text-zinc-400 dark:text-zinc-500'
                    }`}>{item.percentage.toFixed(0)}%</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </motion.div>

        {/* Daily Spending Trend */}
        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.5 }}
          className="glass-card p-8 rounded-[2.5rem] border border-zinc-100 dark:border-white/5 shadow-sm"
        >
          <h3 className="font-bold text-zinc-900 dark:text-white mb-8 uppercase tracking-[0.2em] text-[10px] shimmer-text">Daily Spend Trend</h3>
          <div className="h-[240px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={dailyTrend}>
                <defs>
                  <linearGradient id="colorAmount" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#00FF88" stopOpacity={0.2}/>
                    <stop offset="95%" stopColor="#00FF88" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" opacity={0.5} />
                <XAxis 
                  dataKey="name" 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{ fontSize: 9, fill: '#94a3b8', fontWeight: 'bold' }} 
                  interval={timeRange === '1m' ? 4 : timeRange === '1y' ? 0 : 'preserveStartEnd'}
                />
                <YAxis 
                  axisLine={false}
                  tickLine={false}
                  tick={{ fontSize: 9, fill: '#94a3b8', fontWeight: 'bold' }}
                />
                <Tooltip 
                  contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 20px 25px -5px rgb(0 0 0 / 0.1)', backgroundColor: '#18181b', color: '#fff', fontSize: '11px' }}
                  itemStyle={{ color: '#fff' }}
                  labelStyle={{ color: '#94a3b8', marginBottom: '4px', fontWeight: 'bold' }}
                  formatter={(value: number) => [<AnimatedNumber value={value} />, 'Spent']}
                />
                <Area 
                  type="monotone" 
                  dataKey="amount" 
                  stroke="#00FF88" 
                  strokeWidth={4}
                  fillOpacity={1} 
                  fill="url(#colorAmount)" 
                  animationDuration={2000}
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </motion.div>

        {/* Savings vs Expenses */}
        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.6 }}
          className="glass-card p-8 rounded-[2.5rem] border border-zinc-100 dark:border-white/5 shadow-sm"
        >
          <h3 className="font-bold text-zinc-900 dark:text-white mb-8 uppercase tracking-[0.2em] text-[10px] shimmer-text">Savings vs Expenses</h3>
          <div className="h-[240px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={savingsVsExpenses}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" opacity={0.5} />
                <XAxis 
                  dataKey="name" 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{ fontSize: 9, fill: '#94a3b8', fontWeight: 'bold' }} 
                />
                <YAxis 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{ fontSize: 9, fill: '#94a3b8', fontWeight: 'bold' }}
                />
                <Tooltip 
                  contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 20px 25px -5px rgb(0 0 0 / 0.1)', backgroundColor: '#18181b', color: '#fff', fontSize: '11px' }}
                  itemStyle={{ color: '#fff' }}
                  labelStyle={{ color: '#94a3b8', marginBottom: '4px', fontWeight: 'bold' }}
                  formatter={(value: number, name: string) => [<AnimatedNumber value={value} />, name]}
                />
                <Legend iconType="circle" wrapperStyle={{ fontSize: '9px', fontWeight: 'bold', textTransform: 'uppercase', paddingTop: '20px' }} />
                <Bar dataKey="Expenses" fill="#a1a1aa" radius={[6, 6, 0, 0]} barSize={12} />
                <Bar dataKey="Savings" fill="#00FF88" radius={[6, 6, 0, 0]} barSize={12} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </motion.div>

        {/* Financial Performance Record & Insights */}
        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.7 }}
          className="glass-dark p-8 rounded-[2.5rem] border border-zinc-800 dark:border-white/5 shadow-2xl flex flex-col justify-between"
        >
          <div>
            <div className="flex items-center gap-4 mb-8">
              <div className="w-12 h-12 bg-white/10 dark:bg-zinc-900/10 rounded-2xl flex items-center justify-center">
                <Lightbulb className="w-6 h-6 text-white dark:text-zinc-900" />
              </div>
              <h3 className="font-bold text-white dark:text-zinc-900 text-xl tracking-tight shimmer-text">Smart Insights</h3>
            </div>
            
            <div className="space-y-6">
              <div className="bg-white/5 dark:bg-zinc-900/5 p-6 rounded-2xl border border-white/10 dark:border-zinc-900/10">
                <p className="text-[9px] font-bold text-zinc-400 dark:text-zinc-500 uppercase tracking-[0.2em] mb-3 shimmer-text">Performance Record</p>
                <p className="text-sm text-zinc-300 dark:text-zinc-700 leading-relaxed">
                  In this period, you've spent a total of <span className="font-bold text-white dark:text-zinc-900"><AnimatedNumber value={totalSpentInRange} className="text-white dark:text-zinc-900" /></span> across <span className="font-bold text-white dark:text-zinc-900">{spendingExpenses.length}</span> transactions. 
                  Your average daily spending is <span className="font-bold text-white dark:text-zinc-900"><AnimatedNumber value={avgDailySpend} className="text-white dark:text-zinc-900" /></span>. 
                  The <span className="font-bold text-white dark:text-zinc-900">{biggestCategory.name}</span> category accounts for <span className="font-bold text-white dark:text-zinc-900">{((biggestCategory.value / totalSpentInRange) * 100).toFixed(0)}%</span> of your total spending.
                </p>
              </div>

              <div className="space-y-4">
                <p className="text-[9px] font-bold text-zinc-400 dark:text-zinc-500 uppercase tracking-[0.2em] shimmer-text">Recommendations</p>
                <div className="grid grid-cols-1 gap-3">
                  {getInsights().slice(0, 4).map((insight, i) => (
                    <div key={i} className="flex gap-4 items-start">
                      <div className="mt-2 w-1.5 h-1.5 rounded-full bg-zinc-400 dark:bg-zinc-500 shrink-0" />
                      <p className="text-xs text-zinc-300 dark:text-zinc-700 leading-snug">{insight}</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
};
