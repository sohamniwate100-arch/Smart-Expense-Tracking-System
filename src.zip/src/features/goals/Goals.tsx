import React, { useState, useEffect, useMemo } from 'react';
import { FinancialGoal, getCategoryEmoji, Expense } from '../../models/types';
import { subscribeToGoals, addGoal, deleteGoal } from '../../services/goalService';
import { motion, AnimatePresence } from 'motion/react';
import { Plus, Target, Calendar, Trash2, TrendingUp, CheckCircle2, AlertCircle, Clock, Activity } from 'lucide-react';
import { Button } from '../../widgets/Button';
import { useCurrency } from '../../hooks/useCurrency';
import { AnimatedNumber } from '../../widgets/AnimatedNumber';
import { useAuth } from '../../core/AuthContext';

interface GoalsProps {
  expenses: Expense[];
}

export const Goals: React.FC<GoalsProps> = ({ expenses }) => {
  const [goals, setGoals] = useState<FinancialGoal[]>([]);
  const [showAddModal, setShowAddModal] = useState(false);
  const { profile } = useAuth();
  const { format } = useCurrency();

  // Calculate average monthly savings based on behavior
  const monthlySavings = useMemo(() => {
    const income = profile?.income || 0;
    const now = new Date();
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(now.getDate() - 30);

    const recentExpenses = expenses.filter(e => new Date(e.date) >= thirtyDaysAgo);
    const totalSpent = recentExpenses.reduce((sum, e) => sum + e.amount, 0);
    
    return Math.max(0, income - totalSpent);
  }, [expenses, profile?.income]);

  useEffect(() => {
    return subscribeToGoals(setGoals);
  }, []);

  return (
    <div className="space-y-8 pb-24">
      <div className="flex items-center justify-between px-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tighter shimmer-text">Financial Goals</h1>
          <p className="text-xs font-bold text-zinc-400 uppercase tracking-widest mt-1 shimmer-text">Save for what matters</p>
        </div>
        <Button variant="gradient" size="icon" onClick={() => setShowAddModal(true)}>
          <Plus className="w-5 h-5" />
        </Button>
      </div>

      {/* Behavioral Summary Card */}
      <div className="px-4">
        <motion.div 
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="glass-card p-6 rounded-[2.5rem] border border-zinc-100 dark:border-white/5 flex items-center justify-between bg-neon/5"
        >
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-neon/10 rounded-2xl flex items-center justify-center">
              <TrendingUp className="w-6 h-6 text-neon" />
            </div>
            <div>
              <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest mb-0.5">Monthly Savings Capacity</p>
              <h2 className="text-2xl font-bold text-zinc-900 dark:text-white tracking-tight">
                <AnimatedNumber value={monthlySavings} />
              </h2>
            </div>
          </div>
          <div className="text-right hidden sm:block">
            <p className="text-[9px] font-bold text-zinc-400 uppercase tracking-widest leading-tight">Based on your<br/>last 30 days</p>
          </div>
        </motion.div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 px-4">
        {goals.map((goal, idx) => (
          <GoalCard key={goal.id} goal={goal} idx={idx} monthlySavings={monthlySavings} />
        ))}
        {goals.length === 0 && (
          <div className="col-span-full py-20 text-center glass rounded-[2.5rem] border-2 border-dashed border-zinc-200 dark:border-zinc-800">
            <Target className="w-12 h-12 text-zinc-200 dark:text-zinc-800 mx-auto mb-4" />
            <p className="text-zinc-500 font-bold">No goals set yet</p>
            <p className="text-[10px] text-zinc-400 uppercase tracking-widest mt-1">Start your saving journey today</p>
          </div>
        )}
      </div>

      <AnimatePresence>
        {showAddModal && (
          <AddGoalModal onClose={() => setShowAddModal(false)} />
        )}
      </AnimatePresence>
    </div>
  );
};

const GoalCard: React.FC<{ goal: FinancialGoal; idx: number; monthlySavings: number }> = ({ goal, idx, monthlySavings }) => {
  const { format } = useCurrency();
  const progress = Math.min((goal.currentAmount / goal.targetAmount) * 100, 100);
  const isCompleted = progress >= 100;
  
  const remainingAmount = Math.max(0, goal.targetAmount - goal.currentAmount);
  const monthsToReach = monthlySavings > 0 ? remainingAmount / monthlySavings : Infinity;
  
  const deadlineDate = new Date(goal.deadline);
  const today = new Date();
  const monthsUntilDeadline = (deadlineDate.getFullYear() - today.getFullYear()) * 12 + (deadlineDate.getMonth() - today.getMonth());
  
  // Behavioral Progress Logic
  const createdAtDate = goal.createdAt?.toDate ? goal.createdAt.toDate() : new Date(goal.createdAt || Date.now());
  const totalDuration = Math.max(deadlineDate.getTime() - createdAtDate.getTime(), 1);
  const elapsedDuration = today.getTime() - createdAtDate.getTime();
  const expectedProgress = Math.min(Math.max((elapsedDuration / totalDuration) * 100, 0), 100);
  
  const behavioralScore = expectedProgress > 0 ? (progress / expectedProgress) : 1;
  const momentum = behavioralScore >= 1.2 ? 'High' : behavioralScore >= 0.9 ? 'Steady' : 'Low';

  const status = useMemo(() => {
    if (isCompleted) return { label: 'Completed', color: 'text-neon', bg: 'bg-neon/10', icon: CheckCircle2 };
    if (monthlySavings <= 0) return { label: 'No Savings', color: 'text-red-500', bg: 'bg-red-500/10', icon: AlertCircle };
    if (monthsToReach <= monthsUntilDeadline) return { label: 'On Track', color: 'text-neon', bg: 'bg-neon/10', icon: TrendingUp };
    if (monthsToReach <= monthsUntilDeadline * 1.5) return { label: 'At Risk', color: 'text-amber-500', bg: 'bg-amber-500/10', icon: Clock };
    return { label: 'Behind', color: 'text-red-500', bg: 'bg-red-500/10', icon: AlertCircle };
  }, [isCompleted, monthlySavings, monthsToReach, monthsUntilDeadline]);

  const StatusIcon = status.icon;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: idx * 0.1 }}
      className="glass-card p-6 rounded-[2.5rem] relative overflow-hidden group border border-zinc-100 dark:border-white/5"
    >
      <div className="flex justify-between items-start mb-6">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 bg-zinc-50 dark:bg-zinc-950 rounded-2xl flex items-center justify-center text-2xl shadow-inner">
            {getCategoryEmoji(goal.category)}
          </div>
          <div>
            <h3 className="font-bold text-zinc-900 dark:text-white text-lg tracking-tight shimmer-text">{goal.title}</h3>
            <div className="flex items-center gap-2">
              <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest shimmer-text">{goal.category}</p>
              <span className="w-1 h-1 rounded-full bg-zinc-300 dark:bg-zinc-700" />
              <p className={`text-[9px] font-bold uppercase tracking-widest ${momentum === 'High' ? 'text-neon' : momentum === 'Steady' ? 'text-blue-400' : 'text-amber-500'}`}>
                {momentum} Momentum
              </p>
            </div>
          </div>
        </div>
        <div className={`px-3 py-1 rounded-full flex items-center gap-1.5 ${status.bg} ${status.color}`}>
          <StatusIcon className="w-3 h-3" />
          <span className="text-[9px] font-bold uppercase tracking-wider">{status.label}</span>
        </div>
      </div>

      <div className="space-y-4">
        <div className="flex justify-between items-end">
          <div>
            <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest mb-1 shimmer-text">Progress vs Target</p>
            <p className="text-xl font-bold text-zinc-900 dark:text-white tracking-tighter">
              <AnimatedNumber value={goal.currentAmount} /> <span className="text-zinc-400 text-sm font-medium">/ <AnimatedNumber value={goal.targetAmount} /></span>
            </p>
          </div>
          <div className="text-right">
            <p className="text-2xl font-bold text-neon tracking-tighter">{progress.toFixed(0)}%</p>
            <p className="text-[8px] font-bold text-zinc-400 uppercase tracking-widest">Target: {expectedProgress.toFixed(0)}%</p>
          </div>
        </div>

        <div className="relative h-4 w-full bg-zinc-100 dark:bg-zinc-950 rounded-full overflow-hidden">
          {/* Expected Progress Marker */}
          {!isCompleted && (
            <motion.div 
              initial={{ left: 0 }}
              animate={{ left: `${expectedProgress}%` }}
              className="absolute top-0 bottom-0 w-0.5 bg-zinc-300 dark:bg-zinc-700 z-10"
            >
              <div className="absolute -top-1 -left-1 w-2 h-2 rounded-full bg-zinc-300 dark:bg-zinc-700" />
            </motion.div>
          )}
          
          <motion.div
            initial={{ width: 0 }}
            animate={{ width: `${progress}%` }}
            className={`h-full rounded-full ${isCompleted ? 'bg-neon' : 'gradient-neon'} relative z-0`}
          />
        </div>

        {/* Behavioral Insight */}
        {!isCompleted && (
          <div className="bg-zinc-50 dark:bg-zinc-950/50 p-4 rounded-2xl border border-zinc-100 dark:border-white/5 relative overflow-hidden">
            <div className="relative z-10">
              <div className="flex items-center gap-2 mb-2">
                <Activity className="w-3 h-3 text-neon" />
                <p className="text-[9px] font-bold text-zinc-400 uppercase tracking-widest">Behavioral Projection</p>
              </div>
              <p className="text-[10px] text-zinc-600 dark:text-zinc-400 leading-relaxed">
                {monthlySavings > 0 ? (
                  <>
                    At your current saving rate of <span className="text-zinc-900 dark:text-white font-bold">{format(monthlySavings)}/mo</span>, 
                    you'll reach this in <span className="text-zinc-900 dark:text-white font-bold">{monthsToReach < 1 ? 'less than a month' : `${Math.ceil(monthsToReach)} months`}</span>.
                    {behavioralScore < 0.9 && (
                      <span className="block mt-1 text-amber-500 font-bold">You are currently {((1 - behavioralScore) * 100).toFixed(0)}% behind your ideal saving schedule.</span>
                    )}
                  </>
                ) : (
                  <span className="text-red-500 font-bold">Your current spending behavior prevents any progress toward this goal. Consider reviewing your "Wants" categories.</span>
                )}
              </p>
            </div>
            <div className="absolute -right-4 -bottom-4 w-16 h-16 bg-neon/5 rounded-full blur-2xl" />
          </div>
        )}

        <div className="flex items-center justify-between pt-2">
          <div className="flex items-center gap-2 text-zinc-400">
            <Calendar className="w-3.5 h-3.5" />
            <span className="text-[10px] font-bold uppercase tracking-wider shimmer-text">
              Deadline: {new Date(goal.deadline).toLocaleDateString(undefined, { month: 'short', year: 'numeric' })}
            </span>
          </div>
          <div className="flex gap-2">
            <button onClick={() => deleteGoal(goal.id)} className="p-2 text-zinc-400 hover:text-red-500 transition-colors">
              <Trash2 className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </motion.div>
  );
};

const AddGoalModal: React.FC<{ onClose: () => void }> = ({ onClose }) => {
  const [title, setTitle] = useState('');
  const [targetAmount, setTargetAmount] = useState('');
  const [deadline, setDeadline] = useState('');
  const [category, setCategory] = useState('Other');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      await addGoal({
        title,
        targetAmount: parseFloat(targetAmount),
        currentAmount: 0,
        deadline,
        category,
      });
      onClose();
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-zinc-950/40 backdrop-blur-sm">
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        className="glass w-full max-w-md p-8 rounded-[3rem] shadow-2xl"
      >
        <div className="flex justify-between items-center mb-8">
          <h2 className="text-2xl font-bold tracking-tighter shimmer-text">New Goal</h2>
          <button onClick={onClose} className="p-2 hover:bg-zinc-100 dark:hover:bg-zinc-800 rounded-full transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2">
            <label className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest px-1 shimmer-text">Goal Name</label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full bg-zinc-50 dark:bg-zinc-950 border border-zinc-100 dark:border-zinc-800 rounded-2xl px-4 py-3 focus:outline-none focus:border-neon"
              placeholder="e.g. New Laptop"
              required
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest px-1 shimmer-text">Target Amount</label>
              <input
                type="number"
                value={targetAmount}
                onChange={(e) => setTargetAmount(e.target.value)}
                className="w-full bg-zinc-50 dark:bg-zinc-950 border border-zinc-100 dark:border-zinc-800 rounded-2xl px-4 py-3 focus:outline-none focus:border-neon"
                placeholder="0.00"
                required
              />
            </div>
            <div className="space-y-2">
              <label className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest px-1 shimmer-text">Deadline</label>
              <input
                type="date"
                value={deadline}
                onChange={(e) => setDeadline(e.target.value)}
                className="w-full bg-zinc-50 dark:bg-zinc-950 border border-zinc-100 dark:border-zinc-800 rounded-2xl px-4 py-3 focus:outline-none focus:border-neon"
                required
              />
            </div>
          </div>

          <Button type="submit" variant="gradient" className="w-full py-4 rounded-2xl" isLoading={loading}>
            Create Goal
          </Button>
        </form>
      </motion.div>
    </div>
  );
};

const X = ({ className, onClick }: { className?: string; onClick?: () => void }) => (
  <svg onClick={onClick} className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
  </svg>
);
