import React, { useState, useEffect } from 'react';
import { CATEGORIES, Expense, Category, getCategoryEmoji, Frequency, RecurringExpense } from '../../models/types';
import { addExpense, updateExpense } from '../../services/expenseService';
import { addRecurringExpense, updateRecurringExpense } from '../../services/recurringExpenseService';
import { scanReceipt } from '../../services/aiService';
import { Button } from '../../widgets/Button';
import { motion, AnimatePresence } from 'motion/react';
import { X, Calendar, DollarSign, Tag, FileText, CreditCard, RefreshCw, Camera, Loader2, Landmark } from 'lucide-react';

interface AddExpenseProps {
  onClose: () => void;
  editExpense?: Expense | null;
  editRecurringExpense?: RecurringExpense | null;
}

const CURRENCIES = [
  { code: 'INR', symbol: '₹' },
  { code: 'USD', symbol: '$' },
  { code: 'EUR', symbol: '€' },
  { code: 'GBP', symbol: '£' },
  { code: 'JPY', symbol: '¥' },
];

export const AddExpense: React.FC<AddExpenseProps> = ({ onClose, editExpense, editRecurringExpense }) => {
  const [amount, setAmount] = useState('');
  const [currency, setCurrency] = useState('INR');
  const [category, setCategory] = useState<Category>('Food');
  const [notes, setNotes] = useState('');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [paymentMethod, setPaymentMethod] = useState<'Online' | 'Cash'>('Online');
  const [isRecurring, setIsRecurring] = useState(false);
  const [isTaxDeductible, setIsTaxDeductible] = useState(false);
  const [frequency, setFrequency] = useState<Frequency>('Monthly');
  const [loading, setLoading] = useState(false);
  const [scanning, setScanning] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    if (editExpense) {
      setAmount(editExpense.amount.toString());
      setCurrency(editExpense.currency || 'INR');
      setCategory(editExpense.category as Category);
      setNotes(editExpense.notes || '');
      setDate(new Date(editExpense.date).toISOString().split('T')[0]);
      setPaymentMethod(editExpense.paymentMethod || 'Online');
      setIsTaxDeductible(editExpense.isTaxDeductible || false);
    } else if (editRecurringExpense) {
      setAmount(editRecurringExpense.amount.toString());
      setCurrency(editRecurringExpense.currency || 'INR');
      setCategory(editRecurringExpense.category as Category);
      setNotes(editRecurringExpense.notes || '');
      setDate(new Date(editRecurringExpense.startDate).toISOString().split('T')[0]);
      setPaymentMethod(editRecurringExpense.paymentMethod || 'Online');
      setIsTaxDeductible(editRecurringExpense.isTaxDeductible || false);
      setIsRecurring(true);
      setFrequency(editRecurringExpense.frequency);
    }
  }, [editExpense, editRecurringExpense]);

  const handleReceiptScan = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setScanning(true);
    setError('');

    try {
      const reader = new FileReader();
      reader.onloadend = async () => {
        const base64 = reader.result as string;
        const result = await scanReceipt(base64);
        
        setAmount(result.amount.toString());
        setCategory(result.category);
        setNotes(`${result.merchant}: ${result.notes}`);
        if (result.date) {
          setDate(new Date(result.date).toISOString().split('T')[0]);
        }
        setScanning(false);
      };
      reader.readAsDataURL(file);
    } catch (err: any) {
      setError('Failed to scan receipt. Please try again.');
      setScanning(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    const expenseData = {
      amount: parseFloat(amount),
      currency,
      category,
      notes,
      date: new Date(date).toISOString(),
      paymentMethod,
      isTaxDeductible,
    };

    try {
      if (editRecurringExpense) {
        await updateRecurringExpense(editRecurringExpense.id, {
          ...expenseData,
          frequency,
          startDate: new Date(date).toISOString(),
        });
      } else if (isRecurring && !editExpense) {
        await addRecurringExpense({
          ...expenseData,
          frequency,
          startDate: new Date(date).toISOString(),
        });
      } else if (editExpense) {
        await updateExpense(editExpense.id, expenseData);
      } else {
        await addExpense(expenseData);
      }
      onClose();
    } catch (err: any) {
      setError(err.message || 'Failed to save expense');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between px-2 mb-4">
        <h2 className="text-xl font-bold gradient-text tracking-tight shimmer-text">
          {editExpense || editRecurringExpense ? 'Edit' : 'Add'} {editRecurringExpense ? 'Recurring' : 'Expense'}
        </h2>
        <button onClick={onClose} className="w-8 h-8 glass-card rounded-full flex items-center justify-center transition-transform active:scale-90">
          <X className="w-4 h-4 text-zinc-500" />
        </button>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Amount Input */}
        <div className="text-center py-6 relative">
          <div className="absolute right-4 top-0">
            <label className="cursor-pointer group">
              <input type="file" accept="image/*" className="hidden" onChange={handleReceiptScan} disabled={scanning} />
              <div className={`w-12 h-12 rounded-2xl flex items-center justify-center transition-all ${scanning ? 'bg-neon animate-pulse' : 'glass-card hover:bg-zinc-200 dark:hover:bg-zinc-700'}`}>
                {scanning ? <Loader2 className="w-6 h-6 text-zinc-950 animate-spin" /> : <Camera className="w-6 h-6 text-zinc-500 group-hover:text-zinc-900 dark:group-hover:text-white" />}
              </div>
              <span className="text-[8px] font-bold text-zinc-400 uppercase tracking-widest mt-1 block shimmer-text">Scan</span>
            </label>
          </div>

          <div className="inline-flex items-center gap-2 mb-4">
            <select 
              value={currency} 
              onChange={(e) => setCurrency(e.target.value)}
              className="text-2xl font-bold text-emerald-500/60 dark:text-neon/60 bg-transparent focus:outline-none cursor-pointer appearance-none"
            >
              {CURRENCIES.map(c => <option key={c.code} value={c.code}>{c.symbol}</option>)}
            </select>
            <input
              type="number"
              step="0.01"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              className="bg-transparent text-5xl font-bold text-zinc-900 dark:text-white focus:outline-none w-full max-w-[200px] text-center placeholder:text-zinc-100 dark:placeholder:text-zinc-800 tracking-tighter"
              placeholder="0"
              required
              autoFocus
            />
          </div>
          <div className="flex justify-center gap-2">
            {[100, 500, 1000, 2000].map(val => (
              <button
                key={val}
                type="button"
                onClick={() => setAmount(val.toString())}
                className="px-3 py-1.5 glass-card rounded-lg text-[10px] font-bold text-zinc-500 hover:text-zinc-900 dark:hover:text-white transition-colors"
              >
                +{val}
              </button>
            ))}
          </div>
        </div>

        <div className="glass-card p-6 rounded-3xl space-y-6">
          {/* Category Selection */}
          <div className="space-y-3">
            <label className="flex items-center gap-2 text-[9px] font-bold text-zinc-400 uppercase tracking-[0.2em] px-1 shimmer-text">
              <Tag className="w-3 h-3" /> Category
            </label>
            <div className="grid grid-cols-4 gap-2">
              {CATEGORIES.map(cat => (
                <button
                  key={cat}
                  type="button"
                  onClick={() => setCategory(cat)}
                  className={`flex flex-col items-center gap-1.5 p-2 rounded-xl transition-all active:scale-95 ${
                    category === cat 
                      ? 'bg-zinc-900 dark:bg-neon text-white dark:text-zinc-950 shadow-lg scale-105' 
                      : 'bg-zinc-50 dark:bg-zinc-950 text-zinc-500 hover:bg-zinc-100 dark:hover:bg-zinc-800'
                  }`}
                >
                  <span className="text-xl">{getCategoryEmoji(cat)}</span>
                  <span className="text-[8px] font-bold truncate w-full text-center uppercase tracking-wider shimmer-text">{cat}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Date Selection */}
          <div className="space-y-3">
            <label className="flex items-center gap-2 text-[9px] font-bold text-zinc-400 uppercase tracking-[0.2em] px-1 shimmer-text">
              <Calendar className="w-3 h-3" /> Date
            </label>
            <input
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className="w-full px-4 py-3 bg-zinc-50 dark:bg-zinc-950 border border-zinc-100 dark:border-zinc-800 rounded-xl focus:outline-none focus:ring-4 focus:ring-zinc-900/5 dark:focus:ring-neon/5 focus:border-zinc-900 dark:focus:border-neon transition-all font-bold text-zinc-900 dark:text-white text-sm"
              required
            />
          </div>

          {/* Payment Method */}
          <div className="space-y-3">
            <label className="flex items-center gap-2 text-[9px] font-bold text-zinc-400 uppercase tracking-[0.2em] px-1 shimmer-text">
              <CreditCard className="w-3 h-3" /> Payment Method
            </label>
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => setPaymentMethod('Online')}
                className={`flex-1 py-3 rounded-xl font-bold text-xs transition-all border-2 active:scale-95 ${
                  paymentMethod === 'Online'
                    ? 'border-zinc-900 bg-zinc-900 text-white dark:border-neon dark:bg-neon dark:text-zinc-950'
                    : 'border-zinc-100 bg-zinc-50 text-zinc-400 dark:border-zinc-800 dark:bg-zinc-950'
                }`}
              >
                Online
              </button>
              <button
                type="button"
                onClick={() => setPaymentMethod('Cash')}
                className={`flex-1 py-3 rounded-xl font-bold text-xs transition-all border-2 active:scale-95 ${
                  paymentMethod === 'Cash'
                    ? 'border-zinc-900 bg-zinc-900 text-white dark:border-neon dark:bg-neon dark:text-zinc-950'
                    : 'border-zinc-100 bg-zinc-50 text-zinc-400 dark:border-zinc-800 dark:bg-zinc-950'
                }`}
              >
                Cash
              </button>
            </div>
          </div>

          {/* Notes Input */}
          <div className="space-y-3">
            <label className="flex items-center gap-2 text-[9px] font-bold text-zinc-400 uppercase tracking-[0.2em] px-1 shimmer-text">
              <FileText className="w-3 h-3" /> Notes
            </label>
            <textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="w-full px-4 py-3 bg-zinc-50 dark:bg-zinc-950 border border-zinc-100 dark:border-zinc-800 rounded-xl focus:outline-none focus:ring-4 focus:ring-zinc-900/5 dark:focus:ring-neon/5 focus:border-zinc-900 dark:focus:border-neon transition-all min-h-[80px] resize-none font-medium text-zinc-900 dark:text-white text-sm"
              placeholder="What was this for?"
            />
          </div>

          {/* Tax Deductible Toggle */}
          <div className="flex items-center justify-between p-4 bg-zinc-50 dark:bg-zinc-950 rounded-2xl border border-zinc-100 dark:border-zinc-800/50">
            <div className="flex items-center gap-3">
              <Landmark className={`w-4 h-4 ${isTaxDeductible ? 'text-neon' : 'text-zinc-400'}`} />
              <div>
                <p className="text-xs font-bold text-zinc-900 dark:text-white tracking-tight shimmer-text">Tax Deductible</p>
                <p className="text-[8px] font-bold text-zinc-400 uppercase tracking-wider">Mark for business tax</p>
              </div>
            </div>
            <button
              type="button"
              onClick={() => setIsTaxDeductible(!isTaxDeductible)}
              className={`w-10 h-5 rounded-full transition-all relative ${isTaxDeductible ? 'bg-neon' : 'bg-zinc-200 dark:bg-zinc-800'}`}
            >
              <motion.div 
                animate={{ x: isTaxDeductible ? 20 : 2 }}
                className="absolute top-1 w-3 h-3 bg-white dark:bg-zinc-950 rounded-full shadow-sm"
              />
            </button>
          </div>

          {/* Recurring Toggle */}
          {!editExpense && (
            <div className="space-y-4 pt-2 border-t border-zinc-50 dark:border-zinc-800/50">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <RefreshCw className={`w-4 h-4 ${isRecurring ? 'text-neon animate-spin-slow' : 'text-zinc-400'}`} />
                  <div>
                    <p className="text-xs font-bold text-zinc-900 dark:text-white tracking-tight shimmer-text">Recurring Expense</p>
                    <p className="text-[8px] font-bold text-zinc-400 uppercase tracking-wider">Repeat this automatically</p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setIsRecurring(!isRecurring)}
                  className={`w-10 h-5 rounded-full transition-all relative ${isRecurring ? 'bg-neon' : 'bg-zinc-200 dark:bg-zinc-800'}`}
                >
                  <motion.div 
                    animate={{ x: isRecurring ? 20 : 2 }}
                    className="absolute top-1 w-3 h-3 bg-white dark:bg-zinc-950 rounded-full shadow-sm"
                  />
                </button>
              </div>

              <AnimatePresence>
                {isRecurring && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    className="overflow-hidden"
                  >
                    <div className="grid grid-cols-3 gap-2 pb-2">
                      {(['Daily', 'Weekly', 'Monthly'] as Frequency[]).map(f => (
                        <button
                          key={f}
                          type="button"
                          onClick={() => setFrequency(f)}
                          className={`py-2 rounded-xl text-[9px] font-bold uppercase tracking-wider transition-all border ${
                            frequency === f
                              ? 'bg-zinc-900 dark:bg-neon text-white dark:text-zinc-950 border-zinc-900 dark:border-neon'
                              : 'bg-zinc-50 dark:bg-zinc-950 text-zinc-400 border-zinc-100 dark:border-zinc-800'
                          }`}
                        >
                          {f}
                        </button>
                      ))}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          )}
        </div>

        {error && (
          <div className="p-3 bg-red-50 dark:bg-red-500/10 text-red-600 dark:text-red-400 text-xs rounded-xl border border-red-100 dark:border-red-500/20 font-medium">
            {error}
          </div>
        )}

        <button 
          type="submit" 
          disabled={loading}
          className="w-full py-4 bg-linear-to-br from-zinc-900 to-zinc-700 dark:from-neon dark:to-emerald-400 text-white dark:text-zinc-950 rounded-2xl font-bold text-base flex items-center justify-center gap-2 hover:opacity-90 active:scale-95 transition-all shadow-xl disabled:opacity-50"
        >
          {loading ? (
            <div className="w-5 h-5 border-2 border-white dark:border-zinc-950 border-t-transparent rounded-full animate-spin" />
          ) : (
            <span className="shimmer-text">{editExpense ? 'Update' : 'Save'}</span>
          )}
        </button>
      </form>
    </div>
  );
};
