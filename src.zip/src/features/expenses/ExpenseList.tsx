import React, { useState } from 'react';
import { Expense, CATEGORIES, getCategoryEmoji } from '../../models/types';
import { motion, AnimatePresence } from 'motion/react';
import { Trash2, Edit3, Filter, Search, X, Download, Upload, Loader2 } from 'lucide-react';
import { deleteExpense } from '../../services/expenseService';
import { importFromCSV } from '../../services/importService';
import { addNotification } from '../../services/notificationService';

import { useCurrency } from '../../hooks/useCurrency';
import { AnimatedNumber } from '../../widgets/AnimatedNumber';

interface ExpenseListProps {
  expenses: Expense[];
  onEdit: (expense: Expense) => void;
}

export const ExpenseList: React.FC<ExpenseListProps> = ({ expenses, onEdit }) => {
  const { format } = useCurrency();
  const [filter, setFilter] = useState<string>('All');
  const [search, setSearch] = useState('');
  const [showFilters, setShowFilters] = useState(false);
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const [importing, setImporting] = useState(false);

  const filteredExpenses = expenses.filter(exp => {
    const matchesFilter = filter === 'All' || exp.category === filter;
    const matchesSearch = exp.notes?.toLowerCase().includes(search.toLowerCase()) || 
                         exp.category.toLowerCase().includes(search.toLowerCase());
    return matchesFilter && matchesSearch;
  });

  const handleDelete = async (id: string) => {
    try {
      await deleteExpense(id);
      setDeletingId(null);
    } catch (error) {
      console.error('Delete error:', error);
    }
  };

  const handleImport = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setImporting(true);
    try {
      const count = await importFromCSV(file);
      addNotification({
        title: 'Import Successful',
        message: `Successfully imported ${count} transactions!`,
        type: 'success'
      });
    } catch (error) {
      console.error('Import error:', error);
      addNotification({
        title: 'Import Failed',
        message: 'Failed to import CSV. Please check the format.',
        type: 'error'
      });
    } finally {
      setImporting(false);
    }
  };

  const exportToCSV = () => {
    const headers = ['Date', 'Category', 'Amount', 'Payment Method', 'Notes'];
    const rows = filteredExpenses.map(exp => [
      new Date(exp.date).toLocaleDateString(),
      exp.category,
      exp.amount,
      exp.paymentMethod,
      exp.notes || ''
    ]);

    const csvContent = [
      headers.join(','),
      ...rows.map(row => row.join(','))
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', `expenses_${new Date().toISOString().split('T')[0]}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-8">
      {/* Search and Filter Header */}
      <div className="space-y-3 px-4">
        <div className="flex items-center justify-between mb-0.5">
          <h2 className="text-lg font-bold text-zinc-900 dark:text-white tracking-tight shimmer-text">History</h2>
          <div className="flex items-center gap-2">
            <label className="w-8 h-8 rounded-xl bg-zinc-100 dark:bg-zinc-800 text-zinc-500 flex items-center justify-center transition-all active:scale-95 hover:text-zinc-900 dark:hover:text-white cursor-pointer" title="Import CSV">
              <input type="file" accept=".csv" className="hidden" onChange={handleImport} disabled={importing} />
              {importing ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Upload className="w-3.5 h-3.5" />}
            </label>
            <button 
              onClick={exportToCSV}
              className="w-8 h-8 rounded-xl bg-zinc-100 dark:bg-zinc-800 text-zinc-500 flex items-center justify-center transition-all active:scale-95 hover:text-zinc-900 dark:hover:text-white"
              title="Export to CSV"
            >
              <Download className="w-3.5 h-3.5" />
            </button>
            <button 
              onClick={() => setShowFilters(!showFilters)}
              className={`w-8 h-8 rounded-xl flex items-center justify-center transition-all active:scale-95 ${
                showFilters ? 'bg-zinc-900 text-white dark:bg-neon dark:text-zinc-950' : 'bg-zinc-100 dark:bg-zinc-800 text-zinc-500'
              }`}
            >
              <Filter className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        <div className="relative group">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-zinc-400 group-focus-within:text-zinc-900 dark:group-focus-within:text-white transition-colors" />
          <input
            type="text"
            placeholder="Search transactions..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-10 pr-4 py-2.5 glass-card border border-zinc-100 dark:border-white/5 rounded-xl focus:outline-none focus:ring-4 focus:ring-emerald-500/5 dark:focus:ring-neon/5 focus:border-emerald-500 dark:focus:border-neon transition-all text-[10px] font-medium text-zinc-900 dark:text-white"
          />
        </div>

        <AnimatePresence>
          {showFilters && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="overflow-hidden"
            >
              <div className="flex flex-wrap gap-1.5 py-1.5">
                <FilterChip 
                  label="All" 
                  active={filter === 'All'} 
                  onClick={() => setFilter('All')} 
                />
                {CATEGORIES.map(cat => (
                  <FilterChip 
                    key={cat} 
                    label={cat} 
                    active={filter === cat} 
                    onClick={() => setFilter(cat)} 
                  />
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* List */}
      <div className="space-y-2">
        {filteredExpenses.length === 0 ? (
          <div className="bg-zinc-50 dark:bg-zinc-900/50 p-10 rounded-2xl border-2 border-dashed border-zinc-100 dark:border-zinc-800 text-center">
            <div className="w-12 h-12 bg-white dark:bg-zinc-900 rounded-full flex items-center justify-center mx-auto mb-3 shadow-sm">
              <Search className="w-6 h-6 text-zinc-200 dark:text-zinc-700" />
            </div>
            <p className="text-zinc-500 dark:text-zinc-400 font-bold tracking-tight text-xs">No transactions found</p>
            <p className="text-zinc-400 dark:text-zinc-500 text-[8px] mt-1 uppercase tracking-widest">Adjust your search or filters</p>
          </div>
        ) : (
          filteredExpenses.map((expense, idx) => (
            <motion.div
              key={expense.id}
              initial={{ y: 20, opacity: 0 }}
              whileInView={{ y: 0, opacity: 1 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.03 }}
              className="glass-card p-3 rounded-2xl flex items-center justify-between shadow-sm border border-zinc-100 dark:border-white/5 group hover:shadow-xl hover:scale-[1.01] transition-all"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-zinc-50 dark:bg-zinc-950 rounded-xl flex items-center justify-center text-lg shadow-inner">
                  {getCategoryEmoji(expense.category)}
                </div>
                <div>
                  <p className="font-bold text-zinc-900 dark:text-white text-xs tracking-tight leading-tight shimmer-text">{expense.category}</p>
                  <div className="flex items-center gap-1.5 mt-0.5">
                    <p className="text-[8px] font-bold text-zinc-400 uppercase tracking-widest shimmer-text">
                      {new Date(expense.date).toLocaleDateString(undefined, { month: 'short', day: 'numeric' })}
                    </p>
                    {expense.isRecurring && (
                      <span className="px-1.5 py-0.5 bg-emerald-500/10 dark:bg-neon/10 text-emerald-600 dark:text-neon text-[6px] font-black uppercase tracking-tighter rounded-sm shimmer-text">
                        Recurring
                      </span>
                    )}
                    {expense.notes && (
                      <span className="text-zinc-200 dark:text-zinc-800">•</span>
                    )}
                    <p className="text-[8px] font-medium text-zinc-500 truncate max-w-[80px] shimmer-text">{expense.notes}</p>
                  </div>
                </div>
              </div>
              
              <div className="flex flex-col items-end gap-1.5">
                <p className="font-bold text-zinc-900 dark:text-neon text-sm tracking-tighter">
                  -<AnimatedNumber value={expense.amount} className="dark:text-neon" />
                </p>
                <div className="flex items-center gap-1.5">
                  {deletingId === expense.id ? (
                    <div className="flex items-center gap-1.5">
                      <button 
                        onClick={() => handleDelete(expense.id)}
                        className="px-2.5 py-1 bg-red-600 text-white text-[8px] font-bold rounded-full shadow-lg shadow-red-100"
                      >
                        Confirm
                      </button>
                      <button 
                        onClick={() => setDeletingId(null)}
                        className="p-1 text-zinc-400 hover:bg-zinc-100 dark:hover:bg-zinc-800 rounded-full"
                      >
                        <X className="w-2.5 h-2.5" />
                      </button>
                    </div>
                  ) : (
                    <div className="flex items-center gap-1.5 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button 
                        onClick={() => onEdit(expense)}
                        className="p-1 text-zinc-400 hover:text-zinc-900 dark:hover:text-white hover:bg-zinc-50 dark:hover:bg-zinc-800 rounded-full transition-colors"
                      >
                        <Edit3 className="w-3 h-3" />
                      </button>
                      <button 
                        onClick={() => setDeletingId(expense.id)}
                        className="p-1 text-zinc-400 hover:text-red-600 hover:bg-red-50 rounded-full transition-colors"
                      >
                        <Trash2 className="w-3 h-3" />
                      </button>
                    </div>
                  )}
                </div>
              </div>
            </motion.div>
          ))
        )}
      </div>
    </div>
  );
};

const FilterChip: React.FC<{ label: string; active: boolean; onClick: () => void }> = ({ label, active, onClick }) => (
  <button
    onClick={onClick}
    className={`px-3 py-1.5 rounded-full text-[8px] font-bold uppercase tracking-widest transition-all active:scale-95 ${
      active 
        ? 'bg-linear-to-br from-zinc-900 to-zinc-700 dark:from-neon dark:to-emerald-400 text-white dark:text-zinc-950 shadow-xl' 
        : 'glass-card text-zinc-400 border border-zinc-100 dark:border-white/5 hover:border-zinc-300 shimmer-text'
    }`}
  >
    {label}
  </button>
);


