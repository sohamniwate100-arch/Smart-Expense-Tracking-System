import React, { useState, useEffect } from 'react';
import { RecurringExpense, getCategoryEmoji } from '../../models/types';
import { motion, AnimatePresence } from 'motion/react';
import { Trash2, RefreshCw, Calendar, Clock, AlertCircle, X, Edit3 } from 'lucide-react';
import { addNotification } from '../../services/notificationService';
import { processRecurringExpenses, subscribeToRecurringExpenses, deleteRecurringExpense, updateRecurringExpense } from '../../services/recurringExpenseService';
import { useCurrency } from '../../hooks/useCurrency';
import { AnimatedNumber } from '../../widgets/AnimatedNumber';

interface RecurringExpenseListProps {
  onEdit: (expense: RecurringExpense) => void;
}

export const RecurringExpenseList: React.FC<RecurringExpenseListProps> = ({ onEdit }) => {
  const [recurringExpenses, setRecurringExpenses] = useState<RecurringExpense[]>([]);
  const [loading, setLoading] = useState(true);
  const { format } = useCurrency();

  const [deletingId, setDeletingId] = useState<string | null>(null);

  const [syncing, setSyncing] = useState(false);

  useEffect(() => {
    const unsubscribe = subscribeToRecurringExpenses((data) => {
      setRecurringExpenses(data);
      setLoading(false);
    });
    return () => unsubscribe();
  }, []);

  const handleSync = async () => {
    setSyncing(true);
    try {
      await processRecurringExpenses();
      addNotification({
        title: 'Data Synced',
        message: 'Your recurring expenses have been synchronized.',
        type: 'success'
      });
    } catch (error) {
      console.error('Sync error:', error);
    } finally {
      setSyncing(false);
    }
  };

  const handleDelete = async (id: string) => {
    try {
      await deleteRecurringExpense(id);
      setDeletingId(null);
    } catch (error) {
      console.error('Delete error:', error);
    }
  };

  const toggleActive = async (expense: RecurringExpense) => {
    try {
      await updateRecurringExpense(expense.id, { active: !expense.active });
    } catch (error) {
      console.error('Toggle error:', error);
    }
  };

  const monthlyCommitment = recurringExpenses
    .filter(e => e.active)
    .reduce((sum, e) => {
      if (e.frequency === 'Daily') return sum + (e.amount * 30);
      if (e.frequency === 'Weekly') return sum + (e.amount * 4);
      return sum + e.amount;
    }, 0);

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <RefreshCw className="w-8 h-8 text-zinc-300 animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="px-2 flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-zinc-900 dark:text-white tracking-tight shimmer-text">Recurring Expenses</h2>
          <p className="text-zinc-400 dark:text-zinc-500 text-[10px] font-bold uppercase tracking-widest mt-1 shimmer-text">Manage your subscriptions and repeating bills</p>
        </div>
        <div className="text-right flex flex-col items-end gap-2">
          <button 
            onClick={handleSync}
            disabled={syncing}
            className="flex items-center gap-1.5 px-3 py-1.5 glass-card rounded-xl text-[8px] font-bold uppercase tracking-widest hover:bg-zinc-100 dark:hover:bg-zinc-800 transition-all active:scale-95 disabled:opacity-50"
          >
            <RefreshCw className={`w-3 h-3 ${syncing ? 'animate-spin' : ''}`} />
            {syncing ? 'Syncing...' : 'Sync Data'}
          </button>
          <div>
            <p className="text-[8px] font-bold text-zinc-400 uppercase tracking-widest mb-1 shimmer-text">Monthly Commitment</p>
            <p className="text-xl font-bold text-emerald-600 dark:text-neon tracking-tight">
              <AnimatedNumber value={monthlyCommitment} />
            </p>
          </div>
        </div>
      </div>

      <div className="space-y-3">
        {recurringExpenses.length === 0 ? (
          <div className="bg-white dark:bg-zinc-900 p-12 rounded-[2.5rem] border border-dashed border-zinc-200 dark:border-zinc-800 text-center">
            <div className="w-16 h-16 bg-zinc-50 dark:bg-zinc-950 rounded-full flex items-center justify-center mx-auto mb-4">
              <RefreshCw className="w-8 h-8 text-zinc-200 dark:text-zinc-800" />
            </div>
            <p className="text-zinc-500 dark:text-zinc-400 font-bold tracking-tight shimmer-text">No recurring expenses yet</p>
            <p className="text-zinc-400 dark:text-zinc-500 text-[8px] mt-1 uppercase tracking-widest shimmer-text">Add one from the 'Add' tab</p>
          </div>
        ) : (
          recurringExpenses.map((expense, idx) => (
            <motion.div
              key={expense.id}
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: idx * 0.05 }}
              className={`bg-white dark:bg-zinc-900 p-5 rounded-[2rem] border shadow-sm transition-all group ${
                expense.active ? 'border-zinc-100 dark:border-zinc-800/50' : 'border-zinc-50 dark:border-zinc-900 opacity-60'
              }`}
            >
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-zinc-50 dark:bg-zinc-950 rounded-2xl flex items-center justify-center text-2xl shadow-inner">
                    {getCategoryEmoji(expense.category)}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <p className="font-bold text-zinc-900 dark:text-white text-sm tracking-tight shimmer-text">{expense.category}</p>
                      <span className="px-2 py-0.5 bg-zinc-100 dark:bg-zinc-800 text-zinc-500 dark:text-zinc-400 text-[7px] font-bold uppercase tracking-wider rounded-full shimmer-text">
                        {expense.frequency}
                      </span>
                    </div>
                    <p className="text-[9px] text-zinc-400 dark:text-zinc-500 font-bold uppercase tracking-wider mt-1 flex items-center gap-1 shimmer-text">
                      <Calendar className="w-2.5 h-2.5" /> Next: {new Date(expense.nextDueDate).toLocaleDateString(undefined, { month: 'short', day: 'numeric' })}
                    </p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-bold text-zinc-900 dark:text-white text-lg tracking-tight">
                    <AnimatedNumber value={expense.amount} />
                  </p>
                  <p className="text-[8px] text-zinc-400 dark:text-zinc-500 font-bold uppercase tracking-wider shimmer-text">{expense.paymentMethod}</p>
                </div>
              </div>

              <div className="flex items-center justify-between pt-4 border-t border-zinc-50 dark:border-zinc-800/50">
                <div className="flex items-center gap-4">
                  <button
                    onClick={() => toggleActive(expense)}
                    className={`flex items-center gap-1.5 text-[9px] font-bold uppercase tracking-wider transition-colors shimmer-text ${
                      expense.active ? 'text-emerald-500' : 'text-zinc-400'
                    }`}
                  >
                    <div className={`w-2 h-2 rounded-full ${expense.active ? 'bg-emerald-500 animate-pulse' : 'bg-zinc-300'}`} />
                    {expense.active ? 'Active' : 'Paused'}
                  </button>
                  {expense.lastProcessedDate && (
                    <div className="flex items-center gap-1 text-[9px] font-bold text-zinc-400 uppercase tracking-wider shimmer-text">
                      <Clock className="w-2.5 h-2.5" />
                      Last: {new Date(expense.lastProcessedDate).toLocaleDateString(undefined, { month: 'short', day: 'numeric' })}
                    </div>
                  )}
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => onEdit(expense)}
                    className="p-2 text-zinc-400 hover:text-zinc-900 dark:hover:text-white hover:bg-zinc-50 dark:hover:bg-zinc-800 rounded-xl transition-all"
                  >
                    <Edit3 className="w-4 h-4" />
                  </button>
                  {deletingId === expense.id ? (
                    <div className="flex items-center gap-1.5">
                      <button 
                        onClick={() => handleDelete(expense.id)}
                        className="px-2.5 py-1 bg-red-600 text-white text-[8px] font-bold rounded-full shadow-lg shadow-red-100"
                      >
                        Confirm
                      </button>
                      <button 
                        onClick={() => setDeletingId(null)}
                        className="p-1 text-zinc-400 hover:bg-zinc-100 dark:hover:bg-zinc-800 rounded-full"
                      >
                        <X className="w-2.5 h-2.5" />
                      </button>
                    </div>
                  ) : (
                    <button
                      onClick={() => setDeletingId(expense.id)}
                      className="p-2 text-zinc-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-500/10 rounded-xl transition-all"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                </div>
              </div>
            </motion.div>
          ))
        )}
      </div>

      <div className="bg-zinc-50 dark:bg-zinc-900/50 p-6 rounded-[2rem] border border-zinc-100 dark:border-zinc-800/50 flex items-start gap-4">
        <div className="w-10 h-10 bg-white dark:bg-zinc-900 rounded-xl flex items-center justify-center shrink-0 shadow-sm">
          <AlertCircle className="w-5 h-5 text-zinc-400" />
        </div>
        <div>
          <p className="text-xs font-bold text-zinc-900 dark:text-white tracking-tight shimmer-text">How it works</p>
          <p className="text-[10px] text-zinc-500 dark:text-zinc-400 leading-relaxed mt-1 shimmer-text">
            Recurring expenses are automatically added to your history on their due date. 
            You can pause them at any time if you want to skip a cycle.
          </p>
        </div>
      </div>
    </div>
  );
};
