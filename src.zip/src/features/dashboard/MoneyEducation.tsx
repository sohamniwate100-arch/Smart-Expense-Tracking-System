import React from 'react';
import { motion } from 'motion/react';
import { 
  Lightbulb, 
  TrendingUp, 
  ShieldCheck, 
  PiggyBank, 
  ArrowUpRight, 
  BookOpen,
  Zap,
  Target
} from 'lucide-react';

const TIPS = [
  {
    title: "The 50/30/20 Rule",
    description: "Allocate 50% of income to Needs, 30% to Wants, and 20% to Savings or Debt repayment. It's a simple way to balance your life and future.",
    icon: <PiggyBank className="w-5 h-5 text-emerald-500" />,
    color: "emerald"
  },
  {
    title: "Emergency Fund First",
    description: "Aim to save 3-6 months of essential expenses. This safety net prevents you from taking high-interest debt when life happens.",
    icon: <ShieldCheck className="w-5 h-5 text-blue-500" />,
    color: "blue"
  },
  {
    title: "The Power of Compounding",
    description: "Investing small amounts early is better than large amounts later. Time is your greatest asset in building wealth.",
    icon: <TrendingUp className="w-5 h-5 text-purple-500" />,
    color: "purple"
  },
  {
    title: "Avoid Lifestyle Creep",
    description: "When your income increases, try to keep your expenses the same. Redirect the extra money into investments instead of luxury.",
    icon: <ArrowUpRight className="w-5 h-5 text-amber-500" />,
    color: "amber"
  },
  {
    title: "Pay Yourself First",
    description: "Treat your savings like a mandatory bill. Automate a transfer to your savings account as soon as you get paid.",
    icon: <Zap className="w-5 h-5 text-cyan-500" />,
    color: "cyan"
  },
  {
    title: "Track Every Penny",
    description: "Awareness is the first step to control. Knowing exactly where your money goes helps you identify and cut 'leaks'.",
    icon: <Target className="w-5 h-5 text-rose-500" />,
    color: "rose"
  }
];

export const MoneyEducation: React.FC = () => {
  return (
    <div className="space-y-6 pb-20">
      <div className="px-1">
        <h2 className="text-2xl font-bold tracking-tight text-zinc-900 dark:text-white mb-1">Money Mastery</h2>
        <p className="text-zinc-500 dark:text-zinc-400 text-sm">Smart tips to help you build a better financial future.</p>
      </div>

      <div className="grid grid-cols-1 gap-4">
        {TIPS.map((tip, idx) => (
          <motion.div
            key={tip.title}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: idx * 0.1 }}
            className="glass-card p-6 rounded-[2rem] border border-zinc-100 dark:border-zinc-800/50 shadow-sm hover:shadow-md transition-all group"
          >
            <div className="flex items-start gap-4">
              <div className={`w-12 h-12 rounded-2xl flex items-center justify-center bg-${tip.color}-500/10 dark:bg-${tip.color}-500/20 group-hover:scale-110 transition-transform`}>
                {tip.icon}
              </div>
              <div className="flex-1 space-y-1.5">
                <h3 className="font-bold text-zinc-900 dark:text-white tracking-tight">{tip.title}</h3>
                <p className="text-zinc-500 dark:text-zinc-400 text-xs leading-relaxed">
                  {tip.description}
                </p>
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      <div className="glass-dark p-8 rounded-[2.5rem] text-white relative overflow-hidden shadow-2xl">
        <div className="relative z-10 space-y-4">
          <div className="w-10 h-10 bg-white/10 rounded-xl flex items-center justify-center backdrop-blur-md border border-white/10">
            <BookOpen className="w-5 h-5 text-white" />
          </div>
          <h3 className="text-xl font-bold tracking-tight">Did you know?</h3>
          <p className="text-zinc-300 text-sm leading-relaxed">
            The average millionaire has seven different streams of income. Diversifying how you earn is just as important as how you save.
          </p>
          <div className="pt-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 bg-white/10 rounded-full border border-white/10 backdrop-blur-md">
              <Lightbulb className="w-3 h-3 text-amber-400" />
              <span className="text-[10px] font-bold uppercase tracking-wider">Financial Wisdom</span>
            </div>
          </div>
        </div>
        
        {/* Decorative elements */}
        <div className="absolute -right-10 -bottom-10 w-40 h-40 bg-white/5 rounded-full blur-3xl" />
        <div className="absolute -left-10 -top-10 w-40 h-40 bg-zinc-400/10 rounded-full blur-2xl" />
      </div>
    </div>
  );
};
