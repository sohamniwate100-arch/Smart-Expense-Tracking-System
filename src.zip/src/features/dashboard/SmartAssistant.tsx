import React, { useEffect } from 'react';
import { motion } from 'motion/react';
import { Sparkles, TrendingUp, TrendingDown, AlertCircle, Lightbulb } from 'lucide-react';
import { Expense } from '../../models/types';
import { useCurrency } from '../../hooks/useCurrency';
import { AnimatedNumber } from '../../widgets/AnimatedNumber';

import { addNotification, getNotifications } from '../../services/notificationService';

interface Insight {
  type: string;
  title: string;
  description: React.ReactNode;
  textDescription: string;
  icon: React.ReactNode;
  color: string;
}

interface SmartAssistantProps {
  expenses: Expense[];
  income: number;
}

export const SmartAssistant: React.FC<SmartAssistantProps> = ({ expenses, income }) => {
  const { format } = useCurrency();

  const getInsights = (): Insight[] => {
    const insights: Insight[] = [];
    const now = new Date();
    const currentMonth = now.getMonth();
    const currentYear = now.getFullYear();

    const currentMonthExpenses = expenses.filter(e => {
      const d = new Date(e.date);
      return d.getMonth() === currentMonth && d.getFullYear() === currentYear && e.category !== 'Invested';
    });

    const totalSpent = currentMonthExpenses.reduce((sum, e) => sum + e.amount, 0);
    const dayOfMonth = now.getDate();
    const daysInMonth = new Date(currentYear, currentMonth + 1, 0).getDate();
    const daysRemaining = daysInMonth - dayOfMonth + 1;
    const projectedSpend = (totalSpent / dayOfMonth) * daysInMonth;
    const remainingBudget = Math.max(0, income - totalSpent);
    const dailyBudget = remainingBudget / daysRemaining;

    // 1. Projection Insight
    if (projectedSpend > income) {
      insights.push({
        type: 'alert',
        title: 'Budget Warning',
        description: (
          <>
            You're spending faster than you earn. To stay on track, try to spend less than <AnimatedNumber value={dailyBudget} /> per day for the rest of the month.
          </>
        ),
        textDescription: `You're spending faster than you earn. To stay on track, try to spend less than ${format(dailyBudget)} per day for the rest of the month.`,
        icon: <AlertCircle className="w-4 h-4 text-red-500" />,
        color: 'red'
      });
    } else if (projectedSpend > income * 0.8) {
      insights.push({
        type: 'warning',
        title: 'Tight Budget',
        description: (
          <>
            You've used <AnimatedNumber value={Math.round((projectedSpend / income) * 100)} formatValue={(v) => `${v}%`} /> of your income. It might be a good time to slow down your spending.
          </>
        ),
        textDescription: `You've used ${Math.round((projectedSpend / income) * 100)}% of your income. It might be a good time to slow down your spending.`,
        icon: <TrendingUp className="w-4 h-4 text-amber-500" />,
        color: 'amber'
      });
    }

    // 2. Category Insight
    const categoryTotals: Record<string, number> = {};
    currentMonthExpenses.forEach(e => {
      categoryTotals[e.category] = (categoryTotals[e.category] || 0) + e.amount;
    });

    const topCategory = Object.entries(categoryTotals).sort((a, b) => b[1] - a[1])[0];
    if (topCategory && topCategory[1] > income * 0.3) {
      insights.push({
        type: 'info',
        title: 'High Category Spend',
        description: (
          <>
            {topCategory[0]} is taking up <AnimatedNumber value={Math.round((topCategory[1] / income) * 100)} formatValue={(v) => `${v}%`} /> of your budget. Maybe look for ways to save here?
          </>
        ),
        textDescription: `${topCategory[0]} is taking up ${Math.round((topCategory[1] / income) * 100)}% of your budget. Maybe look for ways to save here?`,
        icon: <Lightbulb className="w-4 h-4 text-blue-500" />,
        color: 'blue'
      });
    }

    // 3. Positive Reinforcement
    if (totalSpent < income * 0.4 && dayOfMonth > 15) {
      insights.push({
        type: 'success',
        title: 'Excellent Saving',
        description: "Great job! You've saved more than half of your income so far. Keep it up!",
        textDescription: "Great job! You've saved more than half of your income so far. Keep it up!",
        icon: <Sparkles className="w-4 h-4 text-emerald-500" />,
        color: 'emerald'
      });
    }

    return insights;
  };

  const insights = getInsights();

  // Trigger notifications for new insights
  useEffect(() => {
    const existing = getNotifications();
    insights.forEach(insight => {
      const alreadyNotified = existing.some(n => n.title === insight.title && n.message === insight.textDescription);
      if (!alreadyNotified) {
        addNotification({
          title: insight.title,
          message: insight.textDescription,
          type: insight.type as any,
        });
      }
    });
  }, [insights]);

  if (insights.length === 0) return null;

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2 px-1">
        <Sparkles className="w-4 h-4 text-zinc-400" />
        <h3 className="font-bold text-sm uppercase tracking-widest text-zinc-400">Smart Assistant</h3>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {insights.map((insight, idx) => (
          <motion.div
            key={idx}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: idx * 0.1 }}
            className={`p-5 rounded-[2rem] border flex gap-4 items-start transition-all hover:scale-[1.02] ${
              insight.color === 'red' ? 'bg-red-50/50 dark:bg-red-950/10 border-red-100 dark:border-red-900/20' :
              insight.color === 'amber' ? 'bg-amber-50/50 dark:bg-amber-950/10 border-amber-100 dark:border-amber-900/20' :
              insight.color === 'blue' ? 'bg-blue-50/50 dark:bg-blue-950/10 border-blue-100 dark:border-blue-900/20' :
              'bg-emerald-50/50 dark:bg-emerald-950/10 border-emerald-100 dark:border-emerald-900/20'
            }`}
          >
            <div className={`p-2 rounded-xl shrink-0 ${
              insight.color === 'red' ? 'bg-red-100 dark:bg-red-900/30' :
              insight.color === 'amber' ? 'bg-amber-100 dark:bg-amber-900/30' :
              insight.color === 'blue' ? 'bg-blue-100 dark:bg-blue-900/30' :
              'bg-emerald-100 dark:bg-emerald-900/30'
            }`}>
              {insight.icon}
            </div>
            <div>
              <h4 className={`font-bold text-sm tracking-tight mb-1 ${
                insight.color === 'red' ? 'text-red-900 dark:text-red-400' :
                insight.color === 'amber' ? 'text-amber-900 dark:text-amber-400' :
                insight.color === 'blue' ? 'text-blue-900 dark:text-blue-400' :
                'text-emerald-900 dark:text-emerald-400'
              }`}>
                {insight.title}
              </h4>
              <p className="text-xs text-zinc-600 dark:text-zinc-400 leading-relaxed font-medium">
                {insight.description}
              </p>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
};
