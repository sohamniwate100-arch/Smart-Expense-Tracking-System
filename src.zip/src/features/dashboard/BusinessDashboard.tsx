import React from 'react';
import { Expense, BUSINESS_CATEGORIES, getCategoryEmoji } from '../../models/types';
import { useAuth } from '../../core/AuthContext';
import { motion } from 'motion/react';
import { 
  TrendingUp, 
  TrendingDown, 
  ArrowRight, 
  BarChart3, 
  Briefcase, 
  Users, 
  Building2, 
  Megaphone, 
  Package,
  DollarSign,
  PieChart as PieChartIcon
} from 'lucide-react';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from 'recharts';
import { FinancialPulse } from '../../widgets/FinancialPulse';

import { useCurrency } from '../../hooks/useCurrency';
import { AnimatedNumber } from '../../widgets/AnimatedNumber';

interface BusinessDashboardProps {
  expenses: Expense[];
  onViewAll: () => void;
  onViewEducation: () => void;
}

export const BusinessDashboard: React.FC<BusinessDashboardProps> = ({ expenses, onViewAll, onViewEducation }) => {
  const { profile } = useAuth();
  const { format } = useCurrency();
  
  const totalRevenue = profile?.income || 0;
  
  const businessExpenses = expenses
    .filter(exp => BUSINESS_CATEGORIES.includes(exp.category as any))
    .reduce((sum, exp) => sum + exp.amount, 0);
    
  // Monthly stats
  const currentMonth = new Date().getMonth();
  const currentYear = new Date().getFullYear();
  
  const monthlyBusinessExpenses = expenses
    .filter(exp => {
      const d = new Date(exp.date);
      return d.getMonth() === currentMonth && d.getFullYear() === currentYear && BUSINESS_CATEGORIES.includes(exp.category as any);
    })
    .reduce((sum, exp) => sum + exp.amount, 0);

  const monthlyRevenue = totalRevenue; // Assuming monthly revenue for now
  const netProfit = monthlyRevenue - monthlyBusinessExpenses;
  const profitMargin = monthlyRevenue > 0 ? (netProfit / monthlyRevenue) * 100 : 0;

  const recentTransactions = expenses.slice(0, 5);

  // Chart data
  const chartData = BUSINESS_CATEGORIES.map(cat => ({
    name: cat,
    value: expenses.filter(e => e.category === cat).reduce((s, e) => s + e.amount, 0)
  })).filter(item => item.value > 0);

  const COLORS = ['#10b981', '#3b82f6', '#f59e0b', '#8b5cf6', '#6b7280'];

  return (
    <div className="space-y-6">
      {/* Business Performance Header */}
      <motion.div
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        className="bg-zinc-900 dark:bg-zinc-900/50 p-4 rounded-2xl text-white shadow-2xl relative overflow-hidden border border-white/5"
      >
        <div className="relative z-10">
          <div className="flex justify-between items-start mb-3">
            <div>
              <div className="flex items-center gap-1 mb-1">
                <div className="px-1 py-0.5 bg-white/10 dark:bg-neon/10 text-white dark:text-neon rounded-full text-[6px] font-bold uppercase tracking-[0.15em] border border-white/10 dark:border-neon/20 backdrop-blur-md">
                  {profile?.businessType || 'Business'}
                </div>
                <div className="px-1 py-0.5 bg-white/10 dark:bg-neon/10 text-white dark:text-neon rounded-full text-[6px] font-bold uppercase tracking-[0.15em] border border-white/10 dark:border-neon/20 backdrop-blur-md">
                  {profile?.businessCategory || 'B2C'}
                </div>
              </div>
              <h2 className="text-xl font-bold tracking-tight mb-0.5">
                <AnimatedNumber value={monthlyRevenue} />
              </h2>
              <p className="text-zinc-400 text-[7px] font-bold uppercase tracking-[0.2em]">Monthly Revenue</p>
            </div>
            <div className={`px-1.5 py-0.5 rounded-lg backdrop-blur-md flex items-center gap-1 border ${netProfit >= 0 ? 'bg-neon/10 text-neon border-neon/20' : 'bg-red-500/10 text-red-400 border-red-500/20'}`}>
              <TrendingUp className={`w-2.5 h-2.5 ${netProfit < 0 && 'rotate-180'}`} />
              <span className="text-[9px] font-bold tracking-tight">{profitMargin.toFixed(1)}% Margin</span>
            </div>
          </div>
          
          <div className="grid grid-cols-2 gap-2">
            <div className="bg-white/5 rounded-xl p-2.5 border border-white/5">
              <p className="text-[7px] font-bold uppercase tracking-[0.2em] text-zinc-400 mb-0.5">Net Profit</p>
              <p className={`font-bold text-base tracking-tight ${netProfit >= 0 ? 'text-neon' : 'text-red-400'}`}>
                <AnimatedNumber value={netProfit} className={netProfit >= 0 ? 'text-neon' : 'text-red-400'} />
              </p>
            </div>
            <div className="bg-white/5 rounded-xl p-2.5 border border-white/5">
              <p className="text-[7px] font-bold uppercase tracking-[0.2em] text-zinc-400 mb-0.5">Op. Expenses</p>
              <p className="font-bold text-base tracking-tight text-zinc-100">
                <AnimatedNumber value={monthlyBusinessExpenses} />
              </p>
            </div>
          </div>
        </div>
        
        <div className="absolute -right-20 -top-20 w-64 h-64 bg-white/5 dark:bg-zinc-900/5 rounded-full blur-3xl" />
        <div className="absolute -left-20 -bottom-20 w-64 h-64 bg-zinc-400/10 rounded-full blur-3xl" />
      </motion.div>

      <FinancialPulse expenses={expenses} title="Business Pulse" />

      {/* Expense Distribution Chart */}
      {chartData.length > 0 && (
        <div className="bg-white dark:bg-zinc-900 p-4 rounded-2xl border border-zinc-100 dark:border-zinc-800/50 shadow-sm">
          <h3 className="font-bold text-[10px] text-zinc-900 dark:text-white mb-2.5 flex items-center gap-2">
            <PieChartIcon className="w-3 h-3 text-zinc-400" />
            <span className="uppercase tracking-[0.1em] text-[7px] font-bold">Expense Distribution</span>
          </h3>
          <div className="h-[120px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={chartData}
                  cx="50%"
                  cy="50%"
                  innerRadius={35}
                  outerRadius={50}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {chartData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={index === 0 ? '#00FF88' : COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip 
                  contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)', backgroundColor: '#18181b', color: '#fff', fontSize: '9px' }}
                  itemStyle={{ color: '#fff' }}
                  formatter={(value: number) => [<AnimatedNumber value={value} />, 'Amount']}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="grid grid-cols-2 gap-1 mt-2">
            {chartData.map((item, index) => (
              <div key={item.name} className="flex items-center gap-1">
                <div className="w-1 h-1 rounded-full" style={{ backgroundColor: index === 0 ? '#00FF88' : COLORS[index % COLORS.length] }} />
                <span className="text-[7px] font-bold text-zinc-500 dark:text-zinc-400 uppercase tracking-wider">{item.name}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Business Metrics Grid */}
      <div className="grid grid-cols-2 gap-2">
        <div className="bg-white dark:bg-zinc-900 p-3 rounded-xl border border-zinc-100 dark:border-zinc-800/50 shadow-sm">
          <div className="flex items-center gap-1.5 mb-1.5">
            <div className="w-6 h-6 bg-zinc-50 dark:bg-zinc-950 rounded-lg flex items-center justify-center">
              <Users className="w-3 h-3 text-zinc-400" />
            </div>
            <span className="text-[7px] font-bold text-zinc-400 uppercase tracking-wider">Salaries</span>
          </div>
          <p className="text-base font-bold text-zinc-900 dark:text-white tracking-tight">
            <AnimatedNumber value={expenses.filter(e => e.category === 'Salaries').reduce((s, e) => s + e.amount, 0)} />
          </p>
        </div>

        <div className="bg-white dark:bg-zinc-900 p-3 rounded-xl border border-zinc-100 dark:border-zinc-800/50 shadow-sm">
          <div className="flex items-center gap-1.5 mb-1.5">
            <div className="w-6 h-6 bg-zinc-50 dark:bg-zinc-950 rounded-lg flex items-center justify-center">
              <Megaphone className="w-3 h-3 text-zinc-400" />
            </div>
            <span className="text-[7px] font-bold text-zinc-400 uppercase tracking-wider">Marketing</span>
          </div>
          <p className="text-base font-bold text-zinc-900 dark:text-white tracking-tight">
            <AnimatedNumber value={expenses.filter(e => e.category === 'Marketing').reduce((s, e) => s + e.amount, 0)} />
          </p>
        </div>
      </div>

      {/* Operating Costs Breakdown */}
      <div className="bg-white dark:bg-zinc-900 p-4 rounded-2xl border border-zinc-100 dark:border-zinc-800/50 shadow-sm">
        <h3 className="font-bold text-[10px] text-zinc-900 dark:text-white mb-2.5 flex items-center gap-2">
          <BarChart3 className="w-3 h-3 text-zinc-400" />
          <span className="uppercase tracking-[0.1em] text-[7px] font-bold">Operating Costs</span>
        </h3>
        <div className="space-y-2.5">
          {[
            { label: 'Inventory', icon: Package, color: 'bg-neon' },
            { label: 'Rent', icon: Building2, color: 'bg-zinc-400' },
            { label: 'Utilities', icon: DollarSign, color: 'bg-zinc-200 dark:bg-zinc-700' },
          ].map(item => {
            const amount = expenses.filter(e => e.category === item.label).reduce((s, e) => s + e.amount, 0);
            const percentage = monthlyBusinessExpenses > 0 ? (amount / monthlyBusinessExpenses) * 100 : 0;
            return (
              <div key={item.label} className="space-y-1">
                <div className="flex justify-between text-[9px] font-bold">
                  <div className="flex items-center gap-1">
                    <item.icon className="w-3 h-3 text-zinc-400" />
                    <span className="text-zinc-600 dark:text-zinc-400">{item.label}</span>
                  </div>
                  <span className="text-zinc-900 dark:text-white">
                    <AnimatedNumber value={amount} />
                  </span>
                </div>
                <div className="h-1 w-full bg-zinc-100 dark:bg-zinc-800 rounded-full overflow-hidden">
                  <motion.div 
                    initial={{ width: 0 }}
                    animate={{ width: `${percentage}%` }}
                    className={`h-full ${item.color} rounded-full`}
                  />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Recent Transactions */}
      <div className="space-y-3">
        <div className="flex items-center justify-between px-1">
          <h3 className="font-bold text-base tracking-tight text-zinc-900 dark:text-white">Business Ledger</h3>
          <button 
            onClick={onViewAll}
            className="text-zinc-400 dark:text-zinc-500 text-[8px] font-bold uppercase tracking-wider flex items-center gap-1 hover:text-zinc-900 dark:hover:text-neon transition-colors"
          >
            Full Report <ArrowRight className="w-3 h-3" />
          </button>
        </div>

        <div className="space-y-2">
          {recentTransactions.map((expense, idx) => (
            <motion.div
              key={expense.id}
              initial={{ x: -20, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              transition={{ delay: idx * 0.05 }}
              className="bg-white dark:bg-zinc-900 p-3 rounded-xl flex items-center justify-between shadow-sm border border-zinc-50 dark:border-zinc-800/50 hover:shadow-md transition-all"
            >
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 bg-zinc-50 dark:bg-zinc-950 rounded-lg flex items-center justify-center text-lg relative">
                  {getCategoryEmoji(expense.category)}
                </div>
                <div>
                  <p className="font-bold text-zinc-900 dark:text-white text-xs leading-tight tracking-tight">{expense.category}</p>
                  <p className="text-[8px] text-zinc-400 dark:text-zinc-500 font-bold uppercase tracking-wider mt-0.5">
                    {new Date(expense.date).toLocaleDateString(undefined, { month: 'short', day: 'numeric' })} • {expense.paymentMethod}
                  </p>
                </div>
              </div>
              <p className="font-bold text-zinc-900 dark:text-white text-sm tracking-tight">
                -<AnimatedNumber value={expense.amount} />
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
};
