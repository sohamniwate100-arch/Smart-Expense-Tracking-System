import React from 'react';
import { Expense, getCategoryEmoji } from '../../models/types';
import { useAuth } from '../../core/AuthContext';
import { motion } from 'motion/react';
import { TrendingUp, TrendingDown, Wallet, ArrowRight, Target, PiggyBank, BarChart3, CreditCard, AlertTriangle, BookOpen } from 'lucide-react';
import { BusinessDashboard } from './BusinessDashboard';
import { SmartAssistant } from './SmartAssistant';
import { FinancialPulse } from '../../widgets/FinancialPulse';

import { useCurrency } from '../../hooks/useCurrency';
import { AnimatedNumber } from '../../widgets/AnimatedNumber';

interface DashboardProps {
  expenses: Expense[];
  onViewAll: () => void;
  onViewEducation: () => void;
}

export const Dashboard: React.FC<DashboardProps> = ({ expenses, onViewAll, onViewEducation }) => {
  const { profile } = useAuth();
  const { format } = useCurrency();
  
  if (profile?.profession === 'Business Owner') {
    return <BusinessDashboard expenses={expenses} onViewAll={onViewAll} onViewEducation={onViewEducation} />;
  }

  const totalExpenses = expenses
    .filter(exp => exp.category !== 'Invested')
    .reduce((sum, exp) => sum + exp.amount, 0);
  
  const totalInvested = expenses
    .filter(exp => exp.category === 'Invested')
    .reduce((sum, exp) => sum + exp.amount, 0);
  
  // Monthly expenses (current month)
  const currentMonth = new Date().getMonth();
  const currentYear = new Date().getFullYear();
  const monthlyExpenses = expenses
    .filter(exp => {
      const d = new Date(exp.date);
      return d.getMonth() === currentMonth && d.getFullYear() === currentYear && exp.category !== 'Invested';
    })
    .reduce((sum, exp) => sum + exp.amount, 0);

  const monthlyInvested = expenses
    .filter(exp => {
      const d = new Date(exp.date);
      return d.getMonth() === currentMonth && d.getFullYear() === currentYear && exp.category === 'Invested';
    })
    .reduce((sum, exp) => sum + exp.amount, 0);

  // Financial Recommendations
  const income = profile?.income || 0;
  const recommendedSavings = income * 0.2; // 20% rule
  const recommendedInvestment = income * 0.1; // 10% rule
  const remainingBudget = income - recommendedSavings - recommendedInvestment;

  const balance = Math.max(0, income - monthlyExpenses - monthlyInvested);
  const isOverspent = monthlyExpenses + monthlyInvested > income;
  const monthlyBudget = profile?.monthlySpendingGoal || income;
  const budgetUsage = (monthlyExpenses / monthlyBudget) * 100;
  const isOverBudget = monthlyExpenses > monthlyBudget;

  // Find top spending category
  const categoryTotals = expenses
    .filter(exp => {
      const d = new Date(exp.date);
      return d.getMonth() === currentMonth && d.getFullYear() === currentYear && exp.category !== 'Invested';
    })
    .reduce((acc, exp) => {
      acc[exp.category] = (acc[exp.category] || 0) + exp.amount;
      return acc;
    }, {} as Record<string, number>);

  const topCategory = Object.entries(categoryTotals)
    .sort(([, a], [, b]) => b - a)[0]?.[0] || 'None';

  const recentTransactions = expenses.slice(0, 5);

  return (
    <div className="space-y-8">
      {/* Financial Overview Cards */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          className="lg:col-span-2 glass-card p-8 rounded-[3rem] text-zinc-900 dark:text-white relative overflow-hidden flex flex-col justify-between min-h-[280px]"
        >
          <div className="relative z-10">
            <div className="flex justify-between items-start mb-8">
              <div>
                <p className="text-zinc-400 dark:text-zinc-500 text-[9px] font-bold uppercase tracking-[0.2em] mb-2">Total Balance</p>
                <h2 className="text-5xl font-bold tracking-tighter">
                  <AnimatedNumber value={income} className="gradient-text" />
                </h2>
              </div>
              <div className="gradient-brand p-4 rounded-2xl shadow-lg shadow-emerald-500/20">
                <Wallet className="w-7 h-7 text-white" />
              </div>
            </div>
            
            <div className="grid grid-cols-2 gap-6">
              <div className="bg-white/40 dark:bg-white/5 rounded-3xl p-5 border border-white/20 dark:border-white/10">
                <div className="flex items-center gap-2 mb-2">
                  <PiggyBank className="w-4 h-4 text-emerald-500" />
                  <span className="text-[9px] font-bold uppercase tracking-wider text-zinc-400">Target Savings</span>
                </div>
                <p className="font-bold text-2xl tracking-tighter">
                  <AnimatedNumber value={recommendedSavings} />
                </p>
              </div>
              <div className="bg-white/40 dark:bg-white/5 rounded-3xl p-5 border border-white/20 dark:border-white/10">
                <div className="flex items-center gap-2 mb-2">
                  <BarChart3 className="w-4 h-4 text-cyan-500" />
                  <span className="text-[9px] font-bold uppercase tracking-wider text-zinc-400">Investments</span>
                </div>
                <p className="font-bold text-2xl tracking-tighter">
                  <AnimatedNumber value={recommendedInvestment} />
                </p>
              </div>
            </div>
          </div>
          
          <div className="absolute -right-20 -top-20 w-80 h-80 bg-emerald-500/10 dark:bg-emerald-500/5 rounded-full blur-[100px]" />
          <div className="absolute -left-20 -bottom-20 w-80 h-80 bg-cyan-500/10 dark:bg-cyan-500/5 rounded-full blur-[100px]" />
        </motion.div>

          <div className="grid grid-cols-1 gap-4">
            <motion.div 
              initial={{ x: 20, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              transition={{ delay: 0.1 }}
              className={`p-5 rounded-[2rem] border shadow-sm flex flex-col justify-between transition-all duration-500 ${isOverspent ? 'bg-red-500/10 border-red-500/20 shadow-red-500/5' : 'glass-card'}`}
            >
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <div className={`w-8 h-8 rounded-xl flex items-center justify-center ${isOverspent ? 'bg-red-500/20' : 'bg-zinc-50 dark:bg-zinc-950'}`}>
                    <TrendingDown className={`w-4 h-4 ${isOverspent ? 'text-red-500' : 'text-zinc-400'}`} />
                  </div>
                  <span className={`text-[8px] font-bold uppercase tracking-wider ${isOverspent ? 'text-red-500' : 'text-zinc-400'}`}>Spent</span>
                </div>
                <p className={`text-xl font-bold tracking-tight ${isOverspent ? 'text-red-600 dark:text-red-400' : 'text-zinc-900 dark:text-white'}`}>
                  <AnimatedNumber value={monthlyExpenses} className={isOverspent ? 'text-red-600 dark:text-red-400' : ''} />
                </p>
              </div>
              <div className="space-y-2">
                <div className={`flex justify-between text-[7px] font-bold uppercase tracking-widest ${isOverspent ? 'text-red-500' : 'text-zinc-400'}`}>
                  <span>{isOverspent ? 'Over Budget' : 'Usage'}</span>
                  <span>{Math.round((monthlyExpenses / remainingBudget) * 100)}%</span>
                </div>
                <div className={`h-1.5 w-full rounded-full overflow-hidden ${isOverspent ? 'bg-red-500/20' : 'bg-zinc-50 dark:bg-zinc-950'}`}>
                  <motion.div 
                    initial={{ width: 0 }}
                    animate={{ width: `${Math.min((monthlyExpenses / remainingBudget) * 100, 100)}%` }}
                    className={`h-full rounded-full ${isOverspent ? 'bg-red-500' : 'gradient-brand'}`} 
                  />
                </div>
              </div>
            </motion.div>

            <motion.div 
              initial={{ x: 20, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              transition={{ delay: 0.2 }}
              className={`glass-card p-5 rounded-[2rem] flex flex-col justify-between border transition-all duration-500 ${isOverBudget ? 'bg-red-500/10 border-red-500/20' : 'border-zinc-100 dark:border-white/5'}`}
            >
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <div className={`w-8 h-8 rounded-xl flex items-center justify-center ${isOverBudget ? 'bg-red-500/20' : 'bg-zinc-50 dark:bg-zinc-950'}`}>
                    <Target className={`w-4 h-4 ${isOverBudget ? 'text-red-500' : 'text-emerald-500'}`} />
                  </div>
                  <span className={`text-[8px] font-bold uppercase tracking-wider ${isOverBudget ? 'text-red-500' : 'text-zinc-400'}`}>Budget</span>
                </div>
                <p className={`text-xl font-bold tracking-tight ${isOverBudget ? 'text-red-600 dark:text-red-400' : 'text-zinc-900 dark:text-white'}`}>
                  <AnimatedNumber value={monthlyBudget} />
                </p>
              </div>
              <div className="space-y-2">
                <div className={`flex justify-between text-[7px] font-bold uppercase tracking-widest ${isOverBudget ? 'text-red-500' : 'text-zinc-400'}`}>
                  <span>{isOverBudget ? 'Exceeded' : 'Limit'}</span>
                  <span>{Math.round(budgetUsage)}%</span>
                </div>
                <div className={`h-1.5 w-full rounded-full overflow-hidden ${isOverBudget ? 'bg-red-500/20' : 'bg-zinc-50 dark:bg-zinc-950'}`}>
                  <motion.div 
                    initial={{ width: 0 }}
                    animate={{ width: `${Math.min(budgetUsage, 100)}%` }}
                    className={`h-full rounded-full ${isOverBudget ? 'bg-red-500' : 'gradient-brand'}`} 
                  />
                </div>
              </div>
            </motion.div>
          </div>
      </div>
      
      <SmartAssistant expenses={expenses} income={income} />

      <FinancialPulse expenses={expenses} />

      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        whileInView={{ opacity: 1, scale: 1 }}
        viewport={{ once: true }}
        onClick={() => onViewEducation()}
        className="glass-card p-6 rounded-[2.5rem] text-zinc-900 dark:text-white relative overflow-hidden shadow-2xl cursor-pointer group border border-zinc-100 dark:border-white/5"
      >
        <div className="relative z-10 flex items-center justify-between">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <BookOpen className="w-5 h-5 text-emerald-500" />
              <span className="text-[10px] font-bold uppercase tracking-[0.2em] text-emerald-500">Money Mastery</span>
            </div>
            <h3 className="text-xl font-bold tracking-tight">Learn to grow your wealth</h3>
            <p className="text-zinc-400 dark:text-zinc-500 text-xs max-w-[200px]">Discover smart tips on budgeting, saving, and investing.</p>
          </div>
          <div className="w-12 h-12 bg-zinc-50 dark:bg-white/10 rounded-2xl flex items-center justify-center group-hover:bg-zinc-100 dark:group-hover:bg-white/20 transition-all">
            <ArrowRight className="w-6 h-6" />
          </div>
        </div>
        <div className="absolute -right-10 -bottom-10 w-40 h-40 bg-emerald-500/10 dark:bg-emerald-500/5 rounded-full blur-3xl" />
      </motion.div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Category Budgets */}
        <div className="space-y-4">
          <h3 className="font-bold text-lg tracking-tight text-zinc-900 dark:text-white px-1">Monthly Budgets</h3>
          {profile?.budgets && Object.keys(profile.budgets).length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {Object.entries(profile.budgets).map(([category, budget]) => {
                const spent = expenses
                  .filter(exp => {
                    const d = new Date(exp.date);
                    return d.getMonth() === currentMonth && d.getFullYear() === currentYear && exp.category === category;
                  })
                  .reduce((sum, exp) => sum + exp.amount, 0);
                const percentage = (spent / (budget as number)) * 100;
                const isNearLimit = percentage >= 80;
                const isOverLimit = percentage >= 100;

                const isTopCategory = category === topCategory;

                return (
                  <motion.div 
                    key={category}
                    initial={{ opacity: 0, scale: 0.95 }}
                    whileInView={{ opacity: 1, scale: 1 }}
                    viewport={{ once: true }}
                    className={`p-5 rounded-[2rem] border shadow-sm transition-all duration-500 ${isOverspent && isTopCategory ? 'bg-red-500/10 border-red-500/30 shadow-lg shadow-red-500/5' : 'glass-card'}`}
                  >
                    <div className="flex justify-between items-center mb-4">
                      <div className="flex items-center gap-3">
                        <div className={`w-10 h-10 rounded-xl flex items-center justify-center text-xl ${isOverspent && isTopCategory ? 'bg-red-500/20' : 'bg-zinc-50 dark:bg-zinc-950'}`}>
                          {getCategoryEmoji(category)}
                        </div>
                        <div>
                          <p className={`text-sm font-bold tracking-tight ${isOverspent && isTopCategory ? 'text-red-600 dark:text-red-400' : 'text-zinc-900 dark:text-white'}`}>{category}</p>
                          <p className="text-[9px] font-bold text-zinc-400 uppercase tracking-wider">
                            <AnimatedNumber value={spent} /> / <AnimatedNumber value={budget as number} />
                          </p>
                        </div>
                      </div>
                      {(isNearLimit || (isOverspent && isTopCategory)) && (
                        <div className={`flex items-center gap-1 px-2 py-1 rounded-full ${isOverLimit || (isOverspent && isTopCategory) ? 'bg-red-500/10 text-red-500 border border-red-500/20' : 'bg-amber-500/10 text-amber-500 border border-amber-500/20'}`}>
                          <AlertTriangle className="w-3 h-3" />
                          <span className="text-[8px] font-bold uppercase tracking-wider">{isOverLimit || (isOverspent && isTopCategory) ? 'Alert' : 'Near'}</span>
                        </div>
                      )}
                    </div>
                    <div className={`h-2 w-full rounded-full overflow-hidden ${isOverspent && isTopCategory ? 'bg-red-500/20' : 'bg-zinc-50 dark:bg-zinc-950'}`}>
                      <motion.div 
                        initial={{ width: 0 }}
                        animate={{ width: `${Math.min(percentage, 100)}%` }}
                        className={`h-full rounded-full transition-all duration-500 ${isOverLimit || (isOverspent && isTopCategory) ? 'bg-red-500' : isNearLimit ? 'bg-amber-500' : 'bg-zinc-900 dark:bg-neon'}`}
                      />
                    </div>
                  </motion.div>
                );
              })}
            </div>
          ) : (
            <div className="bg-white dark:bg-zinc-900 p-8 rounded-[2rem] border border-dashed border-zinc-200 dark:border-zinc-800 text-center">
              <p className="text-zinc-400 dark:text-zinc-500 text-xs font-medium">No budgets set yet</p>
            </div>
          )}
        </div>

        {/* Recent Transactions */}
        <div className="space-y-4">
          <div className="flex items-center justify-between px-1">
            <h3 className="font-bold text-lg tracking-tight text-zinc-900 dark:text-white">Recent Activity</h3>
            <button 
              onClick={onViewAll}
              className="text-zinc-400 dark:text-zinc-500 text-[9px] font-bold uppercase tracking-wider flex items-center gap-1.5 hover:text-zinc-900 dark:hover:text-neon transition-colors"
            >
              <span>View All</span> <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          <div className="space-y-3">
            {recentTransactions.length === 0 ? (
              <div className="bg-white dark:bg-zinc-900 p-8 rounded-[2rem] border border-dashed border-zinc-200 dark:border-zinc-800 text-center">
                <p className="text-zinc-400 dark:text-zinc-500 text-xs font-medium">No transactions yet</p>
              </div>
            ) : (
              recentTransactions.map((expense, idx) => (
                  <motion.div
                    key={expense.id}
                    initial={{ x: -20, opacity: 0 }}
                    whileInView={{ x: 0, opacity: 1 }}
                    viewport={{ once: true }}
                    transition={{ delay: idx * 0.05 }}
                    className="glass-card p-4 rounded-2xl flex items-center justify-between shadow-sm border border-zinc-50 dark:border-white/5 hover:shadow-xl hover:scale-[1.02] transition-all group"
                  >
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-zinc-50 dark:bg-zinc-950 rounded-2xl flex items-center justify-center text-2xl relative group-hover:scale-110 transition-transform">
                      {getCategoryEmoji(expense.category)}
                      <div className={`absolute -bottom-1 -right-1 w-5 h-5 rounded-full border-2 border-white dark:border-zinc-900 flex items-center justify-center text-[8px] ${expense.paymentMethod === 'Online' ? 'bg-zinc-900 dark:bg-white' : 'bg-zinc-400'}`}>
                        {expense.paymentMethod === 'Online' ? '🌐' : '💵'}
                      </div>
                    </div>
                    <div>
                      <p className="font-bold text-zinc-900 dark:text-white text-sm leading-tight tracking-tight shimmer-text">{expense.category}</p>
                      <p className="text-[9px] text-zinc-400 dark:text-zinc-500 font-bold uppercase tracking-wider mt-1">
                        {new Date(expense.date).toLocaleDateString(undefined, { month: 'short', day: 'numeric' })} • {expense.paymentMethod}
                      </p>
                    </div>
                  </div>
                  <p className="font-bold text-zinc-900 dark:text-white text-base tracking-tight">
                    -<AnimatedNumber value={expense.amount} />
                  </p>
                </motion.div>
              ))
            )}
          </div>
        </div>
      </div>

      {/* Debt Alert if exists */}
      {profile?.hasDebt && (
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className="bg-white dark:bg-zinc-900/50 p-6 rounded-[2rem] flex items-center justify-between shadow-xl border border-zinc-100 dark:border-white/5"
        >
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-zinc-900/10 dark:bg-neon/10 rounded-2xl flex items-center justify-center">
              <CreditCard className="w-6 h-6 text-zinc-900 dark:text-neon" />
            </div>
            <div>
              <p className="text-[9px] font-bold text-zinc-400 uppercase tracking-[0.2em] mb-1">Active Debt</p>
              <p className="text-2xl font-bold text-zinc-900 dark:text-white tracking-tight">
                <AnimatedNumber value={profile.debtAmount || 0} />
              </p>
            </div>
          </div>
          <button className="text-xs font-bold text-zinc-950 bg-neon px-6 py-3 rounded-xl shadow-lg active:scale-95 transition-transform">Pay Off Now</button>
        </motion.div>
      )}
    </div>
  );
};
