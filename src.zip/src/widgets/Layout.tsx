import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { useAuth } from '../core/AuthContext';
import { auth } from '../core/firebase';
import { signOut } from 'firebase/auth';
import { LogOut, LayoutDashboard, PlusCircle, PieChart, List, Moon, Sun, RefreshCw, Target, BookOpen } from 'lucide-react';
import { Button } from './Button';
import { NotificationCenter } from './NotificationCenter';

interface LayoutProps {
  children: React.ReactNode;
  activeTab: 'dashboard' | 'expenses' | 'analytics' | 'add' | 'profile' | 'recurring' | 'goals' | 'education';
  onTabChange: (tab: 'dashboard' | 'expenses' | 'analytics' | 'add' | 'profile' | 'recurring' | 'goals' | 'education') => void;
}

export const Layout: React.FC<LayoutProps> = ({ children, activeTab, onTabChange }) => {
  const { user } = useAuth();
  const [isDark, setIsDark] = useState(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('theme');
      if (saved) return saved === 'dark';
      return window.matchMedia('(prefers-color-scheme: dark)').matches;
    }
    return true;
  });

  useEffect(() => {
    const root = window.document.documentElement;
    if (isDark) {
      root.classList.add('dark');
      localStorage.setItem('theme', 'dark');
    } else {
      root.classList.remove('dark');
      localStorage.setItem('theme', 'light');
    }
  }, [isDark]);

  const toggleTheme = () => setIsDark(!isDark);

  const handleLogout = async () => {
    try {
      await signOut(auth);
    } catch (error) {
      console.error('Logout error:', error);
    }
  };

  return (
    <div className="min-h-screen bg-zinc-50 dark:bg-zinc-950 text-zinc-900 dark:text-zinc-50 font-sans selection:bg-zinc-200 dark:selection:bg-neon/30 flex flex-col md:flex-row relative overflow-hidden">
      {/* Background Atmosphere Elements */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
        <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-emerald-500/10 dark:bg-emerald-500/5 rounded-full blur-[120px] animate-pulse" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-cyan-500/10 dark:bg-cyan-500/5 rounded-full blur-[120px] animate-pulse" style={{ animationDelay: '1s' }} />
      </div>

      {/* Sidebar for Desktop */}
      <aside className="hidden md:flex w-64 flex-col glass dark:glass-dark border-r border-zinc-100 dark:border-white/5 h-screen fixed left-0 top-0 z-20 shadow-2xl">
        <div className="p-6 flex items-center gap-3 mb-4">
          <div className="w-10 h-10 bg-linear-to-br from-neon to-emerald-400 rounded-xl flex items-center justify-center shadow-xl">
            <span className="text-zinc-950 font-bold text-xl leading-none">$</span>
          </div>
          <h1 className="font-bold text-xl tracking-tight">Smart Expense</h1>
        </div>

        <nav className="flex-1 px-4 space-y-1">
          <SidebarButton 
            active={activeTab === 'dashboard'} 
            onClick={() => onTabChange('dashboard')}
            icon={<LayoutDashboard className="w-5 h-5" />}
            label="Dashboard"
          />
          <SidebarButton 
            active={activeTab === 'expenses'} 
            onClick={() => onTabChange('expenses')}
            icon={<List className="w-5 h-5" />}
            label="Expenses"
          />
          <SidebarButton 
            active={activeTab === 'analytics'} 
            onClick={() => onTabChange('analytics')}
            icon={<PieChart className="w-5 h-5" />}
            label="Analytics"
          />
          <SidebarButton 
            active={activeTab === 'goals'} 
            onClick={() => onTabChange('goals')}
            icon={<Target className="w-5 h-5" />}
            label="Goals"
          />
          <SidebarButton 
            active={activeTab === 'recurring'} 
            onClick={() => onTabChange('recurring')}
            icon={<RefreshCw className={`w-5 h-5 ${activeTab === 'recurring' ? 'animate-spin-slow' : ''}`} />}
            label="Recurring"
          />
          <SidebarButton 
            active={activeTab === 'education'} 
            onClick={() => onTabChange('education')}
            icon={<BookOpen className="w-5 h-5" />}
            label="Education"
          />
          <SidebarButton 
            active={activeTab === 'profile'} 
            onClick={() => onTabChange('profile')}
            icon={<div className={`w-5 h-5 rounded-full flex items-center justify-center ${activeTab === 'profile' ? 'bg-zinc-900 dark:bg-neon' : 'bg-zinc-100 dark:bg-zinc-800'}`}>
              <span className={`text-[9px] font-bold ${activeTab === 'profile' ? 'text-white dark:text-zinc-950' : 'text-zinc-500'}`}>
                {user?.displayName?.charAt(0) || 'ME'}
              </span>
            </div>}
            label="Profile"
          />
          
          <div className="pt-4 px-2">
            <button
              onClick={toggleTheme}
              className="w-full flex items-center gap-4 px-4 py-3 rounded-2xl transition-all duration-300 group text-zinc-500 hover:bg-zinc-100 dark:hover:bg-zinc-800/50 hover:text-zinc-900 dark:hover:text-white"
            >
              <div className="w-8 h-8 rounded-lg bg-zinc-50 dark:bg-zinc-950 flex items-center justify-center group-hover:scale-110 transition-transform">
                {isDark ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
              </div>
              <span className="font-bold text-sm tracking-tight">{isDark ? 'Light Mode' : 'Dark Mode'}</span>
            </button>
          </div>
        </nav>

        <div className="p-6 pt-2 space-y-3">
          <button
            onClick={() => onTabChange('add')}
            className="w-full py-4 bg-linear-to-br from-neon to-emerald-400 text-zinc-950 rounded-2xl font-bold flex items-center justify-center gap-2 shadow-xl hover:shadow-emerald-500/20 dark:hover:shadow-neon/20 active:scale-95 transition-all"
          >
            <PlusCircle className="w-5 h-5" />
            <span>Add Expense</span>
          </button>
          
          <button 
            onClick={handleLogout}
            className="w-full py-3 flex items-center justify-center gap-2 text-zinc-400 hover:text-red-500 transition-colors font-bold text-xs uppercase tracking-widest"
          >
            <LogOut className="w-4 h-4" />
            <span>Logout</span>
          </button>
        </div>
      </aside>

      <div className="flex-1 flex flex-col min-w-0 md:pl-64">
        {/* Header - Mobile Only */}
        <header className="md:hidden sticky top-0 z-10 glass dark:glass-dark border-b border-zinc-100 dark:border-white/5 px-5 py-3 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 bg-linear-to-br from-neon to-emerald-400 rounded-lg flex items-center justify-center shadow-lg">
              <span className="text-zinc-950 font-bold text-lg leading-none">$</span>
            </div>
            <h1 className="font-bold text-lg tracking-tight">Smart Expense</h1>
          </div>
          <div className="flex items-center gap-2.5">
            <NotificationCenter />
            <button
              onClick={toggleTheme}
              className="w-8 h-8 bg-zinc-100 dark:bg-zinc-800 rounded-lg flex items-center justify-center text-zinc-500 dark:text-zinc-400"
            >
              {isDark ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            </button>
            {user && (
              <button 
                onClick={() => onTabChange('profile')}
                className="w-8 h-8 bg-zinc-100 dark:bg-zinc-800 rounded-full flex items-center justify-center overflow-hidden hover:ring-2 hover:ring-zinc-900 dark:hover:ring-neon transition-all"
              >
                <div className="w-full h-full bg-zinc-200 dark:bg-zinc-700 flex items-center justify-center">
                  <span className="text-zinc-700 dark:text-zinc-300 text-xs font-bold">{user.displayName?.charAt(0) || user.email?.charAt(0)}</span>
                </div>
              </button>
            )}
          </div>
        </header>

        {/* Main Content */}
        <main className="flex-1 pb-32 md:pb-12 pt-6 px-6 md:px-12 w-full max-w-7xl mx-auto">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3, ease: "easeOut" }}
          >
            {children}
          </motion.div>
        </main>

        {/* Bottom Navigation - Mobile Only */}
        <nav className="md:hidden fixed bottom-0 left-0 right-0 glass dark:glass-dark border-t border-zinc-100 dark:border-white/5 px-6 py-3 flex items-center justify-between rounded-t-3xl shadow-2xl z-20">
          <NavButton 
            active={activeTab === 'dashboard'} 
            onClick={() => onTabChange('dashboard')}
            icon={<LayoutDashboard className="w-5 h-5" />}
            label="Home"
          />
          <NavButton 
            active={activeTab === 'expenses'} 
            onClick={() => onTabChange('expenses')}
            icon={<List className="w-5 h-5" />}
            label="List"
          />
          <div className="relative -top-6">
            <button
              onClick={() => onTabChange('add')}
              className="w-14 h-14 bg-linear-to-br from-neon to-emerald-400 rounded-full flex items-center justify-center shadow-2xl text-zinc-950 active:scale-90 transition-transform"
            >
              <PlusCircle className="w-8 h-8" />
            </button>
          </div>
          <NavButton 
            active={activeTab === 'analytics'} 
            onClick={() => onTabChange('analytics')}
            icon={<PieChart className="w-5 h-5" />}
            label="Stats"
          />
          <NavButton 
            active={activeTab === 'goals'} 
            onClick={() => onTabChange('goals')}
            icon={<Target className="w-5 h-5" />}
            label="Goals"
          />
          <NavButton 
            active={activeTab === 'recurring'} 
            onClick={() => onTabChange('recurring')}
            icon={<RefreshCw className={`w-5 h-5 ${activeTab === 'recurring' ? 'animate-spin-slow' : ''}`} />}
            label="Repeat"
          />
          <NavButton 
            active={activeTab === 'education'} 
            onClick={() => onTabChange('education')}
            icon={<BookOpen className="w-5 h-5" />}
            label="Learn"
          />
          <NavButton 
            active={activeTab === 'profile'} 
            onClick={() => onTabChange('profile')}
            icon={<div className={`w-5 h-5 rounded-full flex items-center justify-center ${activeTab === 'profile' ? 'bg-zinc-900 dark:bg-neon' : 'bg-zinc-100 dark:bg-zinc-800'}`}>
              <span className={`text-[9px] font-bold ${activeTab === 'profile' ? 'text-white dark:text-zinc-950' : 'text-zinc-500'}`}>
                {user?.displayName?.charAt(0) || 'ME'}
              </span>
            </div>}
            label="Me"
          />
        </nav>
      </div>
    </div>
  );
};

interface SidebarButtonProps {
  active: boolean;
  onClick: () => void;
  icon: React.ReactNode;
  label: string;
}

const SidebarButton: React.FC<SidebarButtonProps> = ({ active, onClick, icon, label }) => (
    <button
      onClick={onClick}
      className={`w-full flex items-center gap-4 px-6 py-4 rounded-2xl transition-all duration-300 group ${
        active 
          ? 'bg-linear-to-br from-neon to-emerald-400 text-zinc-950 shadow-xl' 
          : 'text-zinc-500 hover:bg-zinc-100/50 dark:hover:bg-white/5 hover:text-zinc-900 dark:hover:text-white'
      }`}
    >
    <div className={`transition-transform duration-300 ${active ? 'scale-110' : 'group-hover:scale-110'}`}>
      {icon}
    </div>
    <span className={`font-bold text-sm tracking-tight`}>{label}</span>
  </button>
);

interface NavButtonProps {
  active: boolean;
  onClick: () => void;
  icon: React.ReactNode;
  label: string;
}

const NavButton: React.FC<NavButtonProps> = ({ active, onClick, icon, label }) => (
  <button
    onClick={onClick}
    className={`flex flex-col items-center gap-1 transition-all duration-300 ${
      active ? 'text-zinc-900 dark:text-neon scale-105' : 'text-zinc-400'
    }`}
  >
    {icon}
    <span className={`text-[8px] font-bold uppercase tracking-[0.15em]`}>{label}</span>
  </button>
);
