import React from 'react';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';
import { motion } from 'motion/react';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'outline' | 'ghost' | 'danger' | 'gradient';
  size?: 'sm' | 'md' | 'lg' | 'icon';
  isLoading?: boolean;
}

export const Button: React.FC<ButtonProps> = ({
  className,
  variant = 'primary',
  size = 'md',
  isLoading,
  children,
  disabled,
  ...props
}) => {
  const variants = {
    primary: 'bg-zinc-900 text-white hover:bg-zinc-800 shadow-md dark:bg-neon dark:text-zinc-950 dark:hover:opacity-90',
    secondary: 'bg-zinc-100 text-zinc-900 hover:bg-zinc-200 shadow-sm dark:bg-zinc-800 dark:text-white dark:hover:bg-zinc-700',
    outline: 'border border-zinc-200 bg-transparent hover:bg-zinc-50 text-zinc-900 dark:border-zinc-800 dark:hover:bg-zinc-900 dark:text-zinc-50',
    ghost: 'bg-transparent hover:bg-zinc-100 text-zinc-600 dark:hover:bg-zinc-900 dark:text-zinc-400',
    danger: 'bg-red-500 text-white hover:bg-red-600 shadow-sm',
    gradient: 'bg-linear-to-br from-emerald-500 to-cyan-500 dark:from-neon dark:to-emerald-400 text-white dark:text-zinc-950 shadow-lg shadow-emerald-500/20 dark:shadow-neon/20 hover:opacity-90',
  };

  const sizes = {
    sm: 'px-3 py-1.5 text-xs',
    md: 'px-5 py-2.5 text-sm',
    lg: 'px-6 py-3 text-base',
    icon: 'p-2.5',
  };

  return (
    <motion.button
      whileHover={{ scale: 1.02 }}
      whileTap={{ scale: 0.98 }}
      className={cn(
        'inline-flex items-center justify-center rounded-2xl font-semibold transition-all disabled:opacity-50 disabled:pointer-events-none tracking-tight',
        variants[variant],
        sizes[size],
        className
      )}
      disabled={isLoading || disabled}
      {...(props as any)}
    >
      {isLoading ? (
        <div className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-current border-t-transparent" />
      ) : null}
      {children}
    </motion.button>
  );
};
