import React from 'react';
import { 
  AreaChart, 
  Area, 
  PieChart, 
  Pie, 
  Cell, 
  ResponsiveContainer, 
  Tooltip, 
  XAxis, 
  YAxis, 
  CartesianGrid 
} from 'recharts';
import { Expense, CATEGORIES, getCategoryEmoji } from '../models/types';
import { useCurrency } from '../hooks/useCurrency';
import { AnimatedNumber } from './AnimatedNumber';
import { motion } from 'motion/react';
import { Activity, PieChart as PieIcon, TrendingUp } from 'lucide-react';

interface FinancialPulseProps {
  expenses: Expense[];
  title?: string;
}

const COLORS = [
  '#00FF88', // Neon Green
  '#3b82f6', // Blue
  '#8b5cf6', // Violet
  '#f59e0b', // Amber
  '#ef4444', // Red
  '#ec4899', // Pink
  '#14b8a6', // Teal
  '#64748b', // Slate
];

export const FinancialPulse: React.FC<FinancialPulseProps> = ({ expenses, title = "Financial Pulse" }) => {
  const { format } = useCurrency();
  
  // 1. Process Pie Data (Category Distribution - Last 30 Days)
  const now = new Date();
  const thirtyDaysAgo = new Date();
  thirtyDaysAgo.setDate(now.getDate() - 30);
  
  const recentExpenses = expenses.filter(e => new Date(e.date) >= thirtyDaysAgo && e.category !== 'Invested');
  
  const categoryTotals = CATEGORIES.reduce((acc, cat) => {
    const total = recentExpenses
      .filter(e => e.category === cat)
      .reduce((sum, e) => sum + e.amount, 0);
    if (total > 0) acc.push({ name: cat, value: total });
    return acc;
  }, [] as { name: string; value: number }[]);

  const totalSpent = categoryTotals.reduce((sum, item) => sum + item.value, 0);

  // 2. Process Waveform Data (Daily Spending Trend - Last 14 Days)
  const fourteenDaysAgo = new Date();
  fourteenDaysAgo.setDate(now.getDate() - 14);
  
  const trendData = Array.from({ length: 14 }).map((_, i) => {
    const date = new Date(fourteenDaysAgo);
    date.setDate(date.getDate() + i + 1);
    const dateStr = date.toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
    
    const dailyTotal = expenses
      .filter(e => {
        const d = new Date(e.date);
        return d.toDateString() === date.toDateString() && e.category !== 'Invested';
      })
      .reduce((sum, e) => sum + e.amount, 0);
      
    return { name: dateStr, amount: dailyTotal };
  });

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between px-1">
        <div className="flex items-center gap-2">
          <Activity className="w-5 h-5 text-neon" />
          <h3 className="font-bold text-lg tracking-tight text-zinc-900 dark:text-white">{title}</h3>
        </div>
        <div className="flex items-center gap-1 text-[9px] font-bold text-zinc-400 uppercase tracking-widest">
          <span>Last 30 Days</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
        {/* Waveform Graph (Area Chart) */}
        <motion.div 
          initial={{ opacity: 0, x: -20 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          className="lg:col-span-3 glass-card p-6 rounded-[2.5rem] border border-zinc-100 dark:border-white/5 shadow-sm relative overflow-hidden"
        >
          <div className="flex items-center justify-between mb-6">
            <div>
              <p className="text-[9px] font-bold text-zinc-400 uppercase tracking-widest mb-1">Spending Wave</p>
              <h4 className="text-xl font-bold text-zinc-900 dark:text-white tracking-tight">Daily Pulse</h4>
            </div>
            <div className="w-10 h-10 bg-zinc-50 dark:bg-zinc-950 rounded-xl flex items-center justify-center">
              <TrendingUp className="w-5 h-5 text-neon" />
            </div>
          </div>

          <div className="h-[200px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={trendData}>
                <defs>
                  <linearGradient id="pulseGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#00FF88" stopOpacity={0.2}/>
                    <stop offset="95%" stopColor="#00FF88" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" opacity={0.5} />
                <XAxis 
                  dataKey="name" 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{ fontSize: 9, fill: '#94a3b8', fontWeight: 'bold' }} 
                />
                <YAxis 
                  hide
                />
                <Tooltip 
                  contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 20px 25px -5px rgb(0 0 0 / 0.1)', backgroundColor: '#18181b', color: '#fff', fontSize: '11px' }}
                  itemStyle={{ color: '#fff' }}
                  labelStyle={{ color: '#94a3b8', marginBottom: '4px', fontWeight: 'bold' }}
                  formatter={(value: number) => [format(value), 'Spent']}
                />
                <Area 
                  type="monotone" 
                  dataKey="amount" 
                  stroke="#00FF88" 
                  strokeWidth={4}
                  fillOpacity={1} 
                  fill="url(#pulseGradient)" 
                  animationDuration={2000}
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
          
          <div className="absolute -right-10 -bottom-10 w-32 h-32 bg-neon/5 rounded-full blur-3xl" />
        </motion.div>

        {/* Pie Chart Graph */}
        <motion.div 
          initial={{ opacity: 0, x: 20 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          className="lg:col-span-2 glass-card p-6 rounded-[2.5rem] border border-zinc-100 dark:border-white/5 shadow-sm relative overflow-hidden"
        >
          <div className="flex items-center justify-between mb-6">
            <div>
              <p className="text-[9px] font-bold text-zinc-400 uppercase tracking-widest mb-1">Spending Mix</p>
              <h4 className="text-xl font-bold text-zinc-900 dark:text-white tracking-tight">Category Split</h4>
            </div>
            <div className="w-10 h-10 bg-zinc-50 dark:bg-zinc-950 rounded-xl flex items-center justify-center">
              <PieIcon className="w-5 h-5 text-neon" />
            </div>
          </div>

          <div className="h-[200px] w-full relative">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={categoryTotals}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={80}
                  paddingAngle={8}
                  dataKey="value"
                  animationDuration={1500}
                >
                  {categoryTotals.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip 
                  contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 20px 25px -5px rgb(0 0 0 / 0.1)', backgroundColor: '#18181b', color: '#fff', fontSize: '11px' }}
                  itemStyle={{ color: '#fff' }}
                  formatter={(value: number) => [format(value), 'Amount']}
                />
              </PieChart>
            </ResponsiveContainer>
            
            <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
              <p className="text-[8px] font-bold text-zinc-400 uppercase tracking-widest">Total</p>
              <p className="text-lg font-bold text-zinc-900 dark:text-white tracking-tight">
                <AnimatedNumber value={totalSpent} />
              </p>
            </div>
          </div>
          
          <div className="absolute -left-10 -bottom-10 w-32 h-32 bg-blue-500/5 rounded-full blur-3xl" />
        </motion.div>
      </div>

      {/* Systematic Summary */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className="glass-card p-4 rounded-2xl border border-zinc-100 dark:border-white/5 flex items-center gap-4"
      >
        <div className="w-10 h-10 bg-neon/10 rounded-xl flex items-center justify-center shrink-0">
          <TrendingUp className="w-5 h-5 text-neon" />
        </div>
        <p className="text-[10px] text-zinc-500 dark:text-zinc-400 leading-relaxed font-medium">
          Your <span className="text-zinc-900 dark:text-white font-bold">Financial Pulse</span> shows a {trendData[trendData.length-1].amount > trendData[trendData.length-2].amount ? 'slight increase' : 'decrease'} in spending over the last 24 hours. 
          The <span className="text-zinc-900 dark:text-white font-bold">{categoryTotals.sort((a,b) => b.value - a.value)[0]?.name || 'top'}</span> category is currently your largest expense area.
        </p>
      </motion.div>
    </div>
  );
};
