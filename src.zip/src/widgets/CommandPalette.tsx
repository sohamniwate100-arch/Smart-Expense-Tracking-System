import React, { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Search, Plus, PieChart, LayoutDashboard, List, User, X, Command, RefreshCw, Target, BookOpen } from 'lucide-react';

interface CommandPaletteProps {
  onTabChange: (tab: any) => void;
  isOpen: boolean;
  onClose: () => void;
}

export const CommandPalette: React.FC<CommandPaletteProps> = ({ onTabChange, isOpen, onClose }) => {
  const [query, setQuery] = useState('');

  const commands = [
    { id: 'dashboard', label: 'Go to Dashboard', icon: <LayoutDashboard className="w-4 h-4" />, action: () => onTabChange('dashboard') },
    { id: 'expenses', label: 'View Expenses', icon: <List className="w-4 h-4" />, action: () => onTabChange('expenses') },
    { id: 'analytics', label: 'View Analytics', icon: <PieChart className="w-4 h-4" />, action: () => onTabChange('analytics') },
    { id: 'goals', label: 'Financial Goals', icon: <Target className="w-4 h-4" />, action: () => onTabChange('goals') },
    { id: 'recurring', label: 'Recurring Expenses', icon: <RefreshCw className="w-4 h-4" />, action: () => onTabChange('recurring') },
    { id: 'education', label: 'Money Mastery (Tips)', icon: <BookOpen className="w-4 h-4" />, action: () => onTabChange('education') },
    { id: 'add', label: 'Add New Expense', icon: <Plus className="w-4 h-4" />, action: () => onTabChange('add') },
    { id: 'profile', label: 'View Profile', icon: <User className="w-4 h-4" />, action: () => onTabChange('profile') },
  ];

  const filteredCommands = commands.filter(cmd => 
    cmd.label.toLowerCase().includes(query.toLowerCase())
  );

  const handleKeyDown = useCallback((e: KeyboardEvent) => {
    if (e.key === 'k' && (e.metaKey || e.ctrlKey)) {
      e.preventDefault();
      if (isOpen) onClose();
      else onClose(); // This logic is handled by the parent, but we can trigger a toggle if we had one
    }
    if (e.key === 'Escape') onClose();
  }, [isOpen, onClose]);

  useEffect(() => {
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handleKeyDown]);

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-start justify-center pt-[15vh] px-4">
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="absolute inset-0 bg-zinc-950/40 backdrop-blur-sm"
        />
        
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: -20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: -20 }}
          className="relative w-full max-w-xl bg-white dark:bg-zinc-900 rounded-3xl shadow-2xl border border-zinc-200 dark:border-zinc-800 overflow-hidden"
        >
          <div className="flex items-center px-6 py-4 border-b border-zinc-100 dark:border-zinc-800">
            <Search className="w-5 h-5 text-zinc-400 mr-4" />
            <input
              autoFocus
              placeholder="Type a command or search..."
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              className="flex-1 bg-transparent border-none outline-none text-zinc-900 dark:text-white font-medium placeholder:text-zinc-400"
            />
            <div className="flex items-center gap-1 px-2 py-1 bg-zinc-100 dark:bg-zinc-800 rounded-lg border border-zinc-200 dark:border-zinc-700">
              <Command className="w-3 h-3 text-zinc-400" />
              <span className="text-[10px] font-bold text-zinc-400">K</span>
            </div>
            <button onClick={onClose} className="ml-4 p-1 hover:bg-zinc-100 dark:hover:bg-zinc-800 rounded-lg transition-colors">
              <X className="w-4 h-4 text-zinc-400" />
            </button>
          </div>

          <div className="max-h-[60vh] overflow-y-auto p-2">
            {filteredCommands.length > 0 ? (
              filteredCommands.map((cmd) => (
                <button
                  key={cmd.id}
                  onClick={() => {
                    cmd.action();
                    onClose();
                  }}
                  className="w-full flex items-center gap-4 px-4 py-3 rounded-2xl hover:bg-zinc-100 dark:hover:bg-zinc-800 transition-all group text-left"
                >
                  <div className="w-10 h-10 bg-zinc-50 dark:bg-zinc-950 rounded-xl flex items-center justify-center text-zinc-400 group-hover:text-zinc-900 dark:group-hover:text-neon transition-colors">
                    {cmd.icon}
                  </div>
                  <span className="font-bold text-sm text-zinc-600 dark:text-zinc-400 group-hover:text-zinc-900 dark:group-hover:text-white tracking-tight">
                    {cmd.label}
                  </span>
                </button>
              ))
            ) : (
              <div className="p-8 text-center">
                <p className="text-zinc-400 text-sm font-medium">No commands found for "{query}"</p>
              </div>
            )}
          </div>

          <div className="px-6 py-3 bg-zinc-50 dark:bg-zinc-950/50 border-t border-zinc-100 dark:border-zinc-800 flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-1.5">
                <kbd className="px-1.5 py-0.5 bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-700 rounded text-[10px] font-bold text-zinc-400 shadow-sm">↑↓</kbd>
                <span className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider">Navigate</span>
              </div>
              <div className="flex items-center gap-1.5">
                <kbd className="px-1.5 py-0.5 bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-700 rounded text-[10px] font-bold text-zinc-400 shadow-sm">Enter</kbd>
                <span className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider">Select</span>
              </div>
            </div>
            <span className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest">Smart Expense v1.0</span>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
