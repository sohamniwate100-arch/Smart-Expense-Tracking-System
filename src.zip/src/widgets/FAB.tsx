import React from 'react';
import { motion } from 'motion/react';
import { Plus } from 'lucide-react';

interface FABProps {
  onClick: () => void;
  visible: boolean;
}

export const FAB: React.FC<FABProps> = ({ onClick, visible }) => {
  if (!visible) return null;

  return (
    <motion.button
      initial={{ scale: 0, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      exit={{ scale: 0, opacity: 0 }}
      whileHover={{ scale: 1.1 }}
      whileTap={{ scale: 0.9 }}
      onClick={onClick}
      className="fixed bottom-24 right-6 md:right-12 w-14 h-14 bg-zinc-900 dark:bg-neon text-white dark:text-zinc-950 rounded-full flex items-center justify-center shadow-2xl z-40 md:hidden"
    >
      <Plus className="w-8 h-8" />
    </motion.button>
  );
};
