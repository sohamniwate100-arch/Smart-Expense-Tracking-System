import React from 'react';
import { useCurrency } from '../hooks/useCurrency';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

interface AnimatedNumberProps {
  value: number;
  className?: string;
  showSymbol?: boolean;
  formatValue?: (value: number) => string;
}

export const AnimatedNumber: React.FC<AnimatedNumberProps> = ({ 
  value, 
  className,
  showSymbol = true,
  formatValue
}) => {
  const { format } = useCurrency();
  const formatted = formatValue ? formatValue(value) : format(value);

  return (
    <span className={cn('number-gradient', className)}>
      {formatted}
    </span>
  );
};
