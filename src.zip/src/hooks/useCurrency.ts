/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect, useMemo } from 'react';
import { useAuth } from '../core/AuthContext';
import { fetchExchangeRates, formatCurrency, ExchangeRates, SUPPORTED_CURRENCIES } from '../services/currencyService';

export function useCurrency() {
  const { profile } = useAuth();
  const [rates, setRates] = useState<ExchangeRates | null>(null);
  const [loading, setLoading] = useState(true);

  const userCurrency = profile?.currency || 'INR';

  useEffect(() => {
    async function getRates() {
      try {
        // We always use INR as our base for stored data
        const data = await fetchExchangeRates('INR');
        setRates(data);
      } catch (error) {
        console.error('Failed to load rates:', error);
      } finally {
        setLoading(false);
      }
    }
    getRates();
  }, []);

  const convert = (amount: number): number => {
    if (!rates || userCurrency === 'INR') return amount;
    const rate = rates[userCurrency];
    return rate ? amount * rate : amount;
  };

  const format = (amount: number): string => {
    const converted = convert(amount);
    return formatCurrency(converted, userCurrency);
  };

  const getSymbol = () => {
    const currency = SUPPORTED_CURRENCIES.find(c => c.code === userCurrency);
    return currency?.symbol || '₹';
  };

  return {
    convert,
    format,
    getSymbol,
    loading,
    userCurrency,
    SUPPORTED_CURRENCIES
  };
}
