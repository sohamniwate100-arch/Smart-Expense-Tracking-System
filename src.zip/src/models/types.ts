export interface UserProfile {
  uid: string;
  email: string;
  displayName: string;
  profession?: 'Job' | 'Student' | 'Business Owner' | 'Freelancer';
  jobType?: 'Part-time' | 'Full-time' | 'Weekend';
  studentLevel?: 'School going' | 'HSC' | 'Polytechnic' | 'Graduation' | 'Post Graduation';
  businessType?: 'Online Business' | 'Offline Business';
  businessDescription?: string;
  businessCategory?: 'B2B' | 'B2C' | 'C2C' | 'C2B';
  income?: number;
  currency?: string;
  age?: number;
  dailySpendingGoal?: number;
  monthlySpendingGoal?: number;
  hasDebt?: boolean;
  debtAmount?: number;
  financialGoal?: string;
  onboardingCompleted?: boolean;
  budgets?: Record<string, number>;
  createdAt: any;
}

export interface Expense {
  id: string;
  userId: string;
  amount: number;
  currency: string;
  category: string;
  notes?: string;
  date: string; // ISO string
  paymentMethod: 'Online' | 'Cash';
  createdAt?: string;
  isRecurring?: boolean;
  recurringId?: string;
  isTaxDeductible?: boolean;
  receiptUrl?: string;
}

export type Frequency = 'Daily' | 'Weekly' | 'Monthly';

export interface RecurringExpense {
  id: string;
  userId: string;
  amount: number;
  currency: string;
  category: string;
  notes?: string;
  frequency: Frequency;
  startDate: string; // ISO string
  lastProcessedDate?: string; // ISO string
  nextDueDate: string; // ISO string
  active: boolean;
  paymentMethod: 'Online' | 'Cash';
  createdAt: any;
  isTaxDeductible?: boolean;
}

export interface FinancialGoal {
  id: string;
  userId: string;
  title: string;
  targetAmount: number;
  currentAmount: number;
  deadline: string;
  category: string;
  createdAt: any;
}

export type Category = 'Food' | 'Transport' | 'Shopping' | 'Bills' | 'Entertainment' | 'Health' | 'Invested' | 'Inventory' | 'Marketing' | 'Salaries' | 'Rent' | 'Utilities' | 'Other';

export const CATEGORIES: Category[] = ['Food', 'Transport', 'Shopping', 'Bills', 'Entertainment', 'Health', 'Invested', 'Inventory', 'Marketing', 'Salaries', 'Rent', 'Utilities', 'Other'];

export const BUSINESS_CATEGORIES: Category[] = ['Inventory', 'Marketing', 'Salaries', 'Rent', 'Utilities'];

export function getCategoryEmoji(category: string): string {
  switch (category) {
    case 'Food': return '🍔';
    case 'Transport': return '🚗';
    case 'Shopping': return '🛍️';
    case 'Bills': return '📄';
    case 'Entertainment': return '🎬';
    case 'Health': return '💊';
    case 'Invested': return '📈';
    case 'Inventory': return '📦';
    case 'Marketing': return '📢';
    case 'Salaries': return '👥';
    case 'Rent': return '🏢';
    case 'Utilities': return '⚡';
    default: return '💰';
  }
}
